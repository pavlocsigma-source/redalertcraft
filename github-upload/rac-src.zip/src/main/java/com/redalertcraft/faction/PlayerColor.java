package com.redalertcraft.faction;

import net.minecraft.network.chat.Component;

/**
 * Цвета игроков в матче. В одной комнате цвет должен быть уникальным.
 */
public enum PlayerColor {
    RED(0xE53935, "color.redalertcraft.red"),
    BLUE(0x1E88E5, "color.redalertcraft.blue"),
    GREEN(0x43A047, "color.redalertcraft.green"),
    YELLOW(0xFDD835, "color.redalertcraft.yellow"),
    ORANGE(0xFB8C00, "color.redalertcraft.orange"),
    PURPLE(0x8E24AA, "color.redalertcraft.purple"),
    CYAN(0x00ACC1, "color.redalertcraft.cyan"),
    PINK(0xD81B60, "color.redalertcraft.pink");

    private final int rgb;
    private final String key;

    PlayerColor(int rgb, String key) {
        this.rgb = rgb;
        this.key = key;
    }

    public int getRgb() {
        return rgb;
    }

    /** ARGB для рендера (непрозрачный). */
    public int getArgb() {
        return 0xFF000000 | rgb;
    }

    public float[] getRgbFloats() {
        return new float[]{
                ((rgb >> 16) & 0xFF) / 255f,
                ((rgb >> 8) & 0xFF) / 255f,
                (rgb & 0xFF) / 255f
        };
    }

    public Component getDisplayName() {
        return Component.translatable(key);
    }

    public static PlayerColor byOrdinal(int i) {
        PlayerColor[] v = values();
        if (i < 0 || i >= v.length) {
            return RED;
        }
        return v[i];
    }

    public static PlayerColor byName(String name) {
        for (PlayerColor c : values()) {
            if (c.name().equalsIgnoreCase(name)) {
                return c;
            }
        }
        return RED;
    }
}
