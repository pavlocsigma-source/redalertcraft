package com.redalertcraft.faction;

import net.minecraft.network.chat.Component;
import net.minecraft.util.StringRepresentable;

/**
 * Три фракции Red Alert Craft.
 */
public enum Faction implements StringRepresentable {
    SOVIET("soviet", 0xCC2222, "faction.redalertcraft.soviet"),
    ALLIES("allies", 0x3366CC, "faction.redalertcraft.allies"),
    EMPIRE("empire", 0xE8A0C0, "faction.redalertcraft.empire");

    private final String id;
    private final int color;
    private final String translationKey;

    Faction(String id, int color, String translationKey) {
        this.id = id;
        this.color = color;
        this.translationKey = translationKey;
    }

    public String getId() {
        return id;
    }

    public int getColor() {
        return color;
    }

    public Component getDisplayName() {
        return Component.translatable(translationKey);
    }

    public static Faction byId(String id) {
        for (Faction f : values()) {
            if (f.id.equalsIgnoreCase(id) || f.name().equalsIgnoreCase(id)) {
                return f;
            }
        }
        return ALLIES;
    }

    @Override
    public String getSerializedName() {
        return id;
    }

    /** Множитель брони (СССР толще). */
    public double armorBonus() {
        return switch (this) {
            case SOVIET -> 1.35;
            case ALLIES -> 1.0;
            case EMPIRE -> 0.85;
        };
    }

    /** Множитель скорости (Империя быстрее). */
    public double speedBonus() {
        return switch (this) {
            case SOVIET -> 0.9;
            case ALLIES -> 1.0;
            case EMPIRE -> 1.2;
        };
    }

    /** Множитель урона. */
    public double damageBonus() {
        return switch (this) {
            case SOVIET -> 1.15;
            case ALLIES -> 1.0;
            case EMPIRE -> 0.95;
        };
    }
}
