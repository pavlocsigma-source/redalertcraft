package com.redalertcraft.faction;

import net.minecraft.nbt.CompoundTag;

public class PlayerFactionData {

    private Faction faction = Faction.ALLIES;
    private int team = 1;
    private PlayerColor color = PlayerColor.BLUE;
    private boolean ready = false;

    public Faction getFaction() { return faction; }
    public void setFaction(Faction faction) { this.faction = faction != null ? faction : Faction.ALLIES; }
    public int getTeam() { return team; }
    public void setTeam(int team) { this.team = Math.max(1, Math.min(3, team)); }
    public PlayerColor getColor() { return color; }
    public void setColor(PlayerColor color) { this.color = color != null ? color : PlayerColor.BLUE; }
    public boolean isReady() { return ready; }
    public void setReady(boolean ready) { this.ready = ready; }

    public void copyFrom(PlayerFactionData other) {
        this.faction = other.faction;
        this.team = other.team;
        this.color = other.color;
        this.ready = other.ready;
    }

    public void saveNBT(CompoundTag tag) {
        tag.putString("Faction", faction.getId());
        tag.putInt("Team", team);
        tag.putString("Color", color.name());
        tag.putBoolean("Ready", ready);
    }

    public void loadNBT(CompoundTag tag) {
        if (tag.contains("Faction")) faction = Faction.byId(tag.getString("Faction"));
        if (tag.contains("Team")) team = tag.getInt("Team");
        if (tag.contains("Color")) color = PlayerColor.byName(tag.getString("Color"));
        if (tag.contains("Ready")) ready = tag.getBoolean("Ready");
    }
}
