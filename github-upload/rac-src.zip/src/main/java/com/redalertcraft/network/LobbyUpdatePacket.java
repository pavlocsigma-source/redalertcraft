package com.redalertcraft.network;

import com.redalertcraft.faction.Faction;
import com.redalertcraft.faction.PlayerColor;
import com.redalertcraft.match.MatchManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class LobbyUpdatePacket {

    private final String factionId;
    private final int team;
    private final int colorOrdinal;
    private final boolean ready;
    private final String mapId;

    public LobbyUpdatePacket(String factionId, int team, int colorOrdinal, boolean ready, String mapId) {
        this.factionId = factionId;
        this.team = team;
        this.colorOrdinal = colorOrdinal;
        this.ready = ready;
        this.mapId = mapId != null ? mapId : "moscow";
    }

    public static void encode(LobbyUpdatePacket p, FriendlyByteBuf buf) {
        buf.writeUtf(p.factionId, 16);
        buf.writeVarInt(p.team);
        buf.writeVarInt(p.colorOrdinal);
        buf.writeBoolean(p.ready);
        buf.writeUtf(p.mapId, 32);
    }

    public static LobbyUpdatePacket decode(FriendlyByteBuf buf) {
        return new LobbyUpdatePacket(buf.readUtf(16), buf.readVarInt(), buf.readVarInt(), buf.readBoolean(), buf.readUtf(32));
    }

    public static void handle(LobbyUpdatePacket packet, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null) return;
            MatchManager.updatePlayerSettings(
                    player,
                    Faction.byId(packet.factionId),
                    packet.team,
                    PlayerColor.byOrdinal(packet.colorOrdinal),
                    packet.ready
            );
            // Карту меняет только хост (или любой, если хост не задан)
            MatchManager.setSelectedMap(player, packet.mapId);
        });
        ctx.get().setPacketHandled(true);
    }
}
