package com.redalertcraft.network;

import com.redalertcraft.RedAlertCraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.Optional;

public final class ModNetwork {

    private static final String PROTOCOL = "2";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(RedAlertCraft.MOD_ID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals
    );

    private static int packetId = 0;

    public static void register() {
        CHANNEL.registerMessage(packetId++, SyncCreditsPacket.class,
                SyncCreditsPacket::encode, SyncCreditsPacket::decode, SyncCreditsPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(packetId++, UnitOrderPacket.class,
                UnitOrderPacket::encode, UnitOrderPacket::decode, UnitOrderPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(packetId++, LobbySyncPacket.class,
                LobbySyncPacket::encode, LobbySyncPacket::decode, LobbySyncPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(packetId++, LobbyUpdatePacket.class,
                LobbyUpdatePacket::encode, LobbyUpdatePacket::decode, LobbyUpdatePacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));
    }

    public static void sendCreditsToPlayer(net.minecraft.server.level.ServerPlayer player, int credits) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new SyncCreditsPacket(credits));
    }

    private ModNetwork() {}
}
