package com.redalertcraft.network;

import com.redalertcraft.entity.RaUnit;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Приказ выделенным юнитам: движение или атака.
 */
public class UnitOrderPacket {

    public enum OrderType {
        MOVE,
        ATTACK
    }

    private final OrderType type;
    private final int[] unitIds;
    private final double x, y, z;
    private final int targetId;

    private UnitOrderPacket(OrderType type, int[] unitIds, double x, double y, double z, int targetId) {
        this.type = type;
        this.unitIds = unitIds;
        this.x = x;
        this.y = y;
        this.z = z;
        this.targetId = targetId;
    }

    public static UnitOrderPacket move(int[] unitIds, double x, double y, double z) {
        return new UnitOrderPacket(OrderType.MOVE, unitIds, x, y, z, -1);
    }

    public static UnitOrderPacket attack(int[] unitIds, int targetId) {
        return new UnitOrderPacket(OrderType.ATTACK, unitIds, 0, 0, 0, targetId);
    }

    public static void encode(UnitOrderPacket packet, FriendlyByteBuf buf) {
        buf.writeEnum(packet.type);
        buf.writeVarIntArray(packet.unitIds);
        if (packet.type == OrderType.MOVE) {
            buf.writeDouble(packet.x);
            buf.writeDouble(packet.y);
            buf.writeDouble(packet.z);
        } else {
            buf.writeVarInt(packet.targetId);
        }
    }

    public static UnitOrderPacket decode(FriendlyByteBuf buf) {
        OrderType type = buf.readEnum(OrderType.class);
        int[] ids = buf.readVarIntArray();
        if (type == OrderType.MOVE) {
            return move(ids, buf.readDouble(), buf.readDouble(), buf.readDouble());
        }
        return attack(ids, buf.readVarInt());
    }

    public static void handle(UnitOrderPacket packet, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null || player.level() == null) {
                return;
            }

            LivingEntity attackTarget = null;
            if (packet.type == OrderType.ATTACK) {
                Entity e = player.level().getEntity(packet.targetId);
                if (e instanceof LivingEntity living) {
                    attackTarget = living;
                } else {
                    return;
                }
            }

            // Небольшое смещение в формации
            int index = 0;
            int side = (int) Math.ceil(Math.sqrt(packet.unitIds.length));

            for (int id : packet.unitIds) {
                Entity e = player.level().getEntity(id);
                if (!(e instanceof RaUnit unit) || !unit.isAlive()) {
                    continue;
                }
                // Только свои юниты
                if (!unit.isOwnedBy(player)) {
                    continue;
                }

                if (packet.type == OrderType.MOVE) {
                    unit.setTarget(null);
                    int row = index / side;
                    int col = index % side;
                    double ox = (col - side / 2.0) * 1.4;
                    double oz = (row - side / 2.0) * 1.4;
                    double tx = packet.x + ox;
                    double tz = packet.z + oz;
                    PathNavigation nav = unit.getNavigation();
                    nav.moveTo(tx, packet.y, tz, 1.15);
                    unit.setOrderedMove(tx, packet.y, tz);
                } else if (attackTarget != null && unit.canAttackTarget(attackTarget)) {
                    unit.setTarget(attackTarget);
                    unit.clearOrderedMove();
                    unit.getNavigation().moveTo(attackTarget, 1.15);
                }
                index++;
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
