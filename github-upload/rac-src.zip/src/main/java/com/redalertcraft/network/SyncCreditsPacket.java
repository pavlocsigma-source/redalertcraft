package com.redalertcraft.network;

import com.redalertcraft.capability.ModCapabilities;
import net.minecraft.client.Minecraft;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Синхронизация баланса кредитов с сервера на клиент (для HUD).
 */
public class SyncCreditsPacket {

    private final int credits;

    public SyncCreditsPacket(int credits) {
        this.credits = credits;
    }

    public static void encode(SyncCreditsPacket packet, FriendlyByteBuf buf) {
        buf.writeVarInt(packet.credits);
    }

    public static SyncCreditsPacket decode(FriendlyByteBuf buf) {
        return new SyncCreditsPacket(buf.readVarInt());
    }

    public static void handle(SyncCreditsPacket packet, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> {
                    var player = Minecraft.getInstance().player;
                    if (player != null) {
                        player.getCapability(ModCapabilities.PLAYER_RESOURCES).ifPresent(res ->
                                res.setCredits(packet.credits));
                    }
                })
        );
        ctx.get().setPacketHandled(true);
    }
}
