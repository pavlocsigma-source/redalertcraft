package com.redalertcraft.network;

import com.redalertcraft.client.lobby.ClientLobbyState;
import com.redalertcraft.match.LobbyPlayerSlot;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class LobbySyncPacket {

    private final String roomCode;
    private final boolean lobbyOpen;
    private final boolean matchActive;
    private final String mapId;
    private final List<LobbyPlayerSlot> slots;

    public LobbySyncPacket(String roomCode, boolean lobbyOpen, boolean matchActive, String mapId, List<LobbyPlayerSlot> slots) {
        this.roomCode = roomCode;
        this.lobbyOpen = lobbyOpen;
        this.matchActive = matchActive;
        this.mapId = mapId;
        this.slots = slots;
    }

    public static void encode(LobbySyncPacket packet, FriendlyByteBuf buf) {
        buf.writeUtf(packet.roomCode, 8);
        buf.writeBoolean(packet.lobbyOpen);
        buf.writeBoolean(packet.matchActive);
        buf.writeUtf(packet.mapId != null ? packet.mapId : "moscow", 32);
        buf.writeVarInt(packet.slots.size());
        for (LobbyPlayerSlot s : packet.slots) {
            s.write(buf);
        }
    }

    public static LobbySyncPacket decode(FriendlyByteBuf buf) {
        String code = buf.readUtf(8);
        boolean open = buf.readBoolean();
        boolean match = buf.readBoolean();
        String mapId = buf.readUtf(32);
        int n = buf.readVarInt();
        List<LobbyPlayerSlot> slots = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            slots.add(LobbyPlayerSlot.read(buf));
        }
        return new LobbySyncPacket(code, open, match, mapId, slots);
    }

    public static void handle(LobbySyncPacket packet, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                        ClientLobbyState.apply(packet.roomCode, packet.lobbyOpen, packet.matchActive, packet.mapId, packet.slots))
        );
        ctx.get().setPacketHandled(true);
    }
}
