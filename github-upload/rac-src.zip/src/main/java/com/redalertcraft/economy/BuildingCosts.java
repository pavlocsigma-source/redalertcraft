package com.redalertcraft.economy;

import com.redalertcraft.RedAlertCraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.HashMap;
import java.util.Map;

public final class BuildingCosts {

    private static final Map<ResourceLocation, Integer> COSTS = new HashMap<>();

    static {
        COSTS.put(new ResourceLocation(RedAlertCraft.MOD_ID, "command_center"), 2000);
        COSTS.put(new ResourceLocation(RedAlertCraft.MOD_ID, "power_plant"), 800);
        COSTS.put(new ResourceLocation(RedAlertCraft.MOD_ID, "refinery"), 1500);
        COSTS.put(new ResourceLocation(RedAlertCraft.MOD_ID, "barracks"), 500);
        COSTS.put(new ResourceLocation(RedAlertCraft.MOD_ID, "war_factory"), 1200);
        COSTS.put(new ResourceLocation(RedAlertCraft.MOD_ID, "airbase"), 1500);
    }

    public static int getCost(Block block) {
        ResourceLocation id = ForgeRegistries.BLOCKS.getKey(block);
        return id == null ? 0 : COSTS.getOrDefault(id, 0);
    }

    public static boolean hasCost(Block block) {
        ResourceLocation id = ForgeRegistries.BLOCKS.getKey(block);
        return id != null && COSTS.containsKey(id);
    }

    private BuildingCosts() {}
}
