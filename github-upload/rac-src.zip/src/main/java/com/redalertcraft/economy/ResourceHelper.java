package com.redalertcraft.economy;

import com.redalertcraft.capability.ModCapabilities;
import com.redalertcraft.capability.PlayerResources;
import com.redalertcraft.network.ModNetwork;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

import java.util.Optional;

/**
 * Удобные методы работы с кредитами + авто-синхронизация на клиент.
 */
public final class ResourceHelper {

    public static Optional<PlayerResources> get(Player player) {
        return player.getCapability(ModCapabilities.PLAYER_RESOURCES).resolve();
    }

    public static void sync(Player player) {
        if (player instanceof ServerPlayer serverPlayer) {
            get(serverPlayer).ifPresent(res ->
                    ModNetwork.sendCreditsToPlayer(serverPlayer, res.getCredits()));
        }
    }

    public static boolean trySpend(Player player, int amount) {
        Optional<PlayerResources> opt = get(player);
        if (opt.isEmpty()) {
            return false;
        }
        boolean ok = opt.get().trySpend(amount);
        if (ok) {
            sync(player);
        }
        return ok;
    }

    public static void addCredits(Player player, int amount) {
        get(player).ifPresent(res -> {
            res.addCredits(amount);
            sync(player);
        });
    }

    public static void setCredits(Player player, int amount) {
        get(player).ifPresent(res -> {
            res.setCredits(amount);
            sync(player);
        });
    }

    private ResourceHelper() {
    }
}
