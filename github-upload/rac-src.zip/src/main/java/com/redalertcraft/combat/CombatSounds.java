package com.redalertcraft.combat;

import com.redalertcraft.entity.AircraftUnit;
import com.redalertcraft.entity.InfantryUnit;
import com.redalertcraft.entity.RaUnit;
import com.redalertcraft.entity.TankUnit;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

public final class CombatSounds {

    private CombatSounds() {}

    public static void playShoot(ServerLevel level, RaUnit unit) {
        double x = unit.getX();
        double y = unit.getY() + unit.getBbHeight() * 0.6;
        double z = unit.getZ();

        if (unit instanceof TankUnit) {
            level.playSound(null, x, y, z, SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 0.7f, 1.35f + level.random.nextFloat() * 0.1f);
            level.playSound(null, x, y, z, SoundEvents.IRON_GOLEM_ATTACK, SoundSource.HOSTILE, 0.9f, 0.55f + level.random.nextFloat() * 0.1f);
            level.playSound(null, x, y, z, SoundEvents.ANVIL_PLACE, SoundSource.HOSTILE, 0.35f, 0.5f);
            level.playSound(null, x, y, z, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.HOSTILE, 0.15f, 1.8f);
        } else if (unit instanceof AircraftUnit) {
            level.playSound(null, x, y, z, SoundEvents.FIREWORK_ROCKET_BLAST, SoundSource.HOSTILE, 0.85f, 0.95f + level.random.nextFloat() * 0.2f);
            level.playSound(null, x, y, z, SoundEvents.FIREWORK_ROCKET_LAUNCH, SoundSource.HOSTILE, 0.55f, 1.2f);
            level.playSound(null, x, y, z, SoundEvents.BLAZE_SHOOT, SoundSource.HOSTILE, 0.4f, 1.4f);
        } else if (unit instanceof InfantryUnit) {
            float basePitch = 1.55f + level.random.nextFloat() * 0.2f;
            level.playSound(null, x, y, z, SoundEvents.FIREWORK_ROCKET_BLAST, SoundSource.HOSTILE, 0.4f, basePitch);
            level.playSound(null, x, y, z, SoundEvents.FIREWORK_ROCKET_BLAST, SoundSource.HOSTILE, 0.28f, basePitch + 0.12f);
            level.playSound(null, x, y, z, SoundEvents.DISPENSER_FAIL, SoundSource.HOSTILE, 0.35f, 1.7f);
            level.playSound(null, x, y, z, SoundEvents.IRON_DOOR_CLOSE, SoundSource.HOSTILE, 0.2f, 1.8f);
        } else {
            level.playSound(null, x, y, z, SoundEvents.FIREWORK_ROCKET_BLAST, SoundSource.HOSTILE, 0.5f, 1.3f);
        }
    }

    public static void playHit(ServerLevel level, Entity target) {
        double x = target.getX();
        double y = target.getY() + target.getBbHeight() * 0.5;
        double z = target.getZ();
        if (target instanceof TankUnit || target instanceof AircraftUnit) {
            level.playSound(null, x, y, z, SoundEvents.SHIELD_BLOCK, SoundSource.HOSTILE, 0.7f, 0.7f + level.random.nextFloat() * 0.2f);
            level.playSound(null, x, y, z, SoundEvents.ANVIL_LAND, SoundSource.HOSTILE, 0.3f, 1.4f);
            level.playSound(null, x, y, z, SoundEvents.IRON_GOLEM_HURT, SoundSource.HOSTILE, 0.35f, 1.2f);
        } else {
            level.playSound(null, x, y, z, SoundEvents.PLAYER_HURT, SoundSource.HOSTILE, 0.55f, 0.95f + level.random.nextFloat() * 0.15f);
            if (level.random.nextFloat() < 0.4f) {
                level.playSound(null, x, y, z, SoundEvents.PLAYER_ATTACK_CRIT, SoundSource.HOSTILE, 0.35f, 1.1f);
            }
        }
    }

    public static void playBuildingHit(ServerLevel level, BlockPos pos, boolean heavy) {
        if (heavy) {
            level.playSound(null, pos, SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, 0.4f, 1.4f);
            level.playSound(null, pos, SoundEvents.ANVIL_LAND, SoundSource.BLOCKS, 0.5f, 0.65f);
            level.playSound(null, pos, SoundEvents.GILDED_BLACKSTONE_BREAK, SoundSource.BLOCKS, 0.6f, 0.8f);
        } else {
            level.playSound(null, pos, SoundEvents.ZOMBIE_ATTACK_IRON_DOOR, SoundSource.BLOCKS, 0.45f, 1.0f + level.random.nextFloat() * 0.2f);
            level.playSound(null, pos, SoundEvents.STONE_HIT, SoundSource.BLOCKS, 0.7f, 0.75f);
            level.playSound(null, pos, SoundEvents.NETHER_BRICKS_BREAK, SoundSource.BLOCKS, 0.35f, 1.1f);
        }
    }

    public static void playExplosion(ServerLevel level, BlockPos pos, float power) {
        float vol = Math.min(2.2f, 0.9f + power * 0.5f);
        level.playSound(null, pos, SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, vol, 0.8f + level.random.nextFloat() * 0.12f);
        level.playSound(null, pos, SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.BLOCKS, 0.55f * power, 0.55f);
        level.playSound(null, pos, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.BLOCKS, 0.25f * power, 1.4f);
        level.playSound(null, pos, SoundEvents.GILDED_BLACKSTONE_BREAK, SoundSource.BLOCKS, 0.9f, 0.65f);
        level.playSound(null, pos, SoundEvents.STONE_BREAK, SoundSource.BLOCKS, 0.7f, 0.7f);
        if (power >= 1.5f) {
            level.playSound(null, pos, SoundEvents.ENDER_DRAGON_GROWL, SoundSource.BLOCKS, 0.3f, 1.6f);
        }
    }

    public static void playBigExplosion(ServerLevel level, Vec3 pos) {
        BlockPos bp = BlockPos.containing(pos);
        playExplosion(level, bp, 2.2f);
        level.playSound(null, bp, SoundEvents.WARDEN_SONIC_BOOM, SoundSource.BLOCKS, 0.45f, 0.55f);
        level.playSound(null, bp, SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, 1.5f, 0.55f);
    }

    public static void playAssault(ServerLevel level, BlockPos pos) {
        level.playSound(null, pos, SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 0.65f, 0.95f + level.random.nextFloat() * 0.2f);
        level.playSound(null, pos, SoundEvents.SHIELD_BLOCK, SoundSource.PLAYERS, 0.45f, 0.85f);
        level.playSound(null, pos, SoundEvents.ZOMBIE_ATTACK_WOODEN_DOOR, SoundSource.PLAYERS, 0.35f, 1.2f);
    }
}
