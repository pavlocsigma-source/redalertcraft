package com.redalertcraft.capability;

import com.redalertcraft.faction.PlayerFactionData;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;

public final class ModCapabilities {

    public static final Capability<PlayerResources> PLAYER_RESOURCES =
            CapabilityManager.get(new CapabilityToken<>() {});

    public static final Capability<PlayerFactionData> PLAYER_FACTION =
            CapabilityManager.get(new CapabilityToken<>() {});

    private ModCapabilities() {
    }
}
