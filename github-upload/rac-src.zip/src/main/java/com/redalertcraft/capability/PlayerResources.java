package com.redalertcraft.capability;

import net.minecraft.nbt.CompoundTag;

/**
 * Экономика игрока: кредиты (основная валюта, как в Red Alert).
 */
public class PlayerResources {

    public static final int DEFAULT_STARTING_CREDITS = 5000;
    public static final int MAX_CREDITS = 999_999;

    private int credits = DEFAULT_STARTING_CREDITS;

    public int getCredits() {
        return credits;
    }

    public void setCredits(int value) {
        this.credits = Math.max(0, Math.min(MAX_CREDITS, value));
    }

    public void addCredits(int amount) {
        if (amount > 0) {
            setCredits(credits + amount);
        }
    }

    /**
     * Пытается списать кредиты. Возвращает true, если хватило средств.
     */
    public boolean trySpend(int amount) {
        if (amount < 0) {
            return false;
        }
        if (credits >= amount) {
            credits -= amount;
            return true;
        }
        return false;
    }

    public boolean canAfford(int amount) {
        return credits >= amount;
    }

    public void copyFrom(PlayerResources other) {
        this.credits = other.credits;
    }

    public void saveNBT(CompoundTag tag) {
        tag.putInt("Credits", credits);
    }

    public void loadNBT(CompoundTag tag) {
        if (tag.contains("Credits")) {
            credits = tag.getInt("Credits");
        }
    }
}
