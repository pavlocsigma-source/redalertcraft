package com.redalertcraft.event;

import com.redalertcraft.RedAlertCraft;
import com.redalertcraft.entity.RaUnit;
import com.redalertcraft.entity.VeteranRank;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Опыт и ранги ветеранов за убийства.
 */
@Mod.EventBusSubscriber(modid = RedAlertCraft.MOD_ID)
public final class VeteranEvents {

    @SubscribeEvent
    public static void onKill(LivingDeathEvent event) {
        LivingEntity dead = event.getEntity();
        if (!(event.getSource().getEntity() instanceof RaUnit killer)) {
            return;
        }
        if (killer.level().isClientSide) {
            return;
        }

        killer.addVeteranKill();
        VeteranRank rank = killer.getVeteranRank();
        // Применяем бонусы ранга к атрибутам (мягко)
        if (killer.getAttribute(Attributes.ATTACK_DAMAGE) != null) {
            double base = killer instanceof com.redalertcraft.entity.TankUnit ? 10.0
                    : killer instanceof com.redalertcraft.entity.AircraftUnit ? 8.0 : 4.0;
            killer.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(base * rank.damageMult);
        }

        Player owner = killer.getOwner();
        if (owner != null && (killer.getVeteranKills() == rank.minKills && rank != VeteranRank.RECRUIT)) {
            owner.displayClientMessage(
                    Component.translatable("message.redalertcraft.unit_promoted",
                            killer.getUnitDisplayName(), rank.getDisplayName()),
                    true
            );
        }
    }

    private VeteranEvents() {
    }
}
