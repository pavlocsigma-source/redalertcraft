package com.redalertcraft.event;

import com.redalertcraft.RedAlertCraft;
import com.redalertcraft.capability.ModCapabilities;
import com.redalertcraft.capability.PlayerFactionProvider;
import com.redalertcraft.capability.PlayerResources;
import com.redalertcraft.capability.PlayerResourcesProvider;
import com.redalertcraft.economy.ResourceHelper;
import com.redalertcraft.faction.PlayerFactionData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

public final class ModEvents {

    private static final ResourceLocation PLAYER_RESOURCES_ID =
            new ResourceLocation(RedAlertCraft.MOD_ID, "player_resources");
    private static final ResourceLocation PLAYER_FACTION_ID =
            new ResourceLocation(RedAlertCraft.MOD_ID, "player_faction");

    @Mod.EventBusSubscriber(modid = RedAlertCraft.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static class ModBusEvents {
        @SubscribeEvent
        public static void onRegisterCapabilities(RegisterCapabilitiesEvent event) {
            event.register(PlayerResources.class);
            event.register(PlayerFactionData.class);
        }
    }

    @Mod.EventBusSubscriber(modid = RedAlertCraft.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static class ForgeBusEvents {
        @SubscribeEvent
        public static void onAttachCapabilities(AttachCapabilitiesEvent<Entity> event) {
            if (event.getObject() instanceof Player) {
                if (!event.getObject().getCapability(ModCapabilities.PLAYER_RESOURCES).isPresent()) {
                    event.addCapability(PLAYER_RESOURCES_ID, new PlayerResourcesProvider());
                }
                if (!event.getObject().getCapability(ModCapabilities.PLAYER_FACTION).isPresent()) {
                    event.addCapability(PLAYER_FACTION_ID, new PlayerFactionProvider());
                }
            }
        }

        @SubscribeEvent
        public static void onPlayerClone(PlayerEvent.Clone event) {
            event.getOriginal().reviveCaps();
            event.getOriginal().getCapability(ModCapabilities.PLAYER_RESOURCES).ifPresent(oldCap ->
                    event.getEntity().getCapability(ModCapabilities.PLAYER_RESOURCES).ifPresent(newCap ->
                            newCap.copyFrom(oldCap)));
            event.getOriginal().getCapability(ModCapabilities.PLAYER_FACTION).ifPresent(oldCap ->
                    event.getEntity().getCapability(ModCapabilities.PLAYER_FACTION).ifPresent(newCap ->
                            newCap.copyFrom(oldCap)));
            event.getOriginal().invalidateCaps();
        }

        @SubscribeEvent
        public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
            ResourceHelper.sync(event.getEntity());
        }

        @SubscribeEvent
        public static void onPlayerRespawn(PlayerEvent.PlayerRespawnEvent event) {
            ResourceHelper.sync(event.getEntity());
        }

        @SubscribeEvent
        public static void onPlayerChangeDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
            ResourceHelper.sync(event.getEntity());
        }
    }

    private ModEvents() {
    }
}
