package com.redalertcraft.event;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.redalertcraft.RedAlertCraft;
import com.redalertcraft.ai.AiCommander;
import com.redalertcraft.ai.AiDifficulty;
import com.redalertcraft.ai.AiManager;
import com.redalertcraft.capability.ModCapabilities;
import com.redalertcraft.capability.PlayerResources;
import com.redalertcraft.economy.ResourceHelper;
import com.redalertcraft.faction.Faction;
import com.redalertcraft.building.BuildingManager;
import com.redalertcraft.entity.InfantryUnit;
import com.redalertcraft.map.MapGenerator;
import com.redalertcraft.map.RaMap;
import com.redalertcraft.map.RaMaps;
import com.redalertcraft.match.MatchManager;
import com.redalertcraft.superweapon.SuperweaponHandler;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.coordinates.BlockPosArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Arrays;
import java.util.Locale;
import java.util.stream.Stream;

@Mod.EventBusSubscriber(modid = RedAlertCraft.MOD_ID)
public final class ModCommands {

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> d = event.getDispatcher();

        d.register(Commands.literal("rac")
                .then(Commands.literal("credits")
                        .executes(ctx -> showCredits(ctx.getSource()))
                        .then(Commands.literal("set").requires(s -> s.hasPermission(2))
                                .then(Commands.argument("amount", IntegerArgumentType.integer(0, PlayerResources.MAX_CREDITS))
                                        .executes(ctx -> setCredits(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "amount")))))
                        .then(Commands.literal("add").requires(s -> s.hasPermission(2))
                                .then(Commands.argument("amount", IntegerArgumentType.integer())
                                        .executes(ctx -> addCredits(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "amount"))))))
                .then(Commands.literal("ai").requires(s -> s.hasPermission(2))
                        .then(Commands.literal("spawn")
                                .executes(ctx -> spawnAi(ctx.getSource(), AiDifficulty.MEDIUM))
                                .then(Commands.argument("difficulty", StringArgumentType.word())
                                        .suggests((c, b) -> SharedSuggestionProvider.suggest(Arrays.stream(AiDifficulty.values()).map(x -> x.id), b))
                                        .executes(ctx -> spawnAi(ctx.getSource(), AiDifficulty.byName(StringArgumentType.getString(ctx, "difficulty"))))))
                        .then(Commands.literal("list").executes(ctx -> listAi(ctx.getSource())))
                        .then(Commands.literal("remove").executes(ctx -> removeAi(ctx.getSource()))))
                .then(Commands.literal("faction")
                        .executes(ctx -> showFaction(ctx.getSource()))
                        .then(Commands.argument("name", StringArgumentType.word())
                                .suggests((c, b) -> SharedSuggestionProvider.suggest(Stream.of("soviet", "allies", "empire"), b))
                                .executes(ctx -> setFaction(ctx.getSource(), StringArgumentType.getString(ctx, "name")))))
                .then(Commands.literal("team")
                        .then(Commands.argument("id", IntegerArgumentType.integer(1, 3))
                                .executes(ctx -> setTeam(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "id")))))
                .then(Commands.literal("superweapon")
                        .executes(ctx -> fireSuperweapon(ctx.getSource(), null))
                        .then(Commands.argument("pos", BlockPosArgument.blockPos())
                                .executes(ctx -> fireSuperweapon(ctx.getSource(), BlockPosArgument.getBlockPos(ctx, "pos")))))
                .then(Commands.literal("lobby")
                        .executes(ctx -> openLobbyCmd(ctx.getSource()))
                        .then(Commands.literal("join").executes(ctx -> joinLobbyCmd(ctx.getSource()))))
                .then(Commands.literal("garrison")
                        .executes(ctx -> garrisonNearest(ctx.getSource())))
                .then(Commands.literal("map")
                        .then(Commands.literal("generate")
                                .requires(s -> s.hasPermission(2))
                                .executes(ctx -> generateMap(ctx.getSource()))
                                .then(Commands.argument("name", StringArgumentType.word())
                                        .suggests((c, b) -> SharedSuggestionProvider.suggest(
                                                RaMaps.all().stream().map(m -> m.getId()), b))
                                        .executes(ctx -> generateMapNamed(ctx.getSource(),
                                                StringArgumentType.getString(ctx, "name"))))))
                .then(Commands.literal("match").requires(s -> s.hasPermission(2))
                        .then(Commands.literal("start").executes(ctx -> startMatch(ctx.getSource())))
                        .then(Commands.literal("status").executes(ctx -> matchStatus(ctx.getSource()))))
        );
    }

    private static int showCredits(CommandSourceStack source) {
        ServerPlayer p = source.getPlayer();
        if (p == null) return 0;
        ResourceHelper.get(p).ifPresent(res ->
                source.sendSuccess(() -> Component.translatable("message.redalertcraft.credits_balance", res.getCredits()), false));
        return 1;
    }

    private static int setCredits(CommandSourceStack source, int amount) {
        ServerPlayer p = source.getPlayer();
        if (p == null) return 0;
        ResourceHelper.setCredits(p, amount);
        source.sendSuccess(() -> Component.translatable("message.redalertcraft.credits_set", amount), true);
        return 1;
    }

    private static int addCredits(CommandSourceStack source, int amount) {
        ServerPlayer p = source.getPlayer();
        if (p == null) return 0;
        if (amount >= 0) ResourceHelper.addCredits(p, amount);
        else ResourceHelper.trySpend(p, -amount);
        ResourceHelper.get(p).ifPresent(res ->
                source.sendSuccess(() -> Component.translatable("message.redalertcraft.credits_balance", res.getCredits()), true));
        return 1;
    }

    private static int spawnAi(CommandSourceStack source, AiDifficulty difficulty) {
        ServerPlayer p = source.getPlayer();
        if (p == null) return 0;
        AiCommander c = AiManager.get(p.serverLevel()).spawn(p.serverLevel(), difficulty, p.blockPosition());
        source.sendSuccess(() -> Component.translatable("message.redalertcraft.ai_spawned",
                difficulty.id.toUpperCase(Locale.ROOT), c.getBaseCenter().getX(), c.getBaseCenter().getY(), c.getBaseCenter().getZ()), true);
        return 1;
    }

    private static int listAi(CommandSourceStack source) {
        if (!(source.getLevel() instanceof ServerLevel level)) return 0;
        var list = AiManager.get(level).getCommanders();
        if (list.isEmpty()) {
            source.sendSuccess(() -> Component.translatable("message.redalertcraft.ai_none"), false);
            return 1;
        }
        source.sendSuccess(() -> Component.translatable("message.redalertcraft.ai_list_header", list.size()), false);
        for (AiCommander c : list) {
            source.sendSuccess(() -> Component.literal(String.format("  [%s] credits=%d base=%s",
                    c.getDifficulty().id, c.getCredits(), c.getBaseCenter().toShortString())), false);
        }
        return 1;
    }

    private static int removeAi(CommandSourceStack source) {
        if (!(source.getLevel() instanceof ServerLevel level)) return 0;
        int n = AiManager.get(level).removeAll();
        source.sendSuccess(() -> Component.translatable("message.redalertcraft.ai_removed", n), true);
        return 1;
    }

    private static int showFaction(CommandSourceStack source) {
        ServerPlayer p = source.getPlayer();
        if (p == null) return 0;
        p.getCapability(ModCapabilities.PLAYER_FACTION).ifPresent(data ->
                source.sendSuccess(() -> Component.translatable("message.redalertcraft.faction_current",
                        data.getFaction().getDisplayName(), data.getTeam()), false));
        return 1;
    }

    private static int setFaction(CommandSourceStack source, String name) {
        ServerPlayer p = source.getPlayer();
        if (p == null) return 0;
        Faction f = Faction.byId(name);
        p.getCapability(ModCapabilities.PLAYER_FACTION).ifPresent(data -> {
            data.setFaction(f);
            source.sendSuccess(() -> Component.translatable("message.redalertcraft.faction_set", f.getDisplayName()), true);
        });
        return 1;
    }

    private static int setTeam(CommandSourceStack source, int team) {
        ServerPlayer p = source.getPlayer();
        if (p == null) return 0;
        p.getCapability(ModCapabilities.PLAYER_FACTION).ifPresent(data -> data.setTeam(team));
        MatchManager.setTeam(p.getUUID(), team);
        source.sendSuccess(() -> Component.translatable("message.redalertcraft.team_set", team), true);
        return 1;
    }

    private static int fireSuperweapon(CommandSourceStack source, BlockPos pos) {
        ServerPlayer p = source.getPlayer();
        if (p == null) return 0;
        if (pos == null) pos = p.blockPosition().offset(0, 0, 16);
        boolean ok = SuperweaponHandler.tryActivate(p, pos);
        return ok ? 1 : 0;
    }


    private static int openLobbyCmd(CommandSourceStack source) {
        ServerPlayer p = source.getPlayer();
        if (p == null) return 0;
        MatchManager.openLobby(p);
        return 1;
    }

    private static int joinLobbyCmd(CommandSourceStack source) {
        ServerPlayer p = source.getPlayer();
        if (p == null) return 0;
        MatchManager.joinLobby(p);
        return 1;
    }

    private static int startMatch(CommandSourceStack source) {
        if (!(source.getLevel() instanceof ServerLevel level)) return 0;
        boolean ok = MatchManager.startMatch(level);
        if (ok) {
            source.sendSuccess(() -> Component.translatable("message.redalertcraft.match_started", MatchManager.getRoomCode()), true);
        }
        return ok ? 1 : 0;
    }

    private static int matchStatus(CommandSourceStack source) {
        source.sendSuccess(() -> Component.literal("Match active: " + MatchManager.isMatchActive()
                + " code=" + MatchManager.getRoomCode()), false);
        return 1;
    }

    private ModCommands() {}
}
