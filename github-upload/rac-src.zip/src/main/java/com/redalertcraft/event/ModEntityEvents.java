package com.redalertcraft.event;

import com.redalertcraft.RedAlertCraft;
import com.redalertcraft.entity.AircraftUnit;
import com.redalertcraft.entity.InfantryUnit;
import com.redalertcraft.entity.TankUnit;
import com.redalertcraft.registry.ModEntities;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = RedAlertCraft.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModEntityEvents {

    @SubscribeEvent
    public static void onAttributeCreate(EntityAttributeCreationEvent event) {
        event.put(ModEntities.INFANTRY.get(), InfantryUnit.createAttributes().build());
        event.put(ModEntities.TANK.get(), TankUnit.createAttributes().build());
        event.put(ModEntities.AIRCRAFT.get(), AircraftUnit.createAttributes().build());
    }

    private ModEntityEvents() {
    }
}
