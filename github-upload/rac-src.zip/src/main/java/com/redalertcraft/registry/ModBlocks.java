package com.redalertcraft.registry;

import com.redalertcraft.RedAlertCraft;
import com.redalertcraft.block.*;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {

    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, RedAlertCraft.MOD_ID);

    public static final RegistryObject<Block> COMMAND_CENTER = BLOCKS.register("command_center",
            () -> new CommandCenterBlock(BlockBehaviour.Properties.of().mapColor(MapColor.METAL)
                    .strength(5.0f, 1200.0f).requiresCorrectToolForDrops().sound(SoundType.METAL).noOcclusion()));

    public static final RegistryObject<Block> POWER_PLANT = BLOCKS.register("power_plant",
            () -> new PowerPlantBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_YELLOW)
                    .strength(3.5f, 600.0f).requiresCorrectToolForDrops().sound(SoundType.METAL).noOcclusion()));

    public static final RegistryObject<Block> REFINERY = BLOCKS.register("refinery",
            () -> new RefineryBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_ORANGE)
                    .strength(4.0f, 800.0f).requiresCorrectToolForDrops().sound(SoundType.METAL).noOcclusion()));

    public static final RegistryObject<Block> BARRACKS = BLOCKS.register("barracks",
            () -> new BarracksBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BROWN)
                    .strength(3.5f, 600.0f).requiresCorrectToolForDrops().sound(SoundType.WOOD).noOcclusion()));

    public static final RegistryObject<Block> WAR_FACTORY = BLOCKS.register("war_factory",
            () -> new WarFactoryBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GRAY)
                    .strength(4.5f, 900.0f).requiresCorrectToolForDrops().sound(SoundType.METAL).noOcclusion()));

    public static final RegistryObject<Block> AIRBASE = BLOCKS.register("airbase",
            () -> new AirbaseBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_LIGHT_BLUE)
                    .strength(4.0f, 700.0f).requiresCorrectToolForDrops().sound(SoundType.METAL).noOcclusion()));

    public static final RegistryObject<Block> ORE_DEPOSIT = BLOCKS.register("ore_deposit",
            () -> new OreDepositBlock(BlockBehaviour.Properties.of().mapColor(MapColor.GOLD)
                    .strength(2.0f, 6.0f).sound(SoundType.STONE).randomTicks()));

    public static final RegistryObject<Block> OIL_DERRICK = BLOCKS.register("oil_derrick",
            () -> new OilDerrickBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK)
                    .strength(3.0f, 300.0f).sound(SoundType.METAL).randomTicks()));

    private ModBlocks() {}
}
