package com.redalertcraft.registry;

import com.redalertcraft.RedAlertCraft;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModCreativeTabs {

    public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, RedAlertCraft.MOD_ID);

    public static final RegistryObject<CreativeModeTab> MAIN_TAB = CREATIVE_MODE_TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.redalertcraft"))
                    .icon(() -> new ItemStack(ModItems.COMMAND_CENTER.get()))
                    .displayItems((params, output) -> {
                        output.accept(ModItems.COMMAND_CENTER.get());
                        output.accept(ModItems.POWER_PLANT.get());
                        output.accept(ModItems.REFINERY.get());
                        output.accept(ModItems.BARRACKS.get());
                        output.accept(ModItems.WAR_FACTORY.get());
                        output.accept(ModItems.AIRBASE.get());
                        output.accept(ModItems.ORE_DEPOSIT.get());
                        output.accept(ModItems.OIL_DERRICK.get());
                        output.accept(ModItems.INFANTRY_SPAWN_EGG.get());
                        output.accept(ModItems.TANK_SPAWN_EGG.get());
                        output.accept(ModItems.AIRCRAFT_SPAWN_EGG.get());
                    })
                    .build());

    private ModCreativeTabs() {}
}
