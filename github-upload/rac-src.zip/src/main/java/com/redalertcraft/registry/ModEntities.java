package com.redalertcraft.registry;

import com.redalertcraft.RedAlertCraft;
import com.redalertcraft.entity.AircraftUnit;
import com.redalertcraft.entity.InfantryUnit;
import com.redalertcraft.entity.TankUnit;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, RedAlertCraft.MOD_ID);

    public static final RegistryObject<EntityType<InfantryUnit>> INFANTRY = ENTITIES.register("infantry",
            () -> EntityType.Builder.of(InfantryUnit::new, MobCategory.CREATURE)
                    .sized(0.6f, 1.8f)
                    .clientTrackingRange(10)
                    .build(new ResourceLocation(RedAlertCraft.MOD_ID, "infantry").toString()));

    public static final RegistryObject<EntityType<TankUnit>> TANK = ENTITIES.register("tank",
            () -> EntityType.Builder.of(TankUnit::new, MobCategory.CREATURE)
                    .sized(1.6f, 1.2f)
                    .clientTrackingRange(10)
                    .fireImmune()
                    .build(new ResourceLocation(RedAlertCraft.MOD_ID, "tank").toString()));

    public static final RegistryObject<EntityType<AircraftUnit>> AIRCRAFT = ENTITIES.register("aircraft",
            () -> EntityType.Builder.of(AircraftUnit::new, MobCategory.CREATURE)
                    .sized(1.4f, 0.6f)
                    .clientTrackingRange(12)
                    .fireImmune()
                    .build(new ResourceLocation(RedAlertCraft.MOD_ID, "aircraft").toString()));

    private ModEntities() {
    }
}
