package com.redalertcraft.registry;

import com.redalertcraft.RedAlertCraft;
import com.redalertcraft.item.BuildingBlockItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, RedAlertCraft.MOD_ID);

    public static final RegistryObject<Item> COMMAND_CENTER = ITEMS.register("command_center",
            () -> new BuildingBlockItem(ModBlocks.COMMAND_CENTER.get(), new Item.Properties()));
    public static final RegistryObject<Item> POWER_PLANT = ITEMS.register("power_plant",
            () -> new BuildingBlockItem(ModBlocks.POWER_PLANT.get(), new Item.Properties()));
    public static final RegistryObject<Item> REFINERY = ITEMS.register("refinery",
            () -> new BuildingBlockItem(ModBlocks.REFINERY.get(), new Item.Properties()));
    public static final RegistryObject<Item> BARRACKS = ITEMS.register("barracks",
            () -> new BuildingBlockItem(ModBlocks.BARRACKS.get(), new Item.Properties()));
    public static final RegistryObject<Item> WAR_FACTORY = ITEMS.register("war_factory",
            () -> new BuildingBlockItem(ModBlocks.WAR_FACTORY.get(), new Item.Properties()));
    public static final RegistryObject<Item> AIRBASE = ITEMS.register("airbase",
            () -> new BuildingBlockItem(ModBlocks.AIRBASE.get(), new Item.Properties()));
    public static final RegistryObject<Item> ORE_DEPOSIT = ITEMS.register("ore_deposit",
            () -> new BlockItem(ModBlocks.ORE_DEPOSIT.get(), new Item.Properties()));
    public static final RegistryObject<Item> OIL_DERRICK = ITEMS.register("oil_derrick",
            () -> new BlockItem(ModBlocks.OIL_DERRICK.get(), new Item.Properties()));

    public static final RegistryObject<Item> INFANTRY_SPAWN_EGG = ITEMS.register("infantry_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.INFANTRY, 0x3B5F2A, 0xC4A35A, new Item.Properties()));
    public static final RegistryObject<Item> TANK_SPAWN_EGG = ITEMS.register("tank_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.TANK, 0x4A4A4A, 0x8B0000, new Item.Properties()));
    public static final RegistryObject<Item> AIRCRAFT_SPAWN_EGG = ITEMS.register("aircraft_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.AIRCRAFT, 0x87CEEB, 0x1E90FF, new Item.Properties()));

    private ModItems() {}
}
