package com.redalertcraft.item;

import com.redalertcraft.economy.BuildingCosts;
import com.redalertcraft.economy.ResourceHelper;
import com.redalertcraft.capability.ModCapabilities;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.block.Block;

/**
 * BlockItem с оплатой кредитами при установке.
 * В креативе и при cost == 0 оплата не требуется.
 */
public class BuildingBlockItem extends BlockItem {

    public BuildingBlockItem(Block block, Properties properties) {
        super(block, properties);
    }

    @Override
    public InteractionResult place(BlockPlaceContext context) {
        Player player = context.getPlayer();
        Block block = getBlock();
        int cost = BuildingCosts.getCost(block);

        if (player != null && !player.getAbilities().instabuild && cost > 0) {
            var resources = ResourceHelper.get(player).orElse(null);
            if (resources == null) {
                return InteractionResult.FAIL;
            }

            if (!resources.canAfford(cost)) {
                if (!context.getLevel().isClientSide) {
                    player.displayClientMessage(
                            Component.translatable("message.redalertcraft.not_enough_credits", cost, resources.getCredits()),
                            true
                    );
                }
                return InteractionResult.FAIL;
            }

            InteractionResult result = super.place(context);
            if (result.consumesAction() && !context.getLevel().isClientSide) {
                ResourceHelper.trySpend(player, cost);
                ResourceHelper.get(player).ifPresent(res ->
                        player.displayClientMessage(
                                Component.translatable("message.redalertcraft.building_placed", cost, res.getCredits()),
                                true
                        ));
            }
            return result;
        }

        return super.place(context);
    }

    @Override
    public void appendHoverText(ItemStack stack, net.minecraft.world.level.Level level,
                                java.util.List<Component> tooltip, net.minecraft.world.item.TooltipFlag flag) {
        super.appendHoverText(stack, level, tooltip, flag);
        int cost = BuildingCosts.getCost(getBlock());
        if (cost > 0) {
            tooltip.add(Component.translatable("tooltip.redalertcraft.cost", cost));
        }
    }
}
