package com.redalertcraft.map;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Каталог карт.
 * Названия и сеттинги вдохновлены локациями RA3, контент оригинальный.
 */
public final class RaMaps {

    private static final Map<String, RaMap> BY_ID = new LinkedHashMap<>();

    static {
        // --- Классика / столицы ---
        reg("moscow", "map.redalertcraft.moscow.name", "map.redalertcraft.moscow.desc",
                4, RaMap.MapSize.MEDIUM, RaMap.MapTerrain.URBAN, false, true);
        reg("new_york", "map.redalertcraft.new_york.name", "map.redalertcraft.new_york.desc",
                6, RaMap.MapSize.LARGE, RaMap.MapTerrain.COAST, true, true);
        reg("tokyo_harbor", "map.redalertcraft.tokyo_harbor.name", "map.redalertcraft.tokyo_harbor.desc",
                6, RaMap.MapSize.LARGE, RaMap.MapTerrain.COAST, true, true);
        reg("leningrad", "map.redalertcraft.leningrad.name", "map.redalertcraft.leningrad.desc",
                4, RaMap.MapSize.MEDIUM, RaMap.MapTerrain.SNOW, true, true);
        reg("vladivostok", "map.redalertcraft.vladivostok.name", "map.redalertcraft.vladivostok.desc",
                4, RaMap.MapSize.MEDIUM, RaMap.MapTerrain.COAST, true, true);

        // --- Европа / Средиземноморье ---
        reg("heidelberg", "map.redalertcraft.heidelberg.name", "map.redalertcraft.heidelberg.desc",
                4, RaMap.MapSize.MEDIUM, RaMap.MapTerrain.URBAN, false, true);
        reg("gibraltar", "map.redalertcraft.gibraltar.name", "map.redalertcraft.gibraltar.desc",
                4, RaMap.MapSize.MEDIUM, RaMap.MapTerrain.COAST, true, true);
        reg("mykonos", "map.redalertcraft.mykonos.name", "map.redalertcraft.mykonos.desc",
                4, RaMap.MapSize.SMALL, RaMap.MapTerrain.ISLAND, true, false);
        reg("odessa", "map.redalertcraft.odessa.name", "map.redalertcraft.odessa.desc",
                4, RaMap.MapSize.MEDIUM, RaMap.MapTerrain.COAST, true, true);

        // --- Азия / Тихий океан ---
        reg("pearl_harbor", "map.redalertcraft.pearl_harbor.name", "map.redalertcraft.pearl_harbor.desc",
                6, RaMap.MapSize.LARGE, RaMap.MapTerrain.ISLAND, true, true);
        reg("shiroshima", "map.redalertcraft.shiroshima.name", "map.redalertcraft.shiroshima.desc",
                4, RaMap.MapSize.MEDIUM, RaMap.MapTerrain.COAST, true, false);
        reg("hapu", "map.redalertcraft.hapu.name", "map.redalertcraft.hapu.desc",
                2, RaMap.MapSize.SMALL, RaMap.MapTerrain.ISLAND, true, false);
        reg("yokohama", "map.redalertcraft.yokohama.name", "map.redalertcraft.yokohama.desc",
                4, RaMap.MapSize.MEDIUM, RaMap.MapTerrain.INDUSTRIAL, true, true);

        // --- Америка ---
        reg("brighton_beach", "map.redalertcraft.brighton_beach.name", "map.redalertcraft.brighton_beach.desc",
                4, RaMap.MapSize.MEDIUM, RaMap.MapTerrain.URBAN, true, true);
        reg("cape_canaveral", "map.redalertcraft.cape_canaveral.name", "map.redalertcraft.cape_canaveral.desc",
                4, RaMap.MapSize.MEDIUM, RaMap.MapTerrain.COAST, true, true);
        reg("santa_monica", "map.redalertcraft.santa_monica.name", "map.redalertcraft.santa_monica.desc",
                4, RaMap.MapSize.MEDIUM, RaMap.MapTerrain.COAST, true, false);
        reg("yucatan", "map.redalertcraft.yucatan.name", "map.redalertcraft.yucatan.desc",
                6, RaMap.MapSize.LARGE, RaMap.MapTerrain.JUNGLE, true, true);

        // --- Прочее ---
        reg("cuba", "map.redalertcraft.cuba.name", "map.redalertcraft.cuba.desc",
                4, RaMap.MapSize.MEDIUM, RaMap.MapTerrain.ISLAND, true, true);
        reg("egypt", "map.redalertcraft.egypt.name", "map.redalertcraft.egypt.desc",
                4, RaMap.MapSize.MEDIUM, RaMap.MapTerrain.DESERT, false, true);
        reg("iceland", "map.redalertcraft.iceland.name", "map.redalertcraft.iceland.desc",
                2, RaMap.MapSize.SMALL, RaMap.MapTerrain.SNOW, true, false);
        reg("north_sea", "map.redalertcraft.north_sea.name", "map.redalertcraft.north_sea.desc",
                6, RaMap.MapSize.LARGE, RaMap.MapTerrain.COAST, true, true);
        reg("imperial_palace", "map.redalertcraft.imperial_palace.name", "map.redalertcraft.imperial_palace.desc",
                2, RaMap.MapSize.SMALL, RaMap.MapTerrain.URBAN, false, false);
        reg("krasna_polyana", "map.redalertcraft.krasna_polyana.name", "map.redalertcraft.krasna_polyana.desc",
                4, RaMap.MapSize.MEDIUM, RaMap.MapTerrain.SNOW, false, true);
        reg("singapore_harbor", "map.redalertcraft.singapore_harbor.name", "map.redalertcraft.singapore_harbor.desc",
                6, RaMap.MapSize.LARGE, RaMap.MapTerrain.COAST, true, true);
    }

    private static void reg(String id, String nameKey, String descKey, int maxPlayers,
                            RaMap.MapSize size, RaMap.MapTerrain terrain, boolean water, boolean oil) {
        BY_ID.put(id, new RaMap(id, nameKey, descKey, maxPlayers, size, terrain, water, oil));
    }

    public static RaMap get(String id) {
        return BY_ID.getOrDefault(id, BY_ID.get("moscow"));
    }

    public static List<RaMap> all() {
        return Collections.unmodifiableList(new ArrayList<>(BY_ID.values()));
    }

    public static String defaultId() {
        return "moscow";
    }

    private RaMaps() {
    }
}
