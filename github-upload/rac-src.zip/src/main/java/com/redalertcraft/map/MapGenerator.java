package com.redalertcraft.map;

import com.redalertcraft.RedAlertCraft;
import com.redalertcraft.building.BuildingManager;
import com.redalertcraft.building.BuildingType;
import com.redalertcraft.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Строит арену матча в стиле RTS (по мотивам RA3):
 * плоская площадка, тематический ландшафт, вода, нефть, спавны команд.
 */
public final class MapGenerator {

    private MapGenerator() {
    }

    public static GenerationResult generate(ServerLevel level, RaMap map, BlockPos centerHint) {
        int half = switch (map.getSize()) {
            case SMALL -> 48;
            case MEDIUM -> 72;
            case LARGE -> 96;
        };

        // Центр арены: рядом с первым игроком / подсказкой, но на поверхности
        BlockPos center = findFlatCenter(level, centerHint);
        int cy = center.getY();

        TerrainPalette palette = TerrainPalette.forTerrain(map.getTerrain());
        Random rng = new Random(map.getId().hashCode() * 31L + center.asLong());

        RedAlertCraft.LOGGER.info("Генерация карты '{}' size={} center={}", map.getId(), half * 2, center);

        // 1) Очистка и пол
        clearAndFloor(level, center, half, cy, palette, map, rng);

        // 2) Береговая линия / вода
        if (map.hasWater()) {
            placeWater(level, center, half, cy, map, rng);
        }

        // 3) Городские/декоративные объекты
        placeDecor(level, center, half, cy, palette, map, rng);

        // 4) Ресурсы
        placeResources(level, center, half, cy, map, rng);

        // 5) Спавны команд (3 угла + центр для 3-й)
        List<BlockPos> spawns = placeTeamSpawns(level, center, half, cy, palette);

        // 6) Освещение / маркеры границ
        placeBorderMarkers(level, center, half, cy);

        level.getServer().getPlayerList().broadcastSystemMessage(
                Component.literal("§6[RAC] §fКарта «" + map.getName().getString() + "» построена. Размер: "
                        + (half * 2) + "×" + (half * 2)),
                false
        );

        return new GenerationResult(center, half, spawns);
    }

    private static BlockPos findFlatCenter(ServerLevel level, BlockPos hint) {
        int x = hint.getX();
        int z = hint.getZ();
        int y = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, x, z);
        // Чуть поднять над океаном/пещерами
        if (y < 60) y = 70;
        if (y > 120) y = 90;
        return new BlockPos(x, y, z);
    }

    private static void clearAndFloor(ServerLevel level, BlockPos center, int half, int cy,
                                      TerrainPalette palette, RaMap map, Random rng) {
        int minX = center.getX() - half;
        int maxX = center.getX() + half;
        int minZ = center.getZ() - half;
        int maxZ = center.getZ() + half;

        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                // Очистка воздуха над полом (высота арены ~16)
                for (int y = cy + 1; y <= cy + 16; y++) {
                    BlockPos p = new BlockPos(x, y, z);
                    if (!level.getBlockState(p).isAir()) {
                        level.setBlock(p, Blocks.AIR.defaultBlockState(), 2);
                    }
                }
                // Подложка
                for (int y = cy - 3; y < cy; y++) {
                    level.setBlock(new BlockPos(x, y, z), palette.subsoil.defaultBlockState(), 2);
                }
                // Пол с лёгким шумом
                Block floor = palette.floor;
                double n = noise(x, z, rng);
                if (n > 0.85 && palette.floorVariant != null) {
                    floor = palette.floorVariant;
                }
                // Дороги крестом (урбан / промзона)
                if (palette.road != null) {
                    int dx = Math.abs(x - center.getX());
                    int dz = Math.abs(z - center.getZ());
                    if (dx <= 2 || dz <= 2) {
                        floor = palette.road;
                    }
                    // Сетка кварталов
                    if (map.getTerrain() == RaMap.MapTerrain.URBAN || map.getTerrain() == RaMap.MapTerrain.INDUSTRIAL) {
                        if (dx % 24 <= 1 || dz % 24 <= 1) {
                            floor = palette.road;
                        }
                    }
                }
                level.setBlock(new BlockPos(x, cy, z), floor.defaultBlockState(), 2);
            }
        }
    }

    private static void placeWater(ServerLevel level, BlockPos center, int half, int cy, RaMap map, Random rng) {
        // Полоса воды с одной стороны (юг) или кольцо для островов
        if (map.getTerrain() == RaMap.MapTerrain.ISLAND) {
            // Вода по периметру, суша — остров в центре
            int land = half - 12;
            for (int x = center.getX() - half; x <= center.getX() + half; x++) {
                for (int z = center.getZ() - half; z <= center.getZ() + half; z++) {
                    int dx = x - center.getX();
                    int dz = z - center.getZ();
                    if (dx * dx + dz * dz > land * land) {
                        // вода вместо пола
                        level.setBlock(new BlockPos(x, cy, z), Blocks.WATER.defaultBlockState(), 2);
                        level.setBlock(new BlockPos(x, cy - 1, z), Blocks.SAND.defaultBlockState(), 2);
                        // чуть глубже
                        level.setBlock(new BlockPos(x, cy - 2, z), Blocks.SAND.defaultBlockState(), 2);
                    }
                }
            }
        } else {
            // Южная «гавань»: треть карты — вода
            int waterStart = center.getZ() + half / 3;
            for (int x = center.getX() - half; x <= center.getX() + half; x++) {
                for (int z = waterStart; z <= center.getZ() + half; z++) {
                    // берег — песок
                    if (z < waterStart + 3) {
                        level.setBlock(new BlockPos(x, cy, z), Blocks.SAND.defaultBlockState(), 2);
                    } else {
                        level.setBlock(new BlockPos(x, cy, z), Blocks.WATER.defaultBlockState(), 2);
                        level.setBlock(new BlockPos(x, cy - 1, z), Blocks.SAND.defaultBlockState(), 2);
                    }
                }
            }
            // Несколько пирсов
            for (int i = 0; i < 3; i++) {
                int px = center.getX() - half / 2 + i * (half / 2);
                for (int z = waterStart; z < waterStart + 10; z++) {
                    level.setBlock(new BlockPos(px, cy, z), Blocks.SPRUCE_PLANKS.defaultBlockState(), 2);
                    level.setBlock(new BlockPos(px + 1, cy, z), Blocks.SPRUCE_PLANKS.defaultBlockState(), 2);
                }
            }
        }
    }

    private static void placeDecor(ServerLevel level, BlockPos center, int half, int cy,
                                   TerrainPalette palette, RaMap map, Random rng) {
        int buildings = switch (map.getSize()) {
            case SMALL -> 6;
            case MEDIUM -> 12;
            case LARGE -> 20;
        };

        for (int i = 0; i < buildings; i++) {
            int x = center.getX() + rng.nextInt(half * 2) - half;
            int z = center.getZ() + rng.nextInt(half * 2) - half;
            // Не ставим в центр (база) и не на воду
            if (Math.abs(x - center.getX()) < 12 && Math.abs(z - center.getZ()) < 12) continue;
            BlockState ground = level.getBlockState(new BlockPos(x, cy, z));
            if (ground.is(Blocks.WATER)) continue;

            int w = 3 + rng.nextInt(4);
            int d = 3 + rng.nextInt(4);
            int h = 3 + rng.nextInt(5);
            Block wall = palette.building;
            for (int dx = 0; dx < w; dx++) {
                for (int dz = 0; dz < d; dz++) {
                    for (int dy = 1; dy <= h; dy++) {
                        boolean edge = dx == 0 || dz == 0 || dx == w - 1 || dz == d - 1;
                        if (edge || dy == h) {
                            level.setBlock(new BlockPos(x + dx, cy + dy, z + dz), wall.defaultBlockState(), 2);
                        } else if (dy == 1) {
                            level.setBlock(new BlockPos(x + dx, cy + dy, z + dz), Blocks.AIR.defaultBlockState(), 2);
                        }
                    }
                }
            }
        }

        // Снег / листва поверх
        if (map.getTerrain() == RaMap.MapTerrain.SNOW) {
            for (int i = 0; i < half * 4; i++) {
                int x = center.getX() + rng.nextInt(half * 2) - half;
                int z = center.getZ() + rng.nextInt(half * 2) - half;
                BlockPos p = new BlockPos(x, cy + 1, z);
                if (level.getBlockState(p).isAir() && !level.getBlockState(p.below()).is(Blocks.WATER)) {
                    level.setBlock(p, Blocks.SNOW.defaultBlockState(), 2);
                }
            }
        }
        if (map.getTerrain() == RaMap.MapTerrain.JUNGLE) {
            for (int i = 0; i < half * 3; i++) {
                int x = center.getX() + rng.nextInt(half * 2) - half;
                int z = center.getZ() + rng.nextInt(half * 2) - half;
                BlockPos p = new BlockPos(x, cy + 1, z);
                if (level.getBlockState(p).isAir() && !level.getBlockState(p.below()).is(Blocks.WATER)) {
                    if (rng.nextBoolean()) {
                        level.setBlock(p, Blocks.JUNGLE_LEAVES.defaultBlockState(), 2);
                    } else {
                        // ствол
                        level.setBlock(p, Blocks.JUNGLE_LOG.defaultBlockState(), 2);
                        level.setBlock(p.above(), Blocks.JUNGLE_LEAVES.defaultBlockState(), 2);
                    }
                }
            }
        }
    }

    private static void placeResources(ServerLevel level, BlockPos center, int half, int cy, RaMap map, Random rng) {
        int oreCount = switch (map.getSize()) {
            case SMALL -> 8;
            case MEDIUM -> 14;
            case LARGE -> 22;
        };
        for (int i = 0; i < oreCount; i++) {
            int x = center.getX() + rng.nextInt(half * 2 - 16) - half + 8;
            int z = center.getZ() + rng.nextInt(half * 2 - 16) - half + 8;
            BlockPos p = new BlockPos(x, cy + 1, z);
            if (level.getBlockState(p).isAir() && !level.getBlockState(new BlockPos(x, cy, z)).is(Blocks.WATER)) {
                level.setBlock(p, ModBlocks.ORE_DEPOSIT.get().defaultBlockState(), 3);
            }
        }

        if (map.hasOil()) {
            int oilCount = switch (map.getSize()) {
                case SMALL -> 2;
                case MEDIUM -> 4;
                case LARGE -> 6;
            };
            for (int i = 0; i < oilCount; i++) {
                int x = center.getX() + rng.nextInt(half * 2 - 20) - half + 10;
                int z = center.getZ() + rng.nextInt(half * 2 - 20) - half + 10;
                BlockPos p = new BlockPos(x, cy + 1, z);
                if (level.getBlockState(p).isAir()) {
                    level.setBlock(p, ModBlocks.OIL_DERRICK.get().defaultBlockState(), 3);
                }
            }
        }
    }

    private static List<BlockPos> placeTeamSpawns(ServerLevel level, BlockPos center, int half, int cy,
                                                  TerrainPalette palette) {
        // Три базы по углам
        int m = half - 14;
        BlockPos[] corners = {
                new BlockPos(center.getX() - m, cy, center.getZ() - m),
                new BlockPos(center.getX() + m, cy, center.getZ() - m),
                new BlockPos(center.getX(), cy, center.getZ() + m)
        };

        List<BlockPos> spawns = new ArrayList<>();
        Block[] markers = {Blocks.RED_CONCRETE, Blocks.BLUE_CONCRETE, Blocks.GREEN_CONCRETE};

        for (int t = 0; t < 3; t++) {
            BlockPos base = corners[t];
            // Площадка 9x9
            for (int dx = -4; dx <= 4; dx++) {
                for (int dz = -4; dz <= 4; dz++) {
                    BlockPos p = base.offset(dx, 0, dz);
                    level.setBlock(p, palette.floor.defaultBlockState(), 2);
                    // очистка над
                    for (int dy = 1; dy <= 6; dy++) {
                        level.setBlock(p.above(dy), Blocks.AIR.defaultBlockState(), 2);
                    }
                }
            }
            // Маркер команды
            level.setBlock(base.above(), markers[t].defaultBlockState(), 3);
            level.setBlock(base.above(2), markers[t].defaultBlockState(), 3);

            // Стартовый командный центр
            BlockPos cc = base.offset(2, 1, 0);
            level.setBlock(cc, ModBlocks.COMMAND_CENTER.get().defaultBlockState(), 3);
            BuildingManager.get(level).register(cc, BuildingType.COMMAND_CENTER, null, t + 1);

            spawns.add(base.above());
        }
        return spawns;
    }

    private static void placeBorderMarkers(ServerLevel level, BlockPos center, int half, int cy) {
        // Столбы по углам арены
        int[] xs = {center.getX() - half, center.getX() + half};
        int[] zs = {center.getZ() - half, center.getZ() + half};
        for (int x : xs) {
            for (int z : zs) {
                for (int y = 1; y <= 8; y++) {
                    level.setBlock(new BlockPos(x, cy + y, z), Blocks.YELLOW_CONCRETE.defaultBlockState(), 2);
                }
            }
        }
    }

    private static double noise(int x, int z, Random rng) {
        // Детерминированный «шум» без доп. библиотек
        long n = x * 374761393L + z * 668265263L;
        n = (n ^ (n >> 13)) * 1274126177L;
        return ((n ^ (n >> 16)) & 0xFFFF) / 65535.0;
    }

    public record GenerationResult(BlockPos center, int halfSize, List<BlockPos> teamSpawns) {
    }

    /** Палитра блоков под тип местности. */
    private record TerrainPalette(Block floor, Block floorVariant, Block subsoil, Block road, Block building) {
        static TerrainPalette forTerrain(RaMap.MapTerrain t) {
            return switch (t) {
                case URBAN -> new TerrainPalette(Blocks.GRAY_CONCRETE, Blocks.LIGHT_GRAY_CONCRETE,
                        Blocks.STONE, Blocks.BLACK_CONCRETE, Blocks.STONE_BRICKS);
                case COAST -> new TerrainPalette(Blocks.SANDSTONE, Blocks.SAND,
                        Blocks.SANDSTONE, Blocks.SMOOTH_STONE, Blocks.PRISMARINE_BRICKS);
                case ISLAND -> new TerrainPalette(Blocks.GRASS_BLOCK, Blocks.SAND,
                        Blocks.DIRT, Blocks.DIRT_PATH, Blocks.JUNGLE_PLANKS);
                case DESERT -> new TerrainPalette(Blocks.SAND, Blocks.RED_SAND,
                        Blocks.SANDSTONE, Blocks.SMOOTH_SANDSTONE, Blocks.CUT_SANDSTONE);
                case SNOW -> new TerrainPalette(Blocks.SNOW_BLOCK, Blocks.POWDER_SNOW,
                        Blocks.STONE, Blocks.PACKED_ICE, Blocks.SPRUCE_PLANKS);
                case JUNGLE -> new TerrainPalette(Blocks.GRASS_BLOCK, Blocks.MOSS_BLOCK,
                        Blocks.DIRT, Blocks.DIRT_PATH, Blocks.MOSSY_STONE_BRICKS);
                case INDUSTRIAL -> new TerrainPalette(Blocks.SMOOTH_STONE, Blocks.GRAY_CONCRETE,
                        Blocks.COBBLESTONE, Blocks.IRON_BLOCK, Blocks.IRON_BLOCK);
            };
        }
    }
}
