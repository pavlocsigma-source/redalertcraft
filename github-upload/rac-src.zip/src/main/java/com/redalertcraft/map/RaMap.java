package com.redalertcraft.map;

import net.minecraft.network.chat.Component;

/**
 * Описание карты матча.
 * Оригинальные тематические карты по мотивам локаций RA3 (без копирования ассетов EA).
 */
public class RaMap {

    private final String id;
    private final String nameKey;
    private final String descKey;
    private final int maxPlayers;
    private final MapSize size;
    private final MapTerrain terrain;
    private final boolean hasWater;
    private final boolean hasOil;

    public RaMap(String id, String nameKey, String descKey, int maxPlayers,
                 MapSize size, MapTerrain terrain, boolean hasWater, boolean hasOil) {
        this.id = id;
        this.nameKey = nameKey;
        this.descKey = descKey;
        this.maxPlayers = maxPlayers;
        this.size = size;
        this.terrain = terrain;
        this.hasWater = hasWater;
        this.hasOil = hasOil;
    }

    public String getId() {
        return id;
    }

    public Component getName() {
        return Component.translatable(nameKey);
    }

    public Component getDescription() {
        return Component.translatable(descKey);
    }

    public int getMaxPlayers() {
        return maxPlayers;
    }

    public MapSize getSize() {
        return size;
    }

    public MapTerrain getTerrain() {
        return terrain;
    }

    public boolean hasWater() {
        return hasWater;
    }

    public boolean hasOil() {
        return hasOil;
    }

    public enum MapSize {
        SMALL("map.size.small"),
        MEDIUM("map.size.medium"),
        LARGE("map.size.large");

        public final String key;

        MapSize(String key) {
            this.key = key;
        }

        public Component label() {
            return Component.translatable(key);
        }
    }

    public enum MapTerrain {
        URBAN("map.terrain.urban"),
        COAST("map.terrain.coast"),
        ISLAND("map.terrain.island"),
        DESERT("map.terrain.desert"),
        SNOW("map.terrain.snow"),
        JUNGLE("map.terrain.jungle"),
        INDUSTRIAL("map.terrain.industrial");

        public final String key;

        MapTerrain(String key) {
            this.key = key;
        }

        public Component label() {
            return Component.translatable(key);
        }
    }
}
