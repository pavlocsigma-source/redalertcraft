package com.redalertcraft.superweapon;

import com.redalertcraft.faction.Faction;
import net.minecraft.network.chat.Component;

/**
 * Супероружие фракций.
 */
public enum SuperweaponType {
    SOVIET_VACUUM(
            Faction.SOVIET,
            "superweapon.redalertcraft.vacuum",
            600,   // кулдаун в секундах (~10 мин)
            5000,  // стоимость активации
            12.0   // радиус поражения
    ),
    ALLIES_CHRONOSPHERE(
            Faction.ALLIES,
            "superweapon.redalertcraft.chronosphere",
            480,
            4000,
            8.0
    ),
    EMPIRE_PSYCHIC(
            Faction.EMPIRE,
            "superweapon.redalertcraft.psychic",
            540,
            4500,
            10.0
    );

    public final Faction faction;
    private final String nameKey;
    public final int cooldownSeconds;
    public final int activationCost;
    public final double radius;

    SuperweaponType(Faction faction, String nameKey, int cooldownSeconds, int activationCost, double radius) {
        this.faction = faction;
        this.nameKey = nameKey;
        this.cooldownSeconds = cooldownSeconds;
        this.activationCost = activationCost;
        this.radius = radius;
    }

    public Component getDisplayName() {
        return Component.translatable(nameKey);
    }

    public static SuperweaponType forFaction(Faction faction) {
        for (SuperweaponType t : values()) {
            if (t.faction == faction) {
                return t;
            }
        }
        return ALLIES_CHRONOSPHERE;
    }
}
