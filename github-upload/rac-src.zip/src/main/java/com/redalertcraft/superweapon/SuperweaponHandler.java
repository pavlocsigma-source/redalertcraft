package com.redalertcraft.superweapon;

import com.redalertcraft.combat.CombatSounds;
import com.redalertcraft.economy.ResourceHelper;
import com.redalertcraft.entity.RaUnit;
import com.redalertcraft.faction.Faction;
import com.redalertcraft.faction.PlayerFactionData;
import com.redalertcraft.capability.ModCapabilities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Активация супероружия с кулдауном.
 */
public final class SuperweaponHandler {

    private static final Map<UUID, Long> LAST_USED_MS = new HashMap<>();

    public static boolean tryActivate(ServerPlayer player, BlockPos target) {
        PlayerFactionData data = player.getCapability(ModCapabilities.PLAYER_FACTION)
                .orElse(null);
        Faction faction = data != null ? data.getFaction() : Faction.ALLIES;
        SuperweaponType type = SuperweaponType.forFaction(faction);

        long now = System.currentTimeMillis();
        Long last = LAST_USED_MS.get(player.getUUID());
        if (last != null) {
            long left = (type.cooldownSeconds * 1000L) - (now - last);
            if (left > 0) {
                player.displayClientMessage(
                        Component.translatable("message.redalertcraft.superweapon_cooldown", (left / 1000) + 1),
                        true
                );
                return false;
            }
        }

        if (!player.getAbilities().instabuild) {
            var res = ResourceHelper.get(player).orElse(null);
            if (res == null || !res.canAfford(type.activationCost)) {
                player.displayClientMessage(
                        Component.translatable("message.redalertcraft.not_enough_credits",
                                type.activationCost, res != null ? res.getCredits() : 0),
                        true
                );
                return false;
            }
            ResourceHelper.trySpend(player, type.activationCost);
        }

        // Предупреждение всем игрокам
        Component warn = Component.translatable("message.redalertcraft.superweapon_warning",
                player.getName().getString(), type.getDisplayName());
        for (ServerPlayer p : player.serverLevel().players()) {
            p.displayClientMessage(warn, false);
        }

        applyEffect(player.serverLevel(), player, type, target);
        LAST_USED_MS.put(player.getUUID(), now);
        return true;
    }

    private static void applyEffect(ServerLevel level, ServerPlayer caster, SuperweaponType type, BlockPos target) {
        double r = type.radius;
        AABB area = new AABB(target).inflate(r);

        // Визуал
        for (int i = 0; i < 40; i++) {
            level.sendParticles(ParticleTypes.EXPLOSION,
                    target.getX() + level.random.nextGaussian() * r * 0.3,
                    target.getY() + 1,
                    target.getZ() + level.random.nextGaussian() * r * 0.3,
                    1, 0, 0, 0, 0);
        }

        float damage = switch (type) {
            case SOVIET_VACUUM -> 25.0f;
            case ALLIES_CHRONOSPHERE -> 12.0f; // больше контроль, меньше урон
            case EMPIRE_PSYCHIC -> 18.0f;
        };

        CombatSounds.playBigExplosion(level, net.minecraft.world.phys.Vec3.atCenterOf(target));

        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, area)) {
            if (e == caster) continue;
            if (e instanceof RaUnit unit && unit.isOwnedBy(caster)) continue;

            e.hurt(level.damageSources().magic(), damage);

            // Chronosphere: подбрасывает / откидывает
            if (type == SuperweaponType.ALLIES_CHRONOSPHERE) {
                e.setDeltaMovement(e.getDeltaMovement().add(0, 0.8, 0));
                e.hurtMarked = true;
            }
            // Psychic: замедление через движение
            if (type == SuperweaponType.EMPIRE_PSYCHIC) {
                e.setDeltaMovement(e.getDeltaMovement().scale(0.2));
                e.hurtMarked = true;
            }
        }

        caster.displayClientMessage(
                Component.translatable("message.redalertcraft.superweapon_fired", type.getDisplayName()),
                true
        );
    }

    private SuperweaponHandler() {
    }
}
