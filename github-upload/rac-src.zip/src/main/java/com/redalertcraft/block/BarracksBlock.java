package com.redalertcraft.block;

import com.redalertcraft.entity.InfantryUnit;
import com.redalertcraft.entity.UnitProduction;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/**
 * Казармы — производство пехоты (ПКМ).
 */
public class BarracksBlock extends Block {

    public BarracksBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos,
                                 Player player, InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }

        if (player.isShiftKeyDown()) {
            player.displayClientMessage(
                    Component.translatable("message.redalertcraft.barracks.info", InfantryUnit.COST),
                    true
            );
            return InteractionResult.CONSUME;
        }

        boolean ok = UnitProduction.tryProduceInfantry(level, pos, player);
        return ok ? InteractionResult.CONSUME : InteractionResult.FAIL;
    }
}
