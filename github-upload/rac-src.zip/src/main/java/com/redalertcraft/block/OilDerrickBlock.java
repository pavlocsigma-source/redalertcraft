package com.redalertcraft.block;

import com.redalertcraft.economy.ResourceHelper;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/**
 * Нефтяная вышка: ПКМ захватывает; пассивный доход владельцу через случайный тик.
 * Упрощённо: ПКМ даёт разовый бонус; тик даёт доход ближайшему игроку в радиусе (захват).
 */
public class OilDerrickBlock extends Block {

    public static final int CAPTURE_BONUS = 200;
    public static final int TICK_INCOME = 25;

    public OilDerrickBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos,
                                 Player player, InteractionHand hand, BlockHitResult hit) {
        if (!level.isClientSide) {
            ResourceHelper.addCredits(player, CAPTURE_BONUS);
            ResourceHelper.get(player).ifPresent(res ->
                    player.displayClientMessage(
                            Component.translatable("message.redalertcraft.oil_captured", CAPTURE_BONUS, res.getCredits()),
                            true
                    ));
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public boolean isRandomlyTicking(BlockState state) {
        return true;
    }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        Player nearest = level.getNearestPlayer(pos.getX(), pos.getY(), pos.getZ(), 16, false);
        if (nearest != null) {
            ResourceHelper.addCredits(nearest, TICK_INCOME);
        }
    }
}
