package com.redalertcraft.block;

import com.redalertcraft.entity.AircraftUnit;
import com.redalertcraft.entity.RaUnit;
import com.redalertcraft.economy.ResourceHelper;
import com.redalertcraft.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/** Авиабаза — производство самолётов (ПКМ). */
public class AirbaseBlock extends Block {

    public AirbaseBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos,
                                 Player player, InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        if (player.isShiftKeyDown()) {
            player.displayClientMessage(
                    Component.translatable("message.redalertcraft.airbase.info", AircraftUnit.COST),
                    true
            );
            return InteractionResult.CONSUME;
        }

        if (!(level instanceof ServerLevel serverLevel)) {
            return InteractionResult.FAIL;
        }

        int cost = AircraftUnit.COST;
        var res = ResourceHelper.get(player).orElse(null);
        if (res == null) return InteractionResult.FAIL;
        if (!player.getAbilities().instabuild && !res.canAfford(cost)) {
            player.displayClientMessage(
                    Component.translatable("message.redalertcraft.not_enough_credits", cost, res.getCredits()),
                    true
            );
            return InteractionResult.FAIL;
        }

        AircraftUnit unit = ModEntities.AIRCRAFT.get().create(serverLevel);
        if (unit == null) return InteractionResult.FAIL;

        BlockPos spawn = pos.above(3);
        unit.moveTo(spawn.getX() + 0.5, spawn.getY(), spawn.getZ() + 0.5, player.getYRot(), 0);
        unit.setOwner(player);
        unit.setNoGravity(true);
        unit.finalizeSpawn(serverLevel, serverLevel.getCurrentDifficultyAt(spawn),
                MobSpawnType.MOB_SUMMONED, null, null);
        if (!player.getAbilities().instabuild) {
            ResourceHelper.trySpend(player, cost);
        }
        serverLevel.addFreshEntity(unit);
        ResourceHelper.get(player).ifPresent(r ->
                player.displayClientMessage(
                        Component.translatable("message.redalertcraft.unit_produced",
                                unit.getUnitDisplayName(), cost, r.getCredits()),
                        true
                ));
        return InteractionResult.CONSUME;
    }
}
