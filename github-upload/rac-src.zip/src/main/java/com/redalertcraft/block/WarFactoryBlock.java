package com.redalertcraft.block;

import com.redalertcraft.entity.TankUnit;
import com.redalertcraft.entity.UnitProduction;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/**
 * Военный завод — производство танков (ПКМ).
 */
public class WarFactoryBlock extends Block {

    public WarFactoryBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos,
                                 Player player, InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }

        if (player.isShiftKeyDown()) {
            player.displayClientMessage(
                    Component.translatable("message.redalertcraft.war_factory.info", TankUnit.COST),
                    true
            );
            return InteractionResult.CONSUME;
        }

        boolean ok = UnitProduction.tryProduceTank(level, pos, player);
        return ok ? InteractionResult.CONSUME : InteractionResult.FAIL;
    }
}
