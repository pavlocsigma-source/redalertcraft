package com.redalertcraft.block;

import com.redalertcraft.capability.ModCapabilities;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/**
 * Командный центр.
 * ПКМ показывает баланс кредитов.
 */
public class CommandCenterBlock extends Block {

    public CommandCenterBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos,
                                 Player player, InteractionHand hand, BlockHitResult hit) {
        if (!level.isClientSide) {
            player.getCapability(ModCapabilities.PLAYER_RESOURCES).ifPresent(res -> {
                player.displayClientMessage(
                        Component.translatable("message.redalertcraft.command_center.status", res.getCredits()),
                        true
                );
            });
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
