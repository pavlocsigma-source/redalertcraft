package com.redalertcraft.block;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/**
 * Перерабатывающий завод (Refinery).
 * На Этапе 2 — placeholder. Позже: приём руды от харвестеров и пассивный доход.
 */
public class RefineryBlock extends Block {

    public RefineryBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos,
                                 Player player, InteractionHand hand, BlockHitResult hit) {
        if (!level.isClientSide) {
            player.displayClientMessage(
                    Component.translatable("message.redalertcraft.refinery.info"),
                    true
            );
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
