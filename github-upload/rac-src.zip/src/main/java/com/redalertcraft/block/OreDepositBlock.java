package com.redalertcraft.block;

import com.redalertcraft.economy.ResourceHelper;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/**
 * Месторождение руды.
 * ПКМ — добыть порцию кредитов (упрощённая добыча до появления харвестеров).
 */
public class OreDepositBlock extends Block {

    public static final int CREDITS_PER_HARVEST = 150;
    public static final int MAX_HARVESTS = 8;

    public OreDepositBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos,
                                 Player player, InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }

        ResourceHelper.addCredits(player, CREDITS_PER_HARVEST);
        ResourceHelper.get(player).ifPresent(res ->
                player.displayClientMessage(
                        Component.translatable("message.redalertcraft.ore_harvested",
                                CREDITS_PER_HARVEST, res.getCredits()),
                        true
                ));

        if (level.random.nextInt(MAX_HARVESTS) == 0) {
            level.removeBlock(pos, false);
            player.displayClientMessage(
                    Component.translatable("message.redalertcraft.ore_depleted"),
                    true
            );
        }

        return InteractionResult.CONSUME;
    }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        // Зарезервировано
    }
}
