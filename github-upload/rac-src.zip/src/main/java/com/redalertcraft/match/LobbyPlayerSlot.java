package com.redalertcraft.match;

import com.redalertcraft.faction.Faction;
import com.redalertcraft.faction.PlayerColor;
import net.minecraft.network.FriendlyByteBuf;

import java.util.UUID;

/**
 * Слот игрока в лобби (для сети и GUI).
 */
public class LobbyPlayerSlot {

    public UUID uuid;
    public String name;
    public Faction faction;
    public int team;
    public PlayerColor color;
    public boolean ready;
    public boolean host;

    public LobbyPlayerSlot() {
    }

    public LobbyPlayerSlot(UUID uuid, String name, Faction faction, int team, PlayerColor color, boolean ready, boolean host) {
        this.uuid = uuid;
        this.name = name;
        this.faction = faction;
        this.team = team;
        this.color = color;
        this.ready = ready;
        this.host = host;
    }

    public void write(FriendlyByteBuf buf) {
        buf.writeUUID(uuid);
        buf.writeUtf(name, 32);
        buf.writeUtf(faction.getId(), 16);
        buf.writeVarInt(team);
        buf.writeVarInt(color.ordinal());
        buf.writeBoolean(ready);
        buf.writeBoolean(host);
    }

    public static LobbyPlayerSlot read(FriendlyByteBuf buf) {
        LobbyPlayerSlot s = new LobbyPlayerSlot();
        s.uuid = buf.readUUID();
        s.name = buf.readUtf(32);
        s.faction = Faction.byId(buf.readUtf(16));
        s.team = buf.readVarInt();
        s.color = PlayerColor.byOrdinal(buf.readVarInt());
        s.ready = buf.readBoolean();
        s.host = buf.readBoolean();
        return s;
    }
}
