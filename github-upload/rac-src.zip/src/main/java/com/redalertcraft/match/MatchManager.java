package com.redalertcraft.match;

import com.redalertcraft.RedAlertCraft;
import com.redalertcraft.map.MapGenerator;
import com.redalertcraft.map.RaMap;
import com.redalertcraft.map.RaMaps;
import com.redalertcraft.capability.ModCapabilities;
import com.redalertcraft.faction.Faction;
import com.redalertcraft.faction.PlayerColor;
import com.redalertcraft.network.LobbySyncPacket;
import com.redalertcraft.network.ModNetwork;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class MatchManager {

    private static boolean lobbyOpen = false;
    private static boolean matchActive = false;
    private static String roomCode = "";
    private static UUID hostId = null;
    private static String selectedMapId = RaMaps.defaultId();

    private static final Map<UUID, Integer> playerTeams = new HashMap<>();
    private static final Map<UUID, PlayerColor> playerColors = new HashMap<>();
    private static final Map<UUID, Faction> playerFactions = new HashMap<>();
    private static final Map<UUID, Boolean> playerReady = new HashMap<>();
    private static final Set<UUID> eliminated = new HashSet<>();

    public static void openLobby(ServerPlayer host) {
        lobbyOpen = true;
        matchActive = false;
        eliminated.clear();
        hostId = host.getUUID();
        roomCode = generateCode();
        refreshFromPlayers(host.serverLevel());
        ensureUniqueColors(host.serverLevel());
        syncLobbyToAll(host.serverLevel());
        broadcast(host.serverLevel(), Component.translatable("message.redalertcraft.lobby_opened", roomCode));
    }

    public static void joinLobby(ServerPlayer player) {
        if (!lobbyOpen) {
            player.displayClientMessage(Component.translatable("message.redalertcraft.lobby_closed"), true);
            return;
        }
        refreshPlayer(player);
        ensureUniqueColors(player.serverLevel());
        syncLobbyToAll(player.serverLevel());
        player.displayClientMessage(Component.translatable("message.redalertcraft.lobby_joined", roomCode), true);
    }

    public static void updatePlayerSettings(ServerPlayer player, Faction faction, int team, PlayerColor color, boolean ready) {
        if (isColorTaken(player.getUUID(), color, player.serverLevel())) {
            player.displayClientMessage(Component.translatable("message.redalertcraft.color_taken"), true);
            color = firstFreeColor(player.getUUID(), player.serverLevel());
        }
        final PlayerColor finalColor = color;
        final int finalTeam = Math.max(1, Math.min(3, team));
        final Faction finalFaction = faction != null ? faction : Faction.ALLIES;
        player.getCapability(ModCapabilities.PLAYER_FACTION).ifPresent(data -> {
            data.setFaction(finalFaction);
            data.setTeam(finalTeam);
            data.setColor(finalColor);
            data.setReady(ready);
        });
        playerTeams.put(player.getUUID(), finalTeam);
        playerColors.put(player.getUUID(), finalColor);
        playerFactions.put(player.getUUID(), finalFaction);
        playerReady.put(player.getUUID(), ready);
        syncLobbyToAll(player.serverLevel());
    }

    public static boolean startMatch(ServerLevel level) {
        if (!lobbyOpen) {
            lobbyOpen = true;
            roomCode = generateCode();
            if (!level.players().isEmpty()) hostId = level.players().get(0).getUUID();
            refreshFromPlayers(level);
        }
        refreshFromPlayers(level);
        ensureUniqueColors(level);
        List<ServerPlayer> players = level.players();
        if (players.size() > 1) {
            for (ServerPlayer p : players) {
                if (!playerReady.getOrDefault(p.getUUID(), false)) {
                    broadcast(level, Component.translatable("message.redalertcraft.not_all_ready"));
                    return false;
                }
            }
        }
        matchActive = true;
        lobbyOpen = false;
        eliminated.clear();
        for (ServerPlayer p : players) {
            setTeam(p.getUUID(), playerTeams.getOrDefault(p.getUUID(), 1));
        }

        // Построить карту как в RA3 (арена) и телепорт игроков
        RaMap map = RaMaps.get(selectedMapId);
        BlockPos hint = players.isEmpty()
                ? level.getSharedSpawnPos()
                : players.get(0).blockPosition();
        MapGenerator.GenerationResult result = MapGenerator.generate(level, map, hint);
        teleportPlayersToSpawns(level, result);

        broadcast(level, Component.translatable("message.redalertcraft.match_started", roomCode));
        broadcast(level, Component.literal("§6Карта: §f" + map.getName().getString()));
        syncLobbyToAll(level);
        return true;
    }

    private static void teleportPlayersToSpawns(ServerLevel level, MapGenerator.GenerationResult result) {
        List<BlockPos> spawns = result.teamSpawns();
        if (spawns.isEmpty()) return;
        for (ServerPlayer p : level.players()) {
            int team = getTeam(p.getUUID());
            int idx = Math.max(0, Math.min(team - 1, spawns.size() - 1));
            BlockPos s = spawns.get(idx);
            p.teleportTo(s.getX() + 0.5, s.getY() + 1, s.getZ() + 0.5);
            p.displayClientMessage(Component.literal("§aВы на базе команды " + team), false);
        }
    }

    public static void endMatch(ServerLevel level, int winningTeam) {
        matchActive = false;
        broadcast(level, Component.translatable("message.redalertcraft.match_ended", winningTeam));
    }

    public static boolean isMatchActive() { return matchActive; }
    public static boolean isLobbyOpen() { return lobbyOpen; }
    public static String getRoomCode() { return roomCode; }

    public static void setTeam(UUID player, int team) {
        playerTeams.put(player, Math.max(1, Math.min(3, team)));
    }

    public static int getTeam(UUID player) {
        return playerTeams.getOrDefault(player, 1);
    }

    public static PlayerColor getColor(UUID player) {
        return playerColors.getOrDefault(player, PlayerColor.BLUE);
    }

    public static boolean sameTeam(UUID a, UUID b) {
        if (a == null || b == null) return false;
        return getTeam(a) == getTeam(b);
    }

    public static List<LobbyPlayerSlot> buildSlots(ServerLevel level) {
        List<LobbyPlayerSlot> slots = new ArrayList<>();
        for (ServerPlayer p : level.players()) {
            refreshPlayer(p);
            slots.add(new LobbyPlayerSlot(
                    p.getUUID(), p.getGameProfile().getName(),
                    playerFactions.getOrDefault(p.getUUID(), Faction.ALLIES),
                    playerTeams.getOrDefault(p.getUUID(), 1),
                    playerColors.getOrDefault(p.getUUID(), PlayerColor.BLUE),
                    playerReady.getOrDefault(p.getUUID(), false),
                    p.getUUID().equals(hostId)
            ));
        }
        return slots;
    }

    public static void syncLobbyToAll(ServerLevel level) {
        List<LobbyPlayerSlot> slots = buildSlots(level);
        LobbySyncPacket packet = new LobbySyncPacket(roomCode, lobbyOpen, matchActive, selectedMapId, slots);
        for (ServerPlayer p : level.players()) {
            ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), packet);
        }
    }

    private static void refreshFromPlayers(ServerLevel level) {
        for (ServerPlayer p : level.players()) refreshPlayer(p);
    }

    private static void refreshPlayer(ServerPlayer p) {
        p.getCapability(ModCapabilities.PLAYER_FACTION).ifPresent(data -> {
            playerTeams.put(p.getUUID(), data.getTeam());
            playerColors.put(p.getUUID(), data.getColor());
            playerFactions.put(p.getUUID(), data.getFaction());
            playerReady.put(p.getUUID(), data.isReady());
        });
        if (hostId == null) hostId = p.getUUID();
    }

    private static boolean isColorTaken(UUID self, PlayerColor color, ServerLevel level) {
        for (ServerPlayer p : level.players()) {
            if (p.getUUID().equals(self)) continue;
            if (playerColors.get(p.getUUID()) == color) return true;
        }
        return false;
    }

    private static PlayerColor firstFreeColor(UUID self, ServerLevel level) {
        Set<PlayerColor> used = new HashSet<>();
        for (ServerPlayer p : level.players()) {
            if (!p.getUUID().equals(self))
                used.add(playerColors.getOrDefault(p.getUUID(), PlayerColor.RED));
        }
        for (PlayerColor c : PlayerColor.values()) {
            if (!used.contains(c)) return c;
        }
        return PlayerColor.RED;
    }

    private static void ensureUniqueColors(ServerLevel level) {
        Set<PlayerColor> used = new HashSet<>();
        for (ServerPlayer p : level.players()) {
            PlayerColor c = playerColors.getOrDefault(p.getUUID(), PlayerColor.BLUE);
            if (used.contains(c)) {
                c = firstFreeColor(p.getUUID(), level);
                playerColors.put(p.getUUID(), c);
                final PlayerColor fc = c;
                p.getCapability(ModCapabilities.PLAYER_FACTION).ifPresent(d -> d.setColor(fc));
            }
            used.add(c);
        }
    }

    public static void checkVictory(ServerLevel level) {
        if (!matchActive) return;
        Set<Integer> aliveTeams = new HashSet<>();
        for (ServerPlayer player : level.players()) {
            if (!eliminated.contains(player.getUUID()))
                aliveTeams.add(getTeam(player.getUUID()));
        }
        if (aliveTeams.size() == 1) endMatch(level, aliveTeams.iterator().next());
    }

    public static void eliminate(ServerPlayer player) {
        eliminated.add(player.getUUID());
        player.displayClientMessage(Component.translatable("message.redalertcraft.eliminated"), false);
        if (player.serverLevel() != null) checkVictory(player.serverLevel());
    }

    private static String generateCode() {
        String chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        StringBuilder sb = new StringBuilder(5);
        for (int i = 0; i < 5; i++) sb.append(chars.charAt((int) (Math.random() * chars.length())));
        return sb.toString();
    }

    private static void broadcast(ServerLevel level, Component msg) {
        for (ServerPlayer p : level.players()) p.displayClientMessage(msg, false);
        RedAlertCraft.LOGGER.info("[Match] {}", msg.getString());
    }


    public static void setSelectedMap(ServerPlayer requester, String mapId) {
        if (mapId == null || mapId.isEmpty()) return;
        // Разрешаем смену карты хосту или любому в открытом лобби
        if (hostId != null && !requester.getUUID().equals(hostId) && lobbyOpen) {
            // гости тоже могут предлагать карту в упрощённой версии
        }
        selectedMapId = RaMaps.get(mapId).getId();
        syncLobbyToAll(requester.serverLevel());
    }

    public static String getSelectedMapId() {
        return selectedMapId;
    }

    private MatchManager() {}
}
