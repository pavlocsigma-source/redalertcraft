package com.redalertcraft.client.strategic;

import com.redalertcraft.entity.RaUnit;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Выделение юнитов на клиенте.
 */
@OnlyIn(Dist.CLIENT)
public final class UnitSelection {

    private static final Set<Integer> SELECTED_IDS = new HashSet<>();

    /** Рамка выделения (экранные координаты), null если нет драга. */
    private static boolean dragging = false;
    private static double dragStartX, dragStartY;
    private static double dragEndX, dragEndY;

    public static void clear() {
        SELECTED_IDS.clear();
        dragging = false;
    }

    public static boolean isSelected(RaUnit unit) {
        return SELECTED_IDS.contains(unit.getId());
    }

    public static int size() {
        cleanup();
        return SELECTED_IDS.size();
    }

    public static List<RaUnit> getSelectedUnits() {
        cleanup();
        Minecraft mc = Minecraft.getInstance();
        List<RaUnit> list = new ArrayList<>();
        if (mc.level == null) {
            return list;
        }
        for (Integer id : SELECTED_IDS) {
            Entity e = mc.level.getEntity(id);
            if (e instanceof RaUnit unit) {
                list.add(unit);
            }
        }
        return list;
    }

    public static void selectOnly(RaUnit unit) {
        SELECTED_IDS.clear();
        if (unit != null && isOwnedByLocalPlayer(unit)) {
            SELECTED_IDS.add(unit.getId());
        }
    }

    public static void add(RaUnit unit) {
        if (unit != null && isOwnedByLocalPlayer(unit)) {
            SELECTED_IDS.add(unit.getId());
        }
    }

    public static void toggle(RaUnit unit) {
        if (unit == null || !isOwnedByLocalPlayer(unit)) {
            return;
        }
        if (SELECTED_IDS.contains(unit.getId())) {
            SELECTED_IDS.remove(unit.getId());
        } else {
            SELECTED_IDS.add(unit.getId());
        }
    }

    public static boolean isOwnedByLocalPlayer(RaUnit unit) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return false;
        }
        UUID owner = unit.getOwnerUUID();
        return owner != null && owner.equals(mc.player.getUUID());
    }

    public static void startDrag(double mouseX, double mouseY) {
        dragging = true;
        dragStartX = dragEndX = mouseX;
        dragStartY = dragEndY = mouseY;
    }

    public static void updateDrag(double mouseX, double mouseY) {
        if (dragging) {
            dragEndX = mouseX;
            dragEndY = mouseY;
        }
    }

    public static void finishDrag(boolean additive) {
        if (!dragging) {
            return;
        }
        dragging = false;

        double minX = Math.min(dragStartX, dragEndX);
        double maxX = Math.max(dragStartX, dragEndX);
        double minY = Math.min(dragStartY, dragEndY);
        double maxY = Math.max(dragStartY, dragEndY);

        // Слишком маленькая рамка = обычный клик
        if (maxX - minX < 4 && maxY - minY < 4) {
            return;
        }

        if (!additive) {
            SELECTED_IDS.clear();
        }

        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || mc.gameRenderer == null) {
            return;
        }

        // Отбираем юнитов в зоне видимости камеры по проекции (упрощённо — AABB вокруг игрока)
        double range = StrategicMode.getCameraHeight() + 40;
        AABB area = mc.player.getBoundingBox().inflate(range, range, range);
        for (RaUnit unit : mc.level.getEntitiesOfClass(RaUnit.class, area)) {
            if (!isOwnedByLocalPlayer(unit)) {
                continue;
            }
            // Проекция центра сущности на экран
            Vec3 pos = unit.getEyePosition();
            // Используем простую проверку через frustum/screen — через EntityRenderer
            // Упрощение: если юнит в поле зрения (look angle)
            if (isOnScreenApprox(unit, minX, minY, maxX, maxY)) {
                SELECTED_IDS.add(unit.getId());
            }
        }
    }

    private static boolean isOnScreenApprox(RaUnit unit, double minX, double minY, double maxX, double maxY) {
        Minecraft mc = Minecraft.getInstance();
        // World to screen via active camera — упрощённый вариант через относительные координаты
        Vec3 cam = mc.gameRenderer.getMainCamera().getPosition();
        Vec3 pos = unit.position().add(0, unit.getBbHeight() * 0.5, 0);
        Vec3 delta = pos.subtract(cam);

        // При виде сверху (pitch ~90) XZ плоскости соответствуют экрану с учётом yaw
        float yaw = (float) Math.toRadians(StrategicMode.getCameraYaw());
        double localX = delta.x * Math.cos(yaw) + delta.z * Math.sin(yaw);
        double localZ = -delta.x * Math.sin(yaw) + delta.z * Math.cos(yaw);

        // Масштаб: чем выше камера, тем мельче
        double scale = mc.getWindow().getGuiScaledHeight() / (StrategicMode.getCameraHeight() * 1.2);
        double screenCX = mc.getWindow().getGuiScaledWidth() / 2.0;
        double screenCY = mc.getWindow().getGuiScaledHeight() / 2.0;

        double sx = screenCX + localX * scale;
        double sy = screenCY + localZ * scale;

        return sx >= minX && sx <= maxX && sy >= minY && sy <= maxY;
    }

    public static boolean isDragging() {
        return dragging;
    }

    public static double[] getDragRect() {
        return new double[]{
                Math.min(dragStartX, dragEndX),
                Math.min(dragStartY, dragEndY),
                Math.max(dragStartX, dragEndX),
                Math.max(dragStartY, dragEndY)
        };
    }

    /**
     * Raycast: юнит под курсором.
     */
    public static RaUnit pickUnitUnderCursor(double reach) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) {
            return null;
        }
        HitResult hit = mc.hitResult;
        if (hit instanceof EntityHitResult ehr && ehr.getEntity() instanceof RaUnit unit) {
            return unit;
        }
        // Дополнительный raycast шире
        Vec3 eye = mc.player.getEyePosition();
        Vec3 look = mc.player.getViewVector(1.0f);
        Vec3 end = eye.add(look.scale(reach));
        AABB box = new AABB(eye, end).inflate(1.5);
        RaUnit closest = null;
        double best = reach * reach;
        for (RaUnit unit : mc.level.getEntitiesOfClass(RaUnit.class, box)) {
            AABB bb = unit.getBoundingBox().inflate(0.3);
            var opt = bb.clip(eye, end);
            if (opt.isPresent()) {
                double d = eye.distanceToSqr(opt.get());
                if (d < best) {
                    best = d;
                    closest = unit;
                }
            }
        }
        return closest;
    }

    private static void cleanup() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            SELECTED_IDS.clear();
            return;
        }
        Iterator<Integer> it = SELECTED_IDS.iterator();
        while (it.hasNext()) {
            Entity e = mc.level.getEntity(it.next());
            if (!(e instanceof RaUnit u) || !u.isAlive()) {
                it.remove();
            }
        }
    }

    private UnitSelection() {
    }
}
