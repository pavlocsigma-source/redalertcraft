package com.redalertcraft.client.lobby;

import com.redalertcraft.map.RaMaps;
import com.redalertcraft.match.LobbyPlayerSlot;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import java.util.ArrayList;
import java.util.List;

@OnlyIn(Dist.CLIENT)
public final class ClientLobbyState {

    public static String roomCode = "";
    public static boolean lobbyOpen = false;
    public static boolean matchActive = false;
    public static String selectedMapId = RaMaps.defaultId();
    public static final List<LobbyPlayerSlot> slots = new ArrayList<>();

    public static void apply(String code, boolean open, boolean match, String mapId, List<LobbyPlayerSlot> newSlots) {
        roomCode = code;
        lobbyOpen = open;
        matchActive = match;
        selectedMapId = mapId != null && !mapId.isEmpty() ? mapId : RaMaps.defaultId();
        slots.clear();
        slots.addAll(newSlots);
    }

    private ClientLobbyState() {}
}
