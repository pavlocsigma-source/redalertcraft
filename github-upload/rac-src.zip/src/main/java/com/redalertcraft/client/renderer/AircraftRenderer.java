package com.redalertcraft.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.redalertcraft.client.model.AircraftModel;
import com.redalertcraft.entity.AircraftUnit;
import com.redalertcraft.match.MatchManager;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

import java.util.UUID;

public class AircraftRenderer extends EntityRenderer<AircraftUnit> {

    private static final ResourceLocation FALLBACK =
            new ResourceLocation("minecraft", "textures/block/light_blue_concrete.png");
    private final AircraftModel model;

    public AircraftRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.model = new AircraftModel(context.bakeLayer(AircraftModel.LAYER));
        this.shadowRadius = 0.7f;
    }

    @Override
    public void render(AircraftUnit entity, float entityYaw, float partialTicks,
                       PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();
        poseStack.translate(0.0, 0.5, 0.0);
        poseStack.mulPose(Axis.YP.rotationDegrees(-entityYaw));
        poseStack.scale(-1.0f, -1.0f, 1.0f);
        float[] rgb = colorOf(entity);
        VertexConsumer consumer = buffer.getBuffer(RenderType.entityCutoutNoCull(getTextureLocation(entity)));
        model.setupAnim(entity, 0, 0, entity.tickCount + partialTicks, 0, 0);
        model.renderToBuffer(poseStack, consumer, packedLight, OverlayTexture.NO_OVERLAY, rgb[0], rgb[1], rgb[2], 1.0f);
        poseStack.popPose();
        super.render(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
    }

    private float[] colorOf(AircraftUnit entity) {
        UUID owner = entity.getOwnerUUID();
        if (owner != null) return MatchManager.getColor(owner).getRgbFloats();
        return new float[]{0.5f, 0.7f, 0.9f};
    }

    @Override
    public ResourceLocation getTextureLocation(AircraftUnit entity) { return FALLBACK; }
}
