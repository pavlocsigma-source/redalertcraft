package com.redalertcraft.client.strategic;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.redalertcraft.RedAlertCraft;
import com.redalertcraft.entity.RaUnit;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;

/**
 * Отрисовка выделения юнитов и UI стратегического режима.
 */
@Mod.EventBusSubscriber(modid = RedAlertCraft.MOD_ID, value = Dist.CLIENT)
public final class StrategicRenderer {

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES) {
            return;
        }
        if (!StrategicMode.isActive()) {
            return;
        }

        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            return;
        }

        PoseStack pose = event.getPoseStack();
        Vec3 cam = event.getCamera().getPosition();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        RenderSystem.disableDepthTest();
        RenderSystem.lineWidth(2.0f);

        for (RaUnit unit : UnitSelection.getSelectedUnits()) {
            drawUnitMarker(pose, cam, unit);
        }

        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    private static void drawUnitMarker(PoseStack pose, Vec3 cam, RaUnit unit) {
        AABB bb = unit.getBoundingBox().inflate(0.1);
        float minX = (float) (bb.minX - cam.x);
        float minY = (float) (bb.minY - cam.y);
        float minZ = (float) (bb.minZ - cam.z);
        float maxX = (float) (bb.maxX - cam.x);
        float maxY = (float) (bb.maxY - cam.y);
        float maxZ = (float) (bb.maxZ - cam.z);

        // Зелёная рамка выделения
        float r = 0.2f, g = 1.0f, b = 0.2f, a = 0.9f;
        var buffer = Tesselator.getInstance().getBuilder();
        Matrix4f mat = pose.last().pose();

        buffer.begin(VertexFormat.Mode.DEBUG_LINES, DefaultVertexFormat.POSITION_COLOR);

        // Нижний прямоугольник
        line(buffer, mat, minX, minY, minZ, maxX, minY, minZ, r, g, b, a);
        line(buffer, mat, maxX, minY, minZ, maxX, minY, maxZ, r, g, b, a);
        line(buffer, mat, maxX, minY, maxZ, minX, minY, maxZ, r, g, b, a);
        line(buffer, mat, minX, minY, maxZ, minX, minY, minZ, r, g, b, a);
        // Верхний
        line(buffer, mat, minX, maxY, minZ, maxX, maxY, minZ, r, g, b, a);
        line(buffer, mat, maxX, maxY, minZ, maxX, maxY, maxZ, r, g, b, a);
        line(buffer, mat, maxX, maxY, maxZ, minX, maxY, maxZ, r, g, b, a);
        line(buffer, mat, minX, maxY, maxZ, minX, maxY, minZ, r, g, b, a);
        // Стойки
        line(buffer, mat, minX, minY, minZ, minX, maxY, minZ, r, g, b, a);
        line(buffer, mat, maxX, minY, minZ, maxX, maxY, minZ, r, g, b, a);
        line(buffer, mat, maxX, minY, maxZ, maxX, maxY, maxZ, r, g, b, a);
        line(buffer, mat, minX, minY, maxZ, minX, maxY, maxZ, r, g, b, a);

        Tesselator.getInstance().end();
    }

    private static void line(com.mojang.blaze3d.vertex.BufferBuilder buffer, Matrix4f mat,
                             float x1, float y1, float z1, float x2, float y2, float z2,
                             float r, float g, float b, float a) {
        buffer.vertex(mat, x1, y1, z1).color(r, g, b, a).endVertex();
        buffer.vertex(mat, x2, y2, z2).color(r, g, b, a).endVertex();
    }

    @SubscribeEvent
    public static void onRenderOverlay(RenderGuiOverlayEvent.Post event) {
        if (event.getOverlay() != VanillaGuiOverlay.HOTBAR.type()) {
            return;
        }
        if (!StrategicMode.isActive()) {
            return;
        }

        Minecraft mc = Minecraft.getInstance();
        GuiGraphics g = event.getGuiGraphics();
        int w = mc.getWindow().getGuiScaledWidth();

        // Баннер режима
        String title = Component.translatable("hud.redalertcraft.strategic_mode").getString();
        String help = Component.translatable("hud.redalertcraft.strategic_help").getString();
        String sel = Component.translatable("hud.redalertcraft.selected", UnitSelection.size()).getString();

        int y = 22;
        g.drawString(mc.font, title, 8, y, 0xFF55FF55, true);
        g.drawString(mc.font, sel, 8, y + 12, 0xFFFFFFFF, true);
        g.drawString(mc.font, help, 8, y + 24, 0xFFAAAAAA, true);

        // Рамка драга
        if (UnitSelection.isDragging()) {
            double[] r = UnitSelection.getDragRect();
            int x1 = (int) r[0];
            int y1 = (int) r[1];
            int x2 = (int) r[2];
            int y2 = (int) r[3];
            g.fill(x1, y1, x2, y2, 0x3300FF00);
            // границы
            g.fill(x1, y1, x2, y1 + 1, 0xFF00FF00);
            g.fill(x1, y2 - 1, x2, y2, 0xFF00FF00);
            g.fill(x1, y1, x1 + 1, y2, 0xFF00FF00);
            g.fill(x2 - 1, y1, x2, y2, 0xFF00FF00);
        }
    }

    private StrategicRenderer() {
    }
}
