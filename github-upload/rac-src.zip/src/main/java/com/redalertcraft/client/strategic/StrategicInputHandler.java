package com.redalertcraft.client.strategic;

import com.redalertcraft.client.ModKeyBindings;
import com.redalertcraft.entity.RaUnit;
import com.redalertcraft.network.ModNetwork;
import com.redalertcraft.network.UnitOrderPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.MovementInputUpdateEvent;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import com.redalertcraft.RedAlertCraft;
import org.lwjgl.glfw.GLFW;

/**
 * Ввод в стратегическом режиме: камера, выделение, приказы.
 */
@Mod.EventBusSubscriber(modid = RedAlertCraft.MOD_ID, value = Dist.CLIENT)
public final class StrategicInputHandler {

    private static final double MOVE_SPEED = 0.95;

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) {
            return;
        }

        while (ModKeyBindings.TOGGLE_STRATEGIC.consumeClick()) {
            StrategicMode.toggle();
        }

        if (StrategicMode.isActive()) {
            StrategicMode.tick();
            handleCameraMovement(mc);
        }
    }

    private static void handleCameraMovement(Minecraft mc) {
        LocalPlayer player = mc.player;
        if (player == null) {
            return;
        }

        float yawRad = (float) Math.toRadians(StrategicMode.getCameraYaw());
        double forward = 0;
        double strafe = 0;

        if (mc.options.keyUp.isDown()) {
            forward += 1;
        }
        if (mc.options.keyDown.isDown()) {
            forward -= 1;
        }
        if (mc.options.keyLeft.isDown()) {
            strafe += 1;
        }
        if (mc.options.keyRight.isDown()) {
            strafe -= 1;
        }

        // Поворот камеры: стрелки влево/вправо или Q/E
        long window = mc.getWindow().getWindow();
        if (GLFW.glfwGetKey(window, GLFW.GLFW_KEY_Q) == GLFW.GLFW_PRESS) {
            StrategicMode.addCameraYaw(-2.5f);
        }
        if (GLFW.glfwGetKey(window, GLFW.GLFW_KEY_E) == GLFW.GLFW_PRESS) {
            StrategicMode.addCameraYaw(2.5f);
        }

        if (forward != 0 || strafe != 0) {
            double len = Math.sqrt(forward * forward + strafe * strafe);
            forward /= len;
            strafe /= len;

            double speed = MOVE_SPEED * (StrategicMode.getCameraHeight() / 40.0);
            double dx = (-Math.sin(yawRad) * forward + Math.cos(yawRad) * strafe) * speed;
            double dz = (Math.cos(yawRad) * forward + Math.sin(yawRad) * strafe) * speed;

            player.setDeltaMovement(dx, 0, dz);
            player.hurtMarked = true;
        } else {
            player.setDeltaMovement(0, 0, 0);
        }

        // Фиксируем высоту камеры
        // Ищем поверхность под камерой
        var hit = player.level().clip(new net.minecraft.world.level.ClipContext(
                new Vec3(player.getX(), player.getY() + 5, player.getZ()),
                new Vec3(player.getX(), player.getY() - 200, player.getZ()),
                net.minecraft.world.level.ClipContext.Block.COLLIDER,
                net.minecraft.world.level.ClipContext.Fluid.NONE,
                player
        ));
        double groundY = hit.getType() == HitResult.Type.BLOCK
                ? hit.getLocation().y
                : player.getY() - StrategicMode.getCameraHeight();
        player.setPos(player.getX(), groundY + StrategicMode.getCameraHeight(), player.getZ());
    }

    /** Зум колёсиком. */
    @SubscribeEvent
    public static void onScroll(InputEvent.MouseScrollingEvent event) {
        if (!StrategicMode.isActive()) {
            return;
        }
        double delta = event.getScrollDelta();
        StrategicMode.setCameraHeight(StrategicMode.getCameraHeight() - delta * 3.0);
        event.setCanceled(true);
    }

    /** ЛКМ — выделение, ПКМ — приказ. */
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onMouseClick(InputEvent.InteractionKeyMappingTriggered event) {
        if (!StrategicMode.isActive()) {
            return;
        }
        // Блокируем обычные действия игрока в стратегическом режиме
        event.setCanceled(true);
        event.setSwingHand(false);
    }

    @SubscribeEvent
    public static void onMouseButton(InputEvent.MouseButton.Pre event) {
        if (!StrategicMode.isActive()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen != null || mc.player == null) {
            return;
        }

        int button = event.getButton();
        int action = event.getAction();

        double mouseX = mc.mouseHandler.xpos()
                * mc.getWindow().getGuiScaledWidth() / mc.getWindow().getScreenWidth();
        double mouseY = mc.mouseHandler.ypos()
                * mc.getWindow().getGuiScaledHeight() / mc.getWindow().getScreenHeight();

        if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            if (action == GLFW.GLFW_PRESS) {
                UnitSelection.startDrag(mouseX, mouseY);
            } else if (action == GLFW.GLFW_RELEASE) {
                boolean shift = GLFW.glfwGetKey(mc.getWindow().getWindow(), GLFW.GLFW_KEY_LEFT_SHIFT) == GLFW.GLFW_PRESS
                        || GLFW.glfwGetKey(mc.getWindow().getWindow(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;

                double[] rect = UnitSelection.isDragging() ? UnitSelection.getDragRect() : null;
                boolean wasDrag = UnitSelection.isDragging()
                        && rect != null
                        && (rect[2] - rect[0] > 4 || rect[3] - rect[1] > 4);

                UnitSelection.finishDrag(shift);

                if (!wasDrag) {
                    // Одиночный клик
                    RaUnit unit = UnitSelection.pickUnitUnderCursor(StrategicMode.getCameraHeight() + 50);
                    if (unit != null && UnitSelection.isOwnedByLocalPlayer(unit)) {
                        if (shift) {
                            UnitSelection.toggle(unit);
                        } else {
                            UnitSelection.selectOnly(unit);
                        }
                    } else if (!shift) {
                        UnitSelection.clear();
                    }
                }
            }
        } else if (button == GLFW.GLFW_MOUSE_BUTTON_RIGHT && action == GLFW.GLFW_PRESS) {
            issueOrder(mc);
        }
    }

    @SubscribeEvent
    public static void onMouseDrag(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !StrategicMode.isActive()) {
            return;
        }
        if (!UnitSelection.isDragging()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.mouseHandler.isLeftPressed()) {
            double mouseX = mc.mouseHandler.xpos()
                    * mc.getWindow().getGuiScaledWidth() / mc.getWindow().getScreenWidth();
            double mouseY = mc.mouseHandler.ypos()
                    * mc.getWindow().getGuiScaledHeight() / mc.getWindow().getScreenHeight();
            UnitSelection.updateDrag(mouseX, mouseY);
        }
    }

    private static void issueOrder(Minecraft mc) {
        var selected = UnitSelection.getSelectedUnits();
        if (selected.isEmpty()) {
            return;
        }

        HitResult hit = mc.hitResult;
        int[] ids = selected.stream().mapToInt(Entity::getId).toArray();

        if (hit instanceof EntityHitResult ehr && ehr.getEntity() instanceof net.minecraft.world.entity.LivingEntity living) {
            // Приказ атаки
            ModNetwork.CHANNEL.sendToServer(UnitOrderPacket.attack(ids, living.getId()));
        } else if (hit instanceof BlockHitResult bhr) {
            Vec3 pos = bhr.getLocation();
            ModNetwork.CHANNEL.sendToServer(UnitOrderPacket.move(ids, pos.x, pos.y, pos.z));
        } else if (hit != null && hit.getType() != HitResult.Type.MISS) {
            Vec3 pos = hit.getLocation();
            ModNetwork.CHANNEL.sendToServer(UnitOrderPacket.move(ids, pos.x, pos.y, pos.z));
        } else {
            // Луч в точку на «земле» под перекрестием
            LocalPlayer player = mc.player;
            Vec3 eye = player.getEyePosition();
            Vec3 look = player.getViewVector(1.0f);
            var clip = player.level().clip(new net.minecraft.world.level.ClipContext(
                    eye, eye.add(look.scale(StrategicMode.getCameraHeight() + 80)),
                    net.minecraft.world.level.ClipContext.Block.COLLIDER,
                    net.minecraft.world.level.ClipContext.Fluid.NONE,
                    player
            ));
            if (clip.getType() == HitResult.Type.BLOCK) {
                Vec3 pos = clip.getLocation();
                ModNetwork.CHANNEL.sendToServer(UnitOrderPacket.move(ids, pos.x, pos.y, pos.z));
            }
        }
    }

    /** Отключаем обычный movement input conflict. */
    @SubscribeEvent
    public static void onMovementInput(MovementInputUpdateEvent event) {
        if (!StrategicMode.isActive()) {
            return;
        }
        // Обнуляем ванильный ввод — камерой управляем сами
        event.getInput().forwardImpulse = 0;
        event.getInput().leftImpulse = 0;
        event.getInput().jumping = false;
        event.getInput().shiftKeyDown = false;
    }

    private StrategicInputHandler() {
    }
}
