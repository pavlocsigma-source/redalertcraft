package com.redalertcraft.client.lobby;

import com.redalertcraft.faction.Faction;
import com.redalertcraft.faction.PlayerColor;
import com.redalertcraft.map.RaMap;
import com.redalertcraft.map.RaMaps;
import com.redalertcraft.match.LobbyPlayerSlot;
import com.redalertcraft.network.LobbyUpdatePacket;
import com.redalertcraft.network.ModNetwork;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

import java.util.List;

public class LobbyScreen extends Screen {

    private Faction faction = Faction.ALLIES;
    private int team = 1;
    private PlayerColor color = PlayerColor.BLUE;
    private boolean ready = false;
    private int mapIndex = 0;
    private int mapScroll = 0;

    private static final int PANEL = 0xE0101420;
    private static final int PANEL_BORDER = 0xFF3D5A80;
    private static final int ACCENT = 0xFFD4A017;
    private static final int TEXT = 0xFFE8EEF7;
    private static final int MUTED = 0xFF8A9BB0;

    public LobbyScreen() {
        super(Component.literal("Red Alert Craft — Лобби"));
        List<RaMap> maps = RaMaps.all();
        for (int i = 0; i < maps.size(); i++) {
            if (maps.get(i).getId().equals(ClientLobbyState.selectedMapId)) {
                mapIndex = i;
                break;
            }
        }
    }

    @Override
    protected void init() {
        clearWidgets();
        int left = 20;
        int mid = this.width / 2;

        addRenderableWidget(Button.builder(Component.literal("<"), b -> {
            mapIndex = (mapIndex - 1 + RaMaps.all().size()) % RaMaps.all().size();
            mapScroll = Math.max(0, mapIndex - 4);
            sendUpdate();
            this.init();
        }).bounds(left + 10, 48, 24, 20).build());

        addRenderableWidget(Button.builder(Component.literal(">"), b -> {
            mapIndex = (mapIndex + 1) % RaMaps.all().size();
            mapScroll = Math.max(0, mapIndex - 4);
            sendUpdate();
            this.init();
        }).bounds(left + 250, 48, 24, 20).build());

        List<RaMap> maps = RaMaps.all();
        int visible = 8;
        int start = Mth.clamp(mapScroll, 0, Math.max(0, maps.size() - visible));
        for (int i = 0; i < visible && start + i < maps.size(); i++) {
            final int idx = start + i;
            RaMap m = maps.get(idx);
            String label = (idx == mapIndex ? "> " : "  ") + m.getName().getString();
            addRenderableWidget(Button.builder(Component.literal(label), b -> {
                mapIndex = idx;
                sendUpdate();
                this.init();
            }).bounds(left + 10, 75 + i * 22, 264, 20).build());
        }

        int y = 50;
        int rx = mid + 20;
        addRenderableWidget(Button.builder(Component.literal("Команда 1"), b -> { team = 1; sendUpdate(); }).bounds(rx, y, 80, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Команда 2"), b -> { team = 2; sendUpdate(); }).bounds(rx + 88, y, 80, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Команда 3"), b -> { team = 3; sendUpdate(); }).bounds(rx + 176, y, 80, 20).build());

        y = 80;
        addRenderableWidget(Button.builder(Component.literal("СССР"), b -> { faction = Faction.SOVIET; sendUpdate(); }).bounds(rx, y, 80, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Союзники"), b -> { faction = Faction.ALLIES; sendUpdate(); }).bounds(rx + 88, y, 80, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Империя"), b -> { faction = Faction.EMPIRE; sendUpdate(); }).bounds(rx + 176, y, 80, 20).build());

        y = 115;
        int x = rx;
        for (PlayerColor c : PlayerColor.values()) {
            final PlayerColor fc = c;
            addRenderableWidget(new ColorButton(x, y, 28, 18, fc, () -> { color = fc; sendUpdate(); }));
            x += 32;
        }

        addRenderableWidget(Button.builder(
                Component.literal(ready ? "§a[Готов]" : "§e[Нажмите: Готов]"),
                b -> { ready = !ready; sendUpdate(); this.init(); }
        ).bounds(rx, 150, 160, 22).build());

        addRenderableWidget(Button.builder(Component.literal("Закрыть"), b -> onClose())
                .bounds(this.width / 2 - 40, this.height - 28, 80, 20).build());
    }

    private void sendUpdate() {
        String mapId = RaMaps.all().get(mapIndex).getId();
        ClientLobbyState.selectedMapId = mapId;
        ModNetwork.CHANNEL.sendToServer(new LobbyUpdatePacket(faction.getId(), team, color.ordinal(), ready, mapId));
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        g.fill(0, 0, this.width, this.height, 0xF0080C14);
        g.fill(0, 0, this.width, 3, ACCENT);
        g.fill(0, this.height - 3, this.width, this.height, ACCENT);

        g.drawCenteredString(this.font, "§6§lRED ALERT CRAFT", this.width / 2, 10, TEXT);
        g.drawCenteredString(this.font, "§7Многопользовательское лобби", this.width / 2, 22, MUTED);
        String code = ClientLobbyState.roomCode.isEmpty() ? "-" : ClientLobbyState.roomCode;
        g.drawCenteredString(this.font, "§fКод комнаты: §e§l" + code, this.width / 2, 34, TEXT);

        drawPanel(g, 12, 44, 290, this.height - 80);
        g.drawString(this.font, "§6Карта", 24, 52, ACCENT);

        RaMap selected = RaMaps.all().get(mapIndex);
        int infoY = 75 + 8 * 22 + 8;
        if (infoY + 60 < this.height - 40) {
            g.drawString(this.font, "§f" + selected.getName().getString(), 24, infoY, TEXT);
            String meta = selected.getSize().label().getString() + " · " + selected.getTerrain().label().getString()
                    + " · до " + selected.getMaxPlayers() + " игр.";
            g.drawString(this.font, "§7" + meta, 24, infoY + 12, MUTED);
            if (selected.hasWater()) g.drawString(this.font, "§bВода / флот", 24, infoY + 24, 0xFF55CCFF);
            if (selected.hasOil()) g.drawString(this.font, "§6Нефтяные вышки", 24, infoY + 36, 0xFFFFAA00);
            String desc = selected.getDescription().getString();
            if (desc.length() > 42) desc = desc.substring(0, 42) + "...";
            g.drawString(this.font, "§8" + desc, 24, infoY + 50, MUTED);
        }

        int rx = this.width / 2 + 8;
        drawPanel(g, rx, 44, this.width - rx - 12, 140);
        g.drawString(this.font, "§6Ваши настройки", rx + 12, 52, ACCENT);
        g.drawString(this.font, "§7Команда:", rx + 12, 68, MUTED);
        g.drawString(this.font, "§7Фракция:", rx + 12, 98, MUTED);
        g.drawString(this.font, "§7Цвет:", rx + 12, 128, MUTED);

        String factionName = switch (faction) {
            case SOVIET -> "СССР";
            case ALLIES -> "Союзники";
            case EMPIRE -> "Империя";
        };
        g.drawString(this.font, "§fВыбрано: §eКоманда " + team + " §f| §e" + factionName + " §f| §e" + color.getDisplayName().getString(),
                rx + 12, 168, TEXT);

        int playersTop = 200;
        drawPanel(g, rx, playersTop, this.width - rx - 12, this.height - playersTop - 40);
        g.drawString(this.font, "§6Игроки в комнате (" + ClientLobbyState.slots.size() + ")", rx + 12, playersTop + 8, ACCENT);

        int ly = playersTop + 24;
        for (LobbyPlayerSlot s : ClientLobbyState.slots) {
            if (ly > this.height - 50) break;
            String fname = switch (s.faction) {
                case SOVIET -> "СССР";
                case ALLIES -> "Союзники";
                case EMPIRE -> "Империя";
            };
            String line = String.format("%s%s  ·  К%d  ·  %s  ·  %s  %s",
                    s.host ? "§6* " : "§f", s.name, s.team, fname,
                    s.color.getDisplayName().getString(), s.ready ? "§aOK" : "§7...");
            g.drawString(this.font, line, rx + 12, ly, s.color.getRgb());
            ly += 12;
        }

        if (ClientLobbyState.matchActive) {
            g.drawCenteredString(this.font, "§c§lМАТЧ ИДЁТ", this.width / 2, this.height - 42, 0xFFFF5555);
        } else if (ClientLobbyState.lobbyOpen) {
            g.drawCenteredString(this.font, "§aЛобби открыто — ждём игроков", this.width / 2, this.height - 42, 0xFF55FF55);
        }

        super.render(g, mouseX, mouseY, partialTick);
    }

    private void drawPanel(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, PANEL);
        g.fill(x, y, x + w, y + 1, PANEL_BORDER);
        g.fill(x, y + h - 1, x + w, y + h, PANEL_BORDER);
        g.fill(x, y, x + 1, y + h, PANEL_BORDER);
        g.fill(x + w - 1, y, x + w, y + h, PANEL_BORDER);
        g.fill(x + 1, y + 1, x + w - 1, y + 3, ACCENT);
    }

    @Override
    public boolean isPauseScreen() { return false; }

    private static class ColorButton extends AbstractWidget {
        private final PlayerColor color;
        private final Runnable onClick;

        ColorButton(int x, int y, int w, int h, PlayerColor color, Runnable onClick) {
            super(x, y, w, h, Component.empty());
            this.color = color;
            this.onClick = onClick;
        }

        @Override
        public void onClick(double mouseX, double mouseY) { onClick.run(); }

        @Override
        protected void renderWidget(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
            g.fill(getX(), getY(), getX() + width, getY() + height, color.getArgb());
            if (isHoveredOrFocused()) {
                g.fill(getX(), getY(), getX() + width, getY() + 1, 0xFFFFFFFF);
                g.fill(getX(), getY() + height - 1, getX() + width, getY() + height, 0xFFFFFFFF);
            }
        }

        @Override
        protected void updateWidgetNarration(NarrationElementOutput output) {}
    }
}
