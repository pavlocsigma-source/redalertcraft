package com.redalertcraft.client;

import com.redalertcraft.RedAlertCraft;
import com.redalertcraft.client.model.AircraftModel;
import com.redalertcraft.client.model.InfantryModel;
import com.redalertcraft.client.model.TankModel;
import com.redalertcraft.client.renderer.AircraftRenderer;
import com.redalertcraft.client.renderer.InfantryRenderer;
import com.redalertcraft.client.renderer.TankRenderer;
import com.redalertcraft.registry.ModEntities;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = RedAlertCraft.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {

    @SubscribeEvent
    public static void onRegisterLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(TankModel.LAYER, TankModel::createBodyLayer);
        event.registerLayerDefinition(AircraftModel.LAYER, AircraftModel::createBodyLayer);
        event.registerLayerDefinition(InfantryModel.LAYER, InfantryModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.INFANTRY.get(), InfantryRenderer::new);
        event.registerEntityRenderer(ModEntities.TANK.get(), TankRenderer::new);
        event.registerEntityRenderer(ModEntities.AIRCRAFT.get(), AircraftRenderer::new);
    }

    private ClientModEvents() {}
}
