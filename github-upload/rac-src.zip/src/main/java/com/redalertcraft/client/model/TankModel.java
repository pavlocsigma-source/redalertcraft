package com.redalertcraft.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.redalertcraft.entity.TankUnit;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import com.redalertcraft.RedAlertCraft;

/**
 * 3D-модель танка: корпус, башня, ствол, гусеницы.
 */
public class TankModel extends EntityModel<TankUnit> {

    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(RedAlertCraft.MOD_ID, "tank"), "main");

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart turret;
    private final ModelPart barrel;
    private final ModelPart trackL;
    private final ModelPart trackR;

    public TankModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.turret = root.getChild("turret");
        this.barrel = this.turret.getChild("barrel");
        this.trackL = root.getChild("track_l");
        this.trackR = root.getChild("track_r");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        // Корпус
        root.addOrReplaceChild("body",
                CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-7, 0, -10, 14, 6, 20),
                PartPose.offset(0, 4, 0));

        // Башня
        PartDefinition turret = root.addOrReplaceChild("turret",
                CubeListBuilder.create()
                        .texOffs(0, 26).addBox(-4, 0, -5, 8, 4, 10),
                PartPose.offset(0, 10, 0));

        // Ствол
        turret.addOrReplaceChild("barrel",
                CubeListBuilder.create()
                        .texOffs(48, 0).addBox(-1, -1, -14, 2, 2, 12),
                PartPose.offset(0, 2, -3));

        // Гусеницы
        root.addOrReplaceChild("track_l",
                CubeListBuilder.create()
                        .texOffs(0, 40).addBox(-2, 0, -11, 3, 4, 22),
                PartPose.offset(-8, 2, 0));
        root.addOrReplaceChild("track_r",
                CubeListBuilder.create()
                        .texOffs(0, 40).addBox(-1, 0, -11, 3, 4, 22),
                PartPose.offset(8, 2, 0));

        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(TankUnit entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        // Башня слегка следует за направлением взгляда
        this.turret.yRot = netHeadYaw * ((float) Math.PI / 180f) * 0.5f;
        this.barrel.xRot = headPitch * ((float) Math.PI / 180f) * 0.25f;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
