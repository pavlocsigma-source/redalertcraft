package com.redalertcraft.client.strategic;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

/**
 * Клиентское состояние стратегического режима (F12).
 */
@OnlyIn(Dist.CLIENT)
public final class StrategicMode {

    private static boolean active = false;
    private static double cameraHeight = 40.0;
    private static float cameraYaw = 0.0f;

    /** Сохранённое положение игрока до входа в режим. */
    private static Vec3 savedPos;
    private static float savedYRot;
    private static float savedXRot;
    private static boolean savedFlying;
    private static boolean savedMayFly;

    public static boolean isActive() {
        return active;
    }

    public static double getCameraHeight() {
        return cameraHeight;
    }

    public static void setCameraHeight(double height) {
        cameraHeight = Math.max(12.0, Math.min(120.0, height));
    }

    public static float getCameraYaw() {
        return cameraYaw;
    }

    public static void addCameraYaw(float delta) {
        cameraYaw = (cameraYaw + delta) % 360.0f;
    }

    public static void toggle() {
        if (active) {
            deactivate();
        } else {
            activate();
        }
    }

    public static void activate() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null) {
            return;
        }

        savedPos = player.position();
        savedYRot = player.getYRot();
        savedXRot = player.getXRot();
        savedFlying = player.getAbilities().flying;
        savedMayFly = player.getAbilities().mayfly;

        cameraYaw = player.getYRot();
        cameraHeight = 40.0;

        player.getAbilities().mayfly = true;
        player.getAbilities().flying = true;
        player.onUpdateAbilities();

        // Поднимаем камеру над текущей позицией
        double groundY = savedPos.y;
        player.setPos(savedPos.x, groundY + cameraHeight, savedPos.z);
        player.setXRot(90.0f);
        player.setYRot(cameraYaw);

        active = true;
        UnitSelection.clear();

        player.displayClientMessage(Component.translatable("message.redalertcraft.strategic_on"), true);
    }

    public static void deactivate() {
        if (!active) {
            return;
        }

        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        active = false;
        UnitSelection.clear();

        if (player != null && savedPos != null) {
            player.setPos(savedPos.x, savedPos.y, savedPos.z);
            player.setYRot(savedYRot);
            player.setXRot(savedXRot);
            player.getAbilities().flying = savedFlying;
            player.getAbilities().mayfly = savedMayFly || player.isCreative() || player.isSpectator();
            player.onUpdateAbilities();
            player.displayClientMessage(Component.translatable("message.redalertcraft.strategic_off"), true);
        }

        savedPos = null;
    }

    /** Вызов каждый клиентский тик, пока режим активен. */
    public static void tick() {
        if (!active) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null) {
            deactivate();
            return;
        }

        // Удерживаем полёт и взгляд вниз
        player.getAbilities().flying = true;
        player.getAbilities().mayfly = true;
        player.setXRot(90.0f);
        player.setYRot(cameraYaw);

        // Фиксируем высоту относительно «земли» под камерой (грубо — относительно saved/текущей)
        // Движение по высоте — только через зум
        double targetY = player.getY();
        // Плавная коррекция не нужна — WASD двигает горизонтально в StrategicInputHandler
    }

    private StrategicMode() {
    }
}
