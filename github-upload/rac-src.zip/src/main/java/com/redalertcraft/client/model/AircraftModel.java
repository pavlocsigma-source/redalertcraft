package com.redalertcraft.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.redalertcraft.RedAlertCraft;
import com.redalertcraft.entity.AircraftUnit;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/**
 * 3D-модель самолёта: фюзеляж, крылья, хвост.
 */
public class AircraftModel extends EntityModel<AircraftUnit> {

    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(RedAlertCraft.MOD_ID, "aircraft"), "main");

    private final ModelPart root;

    public AircraftModel(ModelPart root) {
        this.root = root;
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        // Фюзеляж
        root.addOrReplaceChild("fuselage",
                CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-2, -2, -10, 4, 4, 20),
                PartPose.offset(0, 0, 0));

        // Крылья
        root.addOrReplaceChild("wing_l",
                CubeListBuilder.create()
                        .texOffs(0, 24).addBox(-14, -0.5f, -3, 14, 1, 8),
                PartPose.offset(-2, 0, 0));
        root.addOrReplaceChild("wing_r",
                CubeListBuilder.create()
                        .texOffs(0, 24).addBox(0, -0.5f, -3, 14, 1, 8),
                PartPose.offset(2, 0, 0));

        // Хвост
        root.addOrReplaceChild("tail",
                CubeListBuilder.create()
                        .texOffs(48, 0).addBox(-0.5f, -5, 8, 1, 5, 4),
                PartPose.offset(0, 0, 0));
        root.addOrReplaceChild("tail_wing",
                CubeListBuilder.create()
                        .texOffs(32, 24).addBox(-5, -0.5f, 9, 10, 1, 3),
                PartPose.offset(0, 0, 0));

        // Кабина
        root.addOrReplaceChild("cockpit",
                CubeListBuilder.create()
                        .texOffs(48, 16).addBox(-1.5f, 1, -6, 3, 2, 5),
                PartPose.offset(0, 0, 0));

        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(AircraftUnit entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        // Лёгкий крен при движении
        this.root.zRot = (float) Math.sin(ageInTicks * 0.15f) * 0.05f;
        this.root.xRot = headPitch * ((float) Math.PI / 180f) * 0.15f;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
