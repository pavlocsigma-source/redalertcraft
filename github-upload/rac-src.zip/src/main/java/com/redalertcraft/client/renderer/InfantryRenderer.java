package com.redalertcraft.client.renderer;

import com.redalertcraft.client.model.InfantryModel;
import com.redalertcraft.entity.InfantryUnit;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class InfantryRenderer extends MobRenderer<InfantryUnit, InfantryModel> {

    private static final ResourceLocation FALLBACK =
            new ResourceLocation("minecraft", "textures/entity/zombie/zombie.png");

    public InfantryRenderer(EntityRendererProvider.Context context) {
        super(context, new InfantryModel(context.bakeLayer(InfantryModel.LAYER)), 0.5f);
    }

    @Override
    public ResourceLocation getTextureLocation(InfantryUnit entity) {
        return FALLBACK;
    }
}
