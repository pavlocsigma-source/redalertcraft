package com.redalertcraft.client;

import com.redalertcraft.RedAlertCraft;
import com.redalertcraft.capability.ModCapabilities;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Простой HUD: показывает кредиты в левом верхнем углу.
 * На Этапе 2 данные берутся с клиента через capability
 * (полный sync по сети добавим при мультиплеере).
 */
@Mod.EventBusSubscriber(modid = RedAlertCraft.MOD_ID, value = Dist.CLIENT)
public final class ResourceHudOverlay {

    @SubscribeEvent
    public static void onRenderOverlay(RenderGuiOverlayEvent.Post event) {
        if (event.getOverlay() != VanillaGuiOverlay.HOTBAR.type()) {
            return;
        }

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) {
            return;
        }

        mc.player.getCapability(ModCapabilities.PLAYER_RESOURCES).ifPresent(res -> {
            GuiGraphics graphics = event.getGuiGraphics();
            String text = Component.translatable("hud.redalertcraft.credits", res.getCredits()).getString();
            int x = 8;
            int y = 8;
            // Тень + основной текст
            graphics.drawString(mc.font, text, x + 1, y + 1, 0x40000000, false);
            graphics.drawString(mc.font, text, x, y, 0xFFFFD700, false);
        });
    }

    private ResourceHudOverlay() {
    }
}
