package com.redalertcraft.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.redalertcraft.RedAlertCraft;
import com.redalertcraft.client.lobby.LobbyScreen;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

public final class ModKeyBindings {

    public static final String CATEGORY = "key.categories.redalertcraft";

    public static final KeyMapping TOGGLE_STRATEGIC = new KeyMapping(
            "key.redalertcraft.strategic",
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_F12,
            CATEGORY
    );

    public static final KeyMapping OPEN_LOBBY = new KeyMapping(
            "key.redalertcraft.lobby",
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_H,
            CATEGORY
    );

    @Mod.EventBusSubscriber(modid = RedAlertCraft.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class ModBus {
        @SubscribeEvent
        public static void register(RegisterKeyMappingsEvent event) {
            event.register(TOGGLE_STRATEGIC);
            event.register(OPEN_LOBBY);
        }
    }

    @Mod.EventBusSubscriber(modid = RedAlertCraft.MOD_ID, value = Dist.CLIENT)
    public static class ForgeBus {
        @SubscribeEvent
        public static void onKey(InputEvent.Key event) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.screen != null) return;
            while (OPEN_LOBBY.consumeClick()) {
                mc.setScreen(new LobbyScreen());
            }
        }
    }

    private ModKeyBindings() {}
}
