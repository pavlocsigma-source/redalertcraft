package com.redalertcraft.ai;

/**
 * Четыре уровня сложности ИИ.
 * Лимита войск нет — targetArmySize только мягкий ориентир «когда атаковать»,
 * ИИ продолжает производить, пока есть кредиты.
 */
public enum AiDifficulty {
    EASY("easy", 80, 3000, 80, 6, 0.25, 12, false, false),
    MEDIUM("medium", 50, 5000, 120, 12, 0.45, 16, false, false),
    HARD("hard", 30, 7000, 180, 20, 0.65, 20, true, true),
    BRUTAL("brutal", 18, 10000, 250, 30, 0.85, 24, true, true);

    public final String id;
    public final int decisionIntervalTicks;
    public final int startingCredits;
    public final int incomePerCycle;
    /** Мягкий ориентир для перехода к атакам, НЕ жёсткий лимит. */
    public final int targetArmySize;
    public final double attackChance;
    public final int baseRadius;
    public final boolean smartCounters;
    public final boolean multiFront;

    AiDifficulty(String id, int decisionIntervalTicks, int startingCredits, int incomePerCycle,
                 int targetArmySize, double attackChance, int baseRadius,
                 boolean smartCounters, boolean multiFront) {
        this.id = id;
        this.decisionIntervalTicks = decisionIntervalTicks;
        this.startingCredits = startingCredits;
        this.incomePerCycle = incomePerCycle;
        this.targetArmySize = targetArmySize;
        this.attackChance = attackChance;
        this.baseRadius = baseRadius;
        this.smartCounters = smartCounters;
        this.multiFront = multiFront;
    }

    public static AiDifficulty byName(String name) {
        for (AiDifficulty d : values()) {
            if (d.id.equalsIgnoreCase(name) || d.name().equalsIgnoreCase(name)) {
                return d;
            }
        }
        return MEDIUM;
    }
}
