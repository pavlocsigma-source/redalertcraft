package com.redalertcraft.ai;

import com.redalertcraft.RedAlertCraft;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.storage.DimensionDataStorage;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

/**
 * Хранит и тикает всех ИИ-командиров мира.
 */
public class AiManager extends SavedData {

    private static final String DATA_NAME = RedAlertCraft.MOD_ID + "_ai";

    private final List<AiCommander> commanders = new ArrayList<>();

    public static AiManager get(ServerLevel level) {
        DimensionDataStorage storage = level.getDataStorage();
        return storage.computeIfAbsent(AiManager::load, AiManager::new, DATA_NAME);
    }

    public AiCommander spawn(ServerLevel level, AiDifficulty difficulty, BlockPos nearPlayer) {
        // База ИИ — на расстоянии 40–70 блоков от игрока
        double angle = level.random.nextDouble() * Math.PI * 2;
        int dist = 48 + level.random.nextInt(24);
        int x = nearPlayer.getX() + (int) (Math.cos(angle) * dist);
        int z = nearPlayer.getZ() + (int) (Math.sin(angle) * dist);
        BlockPos base = findSurface(level, new BlockPos(x, nearPlayer.getY(), z));
        if (base == null) {
            base = new BlockPos(x, nearPlayer.getY(), z);
        }

        AiCommander commander = new AiCommander(UUID.randomUUID(), difficulty, base);
        commanders.add(commander);
        setDirty();

        RedAlertCraft.LOGGER.info("AI commander spawned: {} at {} ({})", difficulty.id, base, commander.getId());
        return commander;
    }

    public void tick(ServerLevel level) {
        if (commanders.isEmpty()) {
            return;
        }
        boolean dirty = false;
        Iterator<AiCommander> it = commanders.iterator();
        while (it.hasNext()) {
            AiCommander c = it.next();
            c.tick(level);
            dirty = true;
            if (c.isDefeated()) {
                it.remove();
            }
        }
        if (dirty) {
            setDirty();
        }
    }

    public List<AiCommander> getCommanders() {
        return commanders;
    }

    public int removeAll() {
        int n = commanders.size();
        commanders.clear();
        setDirty();
        return n;
    }

    private static BlockPos findSurface(ServerLevel level, BlockPos column) {
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos(column.getX(), level.getMaxBuildHeight() - 1, column.getZ());
        for (int y = level.getMaxBuildHeight() - 1; y > level.getMinBuildHeight(); y--) {
            m.setY(y);
            if (!level.getBlockState(m).isAir() && level.getBlockState(m.above()).isAir()) {
                return m.immutable();
            }
        }
        return null;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (AiCommander c : commanders) {
            list.add(c.save());
        }
        tag.put("Commanders", list);
        return tag;
    }

    public static AiManager load(CompoundTag tag) {
        AiManager manager = new AiManager();
        ListTag list = tag.getList("Commanders", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            manager.commanders.add(AiCommander.load(list.getCompound(i)));
        }
        return manager;
    }
}
