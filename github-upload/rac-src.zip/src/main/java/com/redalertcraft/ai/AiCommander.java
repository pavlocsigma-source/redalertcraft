package com.redalertcraft.ai;

import com.redalertcraft.RedAlertCraft;
import com.redalertcraft.entity.InfantryUnit;
import com.redalertcraft.entity.RaUnit;
import com.redalertcraft.entity.TankUnit;
import com.redalertcraft.registry.ModBlocks;
import com.redalertcraft.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Один ИИ-командир: база, экономика, армия, решения.
 */
public class AiCommander {

    private final UUID id;
    private AiDifficulty difficulty;
    private BlockPos baseCenter;
    private int credits;
    private int tickCounter;
    private boolean defeated;

    private BlockPos commandCenter;
    private BlockPos powerPlant;
    private BlockPos barracks;
    private BlockPos warFactory;
    private BlockPos refinery;

    private enum Phase {
        BUILD_CC,
        BUILD_POWER,
        BUILD_BARRACKS,
        BUILD_REFINERY,
        BUILD_FACTORY,
        EXPAND_ARMY,
        ATTACK,
        DEFEND
    }

    public AiCommander(UUID id, AiDifficulty difficulty, BlockPos baseCenter) {
        this.id = id;
        this.difficulty = difficulty;
        this.baseCenter = baseCenter.immutable();
        this.credits = difficulty.startingCredits;
        this.tickCounter = 0;
        this.defeated = false;
    }

    public UUID getId() {
        return id;
    }

    public AiDifficulty getDifficulty() {
        return difficulty;
    }

    public BlockPos getBaseCenter() {
        return baseCenter;
    }

    public int getCredits() {
        return credits;
    }

    public boolean isDefeated() {
        return defeated;
    }

    public void tick(ServerLevel level) {
        if (defeated) {
            return;
        }

        tickCounter++;

        // Проверка поражения: нет командного центра и нет юнитов
        if (commandCenter != null && level.getBlockState(commandCenter).getBlock() != ModBlocks.COMMAND_CENTER.get()) {
            commandCenter = null;
        }
        if (commandCenter == null && countUnits(level) == 0 && tickCounter > 100) {
            // Если CC так и не построили — не считаем поражением сразу
            if (tickCounter > difficulty.decisionIntervalTicks * 20L) {
                // после долгого времени без CC и армии
            }
        }
        if (commandCenter == null && wasBuiltOnce() && countUnits(level) == 0) {
            defeated = true;
            broadcast(level, Component.translatable("message.redalertcraft.ai_defeated", difficulty.id));
            return;
        }

        if (tickCounter % difficulty.decisionIntervalTicks != 0) {
            return;
        }

        // Пассивный доход (имитация добычи)
        credits += difficulty.incomePerCycle;
        if (refinery != null && level.getBlockState(refinery).getBlock() == ModBlocks.REFINERY.get()) {
            credits += difficulty.incomePerCycle / 2;
        }
        credits = Math.min(credits, 999_999);

        // Защита: если враг у базы — срочный отход/контратака
        Player nearestThreat = findNearestEnemyPlayer(level, difficulty.baseRadius + 8);
        if (nearestThreat != null) {
            defendBase(level, nearestThreat);
        }

        Phase phase = decidePhase(level);
        switch (phase) {
            case BUILD_CC -> tryBuild(level, ModBlocks.COMMAND_CENTER.get(), 2000, pos -> commandCenter = pos);
            case BUILD_POWER -> tryBuild(level, ModBlocks.POWER_PLANT.get(), 800, pos -> powerPlant = pos);
            case BUILD_BARRACKS -> tryBuild(level, ModBlocks.BARRACKS.get(), 500, pos -> barracks = pos);
            case BUILD_REFINERY -> tryBuild(level, ModBlocks.REFINERY.get(), 1500, pos -> refinery = pos);
            case BUILD_FACTORY -> tryBuild(level, ModBlocks.WAR_FACTORY.get(), 1200, pos -> warFactory = pos);
            case EXPAND_ARMY -> produceUnits(level);
            case ATTACK -> launchAttack(level);
            case DEFEND -> {
                if (nearestThreat != null) {
                    defendBase(level, nearestThreat);
                } else {
                    produceUnits(level);
                }
            }
        }
    }

    private boolean wasBuiltOnce() {
        return commandCenter != null || barracks != null || warFactory != null;
    }

    private Phase decidePhase(ServerLevel level) {
        if (!isStructureValid(level, commandCenter, ModBlocks.COMMAND_CENTER.get())) {
            return Phase.BUILD_CC;
        }
        if (!isStructureValid(level, powerPlant, ModBlocks.POWER_PLANT.get())) {
            return Phase.BUILD_POWER;
        }
        if (!isStructureValid(level, barracks, ModBlocks.BARRACKS.get())) {
            return Phase.BUILD_BARRACKS;
        }
        // На medium+ — сначала refinery
        if (difficulty.ordinal() >= AiDifficulty.MEDIUM.ordinal()
                && !isStructureValid(level, refinery, ModBlocks.REFINERY.get())) {
            return Phase.BUILD_REFINERY;
        }
        if (difficulty.ordinal() >= AiDifficulty.MEDIUM.ordinal()
                && !isStructureValid(level, warFactory, ModBlocks.WAR_FACTORY.get())) {
            return Phase.BUILD_FACTORY;
        }

        int army = countUnits(level);
        if (army < difficulty.targetArmySize) {
            return Phase.EXPAND_ARMY;
        }

        // Атака по вероятности
        if (ThreadLocalRandom.current().nextDouble() < difficulty.attackChance) {
            return Phase.ATTACK;
        }
        return Phase.EXPAND_ARMY;
    }

    private boolean isStructureValid(ServerLevel level, BlockPos pos, Block expected) {
        return pos != null && level.getBlockState(pos).getBlock() == expected;
    }

    private interface PosConsumer {
        void accept(BlockPos pos);
    }

    private void tryBuild(ServerLevel level, Block block, int cost, PosConsumer onBuilt) {
        if (credits < cost) {
            return;
        }
        BlockPos spot = findBuildSpot(level);
        if (spot == null) {
            return;
        }
        level.setBlock(spot, block.defaultBlockState(), 3);
        credits -= cost;
        onBuilt.accept(spot);
        RedAlertCraft.LOGGER.debug("AI {} built {} at {}", id, block, spot);
    }

    private BlockPos findBuildSpot(ServerLevel level) {
        ThreadLocalRandom rng = ThreadLocalRandom.current();
        for (int attempt = 0; attempt < 40; attempt++) {
            int dx = rng.nextInt(-difficulty.baseRadius, difficulty.baseRadius + 1);
            int dz = rng.nextInt(-difficulty.baseRadius, difficulty.baseRadius + 1);
            if (dx * dx + dz * dz < 9) {
                continue; // слишком близко к центру
            }
            BlockPos column = baseCenter.offset(dx, 0, dz);
            BlockPos ground = findSurface(level, column);
            if (ground == null) {
                continue;
            }
            BlockPos place = ground.above();
            if (level.getBlockState(place).isAir()
                    && level.getBlockState(place.above()).isAir()
                    && level.getBlockState(ground).isSolidRender(level, ground)) {
                // Не ставим вплотную к другому зданию ИИ (минимум 2 блока)
                if (isTooCloseToOwnBuilding(place)) {
                    continue;
                }
                return place;
            }
        }
        return null;
    }

    private boolean isTooCloseToOwnBuilding(BlockPos place) {
        for (BlockPos b : List.of(
                commandCenter, powerPlant, barracks, warFactory, refinery)) {
            if (b != null && b.closerThan(place, 2.5)) {
                return true;
            }
        }
        return false;
    }

    private BlockPos findSurface(ServerLevel level, BlockPos column) {
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos(column.getX(), baseCenter.getY() + 8, column.getZ());
        for (int i = 0; i < 24; i++) {
            if (!level.getBlockState(m).isAir() && level.getBlockState(m.above()).isAir()) {
                return m.immutable();
            }
            m.move(0, -1, 0);
        }
        return null;
    }

    private void produceUnits(ServerLevel level) {
        int army = countUnits(level);
        // Нет жёсткого лимита войск — производим, пока есть кредиты.
        // targetArmySize лишь влияет на приоритет атаки в decidePhase.

        // Smart counters: если у игрока много танков-подобных (высокий HP) — больше танков
        boolean preferTanks = false;
        if (difficulty.smartCounters) {
            Player enemy = findNearestEnemyPlayer(level, 128);
            if (enemy != null) {
                long enemyTanks = level.getEntitiesOfClass(TankUnit.class,
                        enemy.getBoundingBox().inflate(64)).stream()
                        .filter(u -> u.getOwnerUUID() != null && u.getOwnerUUID().equals(enemy.getUUID()))
                        .count();
                preferTanks = enemyTanks >= 2;
            }
        }

        // Сначала пехота, потом танки
        if (isStructureValid(level, barracks, ModBlocks.BARRACKS.get())
                && credits >= InfantryUnit.COST
                && (!preferTanks || army < 3)) {
            if (spawnUnit(level, ModEntities.INFANTRY.get(), barracks, InfantryUnit.COST)) {
                return;
            }
        }
        if (isStructureValid(level, warFactory, ModBlocks.WAR_FACTORY.get())
                && credits >= TankUnit.COST) {
            spawnUnit(level, ModEntities.TANK.get(), warFactory, TankUnit.COST);
        } else if (isStructureValid(level, barracks, ModBlocks.BARRACKS.get())
                && credits >= InfantryUnit.COST) {
            spawnUnit(level, ModEntities.INFANTRY.get(), barracks, InfantryUnit.COST);
        }
    }

    private boolean spawnUnit(ServerLevel level, EntityType<? extends RaUnit> type, BlockPos near, int cost) {
        BlockPos spawn = findSpawnNear(level, near);
        if (spawn == null) {
            return false;
        }
        RaUnit unit = type.create(level);
        if (unit == null) {
            return false;
        }
        unit.moveTo(spawn.getX() + 0.5, spawn.getY(), spawn.getZ() + 0.5, 0, 0);
        unit.setOwnerUUID(id);
        unit.finalizeSpawn(level, level.getCurrentDifficultyAt(spawn), MobSpawnType.MOB_SUMMONED, null, null);
        level.addFreshEntity(unit);
        credits -= cost;
        return true;
    }

    private BlockPos findSpawnNear(ServerLevel level, BlockPos center) {
        for (int r = 2; r <= 5; r++) {
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (Math.abs(dx) != r && Math.abs(dz) != r) continue;
                    BlockPos p = center.offset(dx, 0, dz);
                    BlockPos ground = findSurface(level, p);
                    if (ground != null) {
                        BlockPos above = ground.above();
                        if (level.getBlockState(above).isAir()) {
                            return above;
                        }
                    }
                }
            }
        }
        return center.above();
    }

    private void launchAttack(ServerLevel level) {
        Player target = findNearestEnemyPlayer(level, 256);
        if (target == null) {
            return;
        }
        List<RaUnit> army = getOwnedUnits(level);
        if (army.isEmpty()) {
            return;
        }

        // На лёгком — атакует частью армии; на брутальном — почти всеми
        double commit = switch (difficulty) {
            case EASY -> 0.4;
            case MEDIUM -> 0.6;
            case HARD -> 0.8;
            case BRUTAL -> 0.95;
        };
        int count = Math.max(1, (int) (army.size() * commit));

        // Оставляем немного для обороны на hard+
        int reserve = difficulty.ordinal() >= AiDifficulty.HARD.ordinal() ? 2 : 0;
        count = Math.min(count, Math.max(0, army.size() - reserve));

        for (int i = 0; i < count; i++) {
            RaUnit unit = army.get(i);
            unit.setTarget(target);
            unit.clearOrderedMove();
            unit.getNavigation().moveTo(target, 1.2);
        }

        if (difficulty.multiFront && army.size() > count + 2) {
            // Вторая группа — к базе игрока (чуть смещённая)
            Player p = target;
            for (int i = count; i < Math.min(army.size(), count + 3); i++) {
                RaUnit unit = army.get(i);
                double ox = ThreadLocalRandom.current().nextDouble(-12, 12);
                double oz = ThreadLocalRandom.current().nextDouble(-12, 12);
                unit.setOrderedMove(p.getX() + ox, p.getY(), p.getZ() + oz);
                unit.setTarget(null);
            }
        }
    }

    private void defendBase(ServerLevel level, Player threat) {
        for (RaUnit unit : getOwnedUnits(level)) {
            if (unit.distanceToSqr(baseCenter.getX(), baseCenter.getY(), baseCenter.getZ()) < 40 * 40
                    || unit.distanceToSqr(threat) < 20 * 20) {
                unit.setTarget(threat);
                unit.getNavigation().moveTo(threat, 1.2);
            }
        }
        // Дополнительное производство при обороне
        produceUnits(level);
    }

    private Player findNearestEnemyPlayer(ServerLevel level, double range) {
        Player best = null;
        double bestDist = range * range;
        for (Player p : level.players()) {
            if (p.isSpectator() || !p.isAlive()) continue;
            double d = p.distanceToSqr(baseCenter.getX(), baseCenter.getY(), baseCenter.getZ());
            if (d < bestDist) {
                bestDist = d;
                best = p;
            }
        }
        return best;
    }

    private int countUnits(ServerLevel level) {
        return getOwnedUnits(level).size();
    }

    private List<RaUnit> getOwnedUnits(ServerLevel level) {
        AABB area = new AABB(baseCenter).inflate(192);
        List<RaUnit> list = new ArrayList<>();
        for (RaUnit unit : level.getEntitiesOfClass(RaUnit.class, area)) {
            if (id.equals(unit.getOwnerUUID()) && unit.isAlive()) {
                list.add(unit);
            }
        }
        // Расширенный поиск по большой области (getAllEntities в 1.20.1 недоступен)
        if (list.size() < difficulty.targetArmySize) {
            AABB big = new AABB(baseCenter).inflate(256);
            for (RaUnit unit : level.getEntitiesOfClass(RaUnit.class, big)) {
                if (id.equals(unit.getOwnerUUID()) && unit.isAlive() && !list.contains(unit)) {
                    list.add(unit);
                }
            }
        }
        return list;
    }

    private void broadcast(ServerLevel level, Component msg) {
        for (Player p : level.players()) {
            p.displayClientMessage(msg, false);
        }
    }

    // --- NBT ---

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        tag.putUUID("Id", id);
        tag.putString("Difficulty", difficulty.id);
        tag.put("Base", NbtUtils.writeBlockPos(baseCenter));
        tag.putInt("Credits", credits);
        tag.putInt("Ticks", tickCounter);
        tag.putBoolean("Defeated", defeated);
        writePos(tag, "CC", commandCenter);
        writePos(tag, "PP", powerPlant);
        writePos(tag, "BR", barracks);
        writePos(tag, "WF", warFactory);
        writePos(tag, "RF", refinery);
        return tag;
    }

    public static AiCommander load(CompoundTag tag) {
        UUID id = tag.getUUID("Id");
        AiDifficulty diff = AiDifficulty.byName(tag.getString("Difficulty"));
        BlockPos base = NbtUtils.readBlockPos(tag.getCompound("Base"));
        AiCommander c = new AiCommander(id, diff, base);
        c.credits = tag.getInt("Credits");
        c.tickCounter = tag.getInt("Ticks");
        c.defeated = tag.getBoolean("Defeated");
        c.commandCenter = readPos(tag, "CC");
        c.powerPlant = readPos(tag, "PP");
        c.barracks = readPos(tag, "BR");
        c.warFactory = readPos(tag, "WF");
        c.refinery = readPos(tag, "RF");
        return c;
    }

    private static void writePos(CompoundTag tag, String key, BlockPos pos) {
        if (pos != null) {
            tag.put(key, NbtUtils.writeBlockPos(pos));
        }
    }

    private static BlockPos readPos(CompoundTag tag, String key) {
        return tag.contains(key) ? NbtUtils.readBlockPos(tag.getCompound(key)) : null;
    }
}
