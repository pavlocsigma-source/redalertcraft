package com.redalertcraft.ai;

import com.redalertcraft.RedAlertCraft;
import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = RedAlertCraft.MOD_ID)
public final class AiEvents {

    @SubscribeEvent
    public static void onWorldTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        if (!(event.level instanceof ServerLevel level)) {
            return;
        }
        // Только overworld для простоты Этапа 5
        if (level.dimension() != ServerLevel.OVERWORLD) {
            return;
        }
        AiManager.get(level).tick(level);
    }

    private AiEvents() {
    }
}
