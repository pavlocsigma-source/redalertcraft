package com.redalertcraft.entity;

import com.redalertcraft.economy.ResourceHelper;
import com.redalertcraft.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Производство юнитов за кредиты рядом со зданием.
 */
public final class UnitProduction {

    public static boolean tryProduceInfantry(Level level, BlockPos buildingPos, Player player) {
        return tryProduce(level, buildingPos, player, ModEntities.INFANTRY.get(), InfantryUnit.COST,
                Component.translatable("entity.redalertcraft.infantry"));
    }

    public static boolean tryProduceTank(Level level, BlockPos buildingPos, Player player) {
        return tryProduce(level, buildingPos, player, ModEntities.TANK.get(), TankUnit.COST,
                Component.translatable("entity.redalertcraft.tank"));
    }

    private static boolean tryProduce(Level level, BlockPos buildingPos, Player player,
                                      EntityType<? extends RaUnit> type, int cost, Component name) {
        if (level.isClientSide) {
            return false;
        }
        if (!(level instanceof ServerLevel serverLevel)) {
            return false;
        }

        var resources = ResourceHelper.get(player).orElse(null);
        if (resources == null) {
            return false;
        }
        if (!player.getAbilities().instabuild && !resources.canAfford(cost)) {
            player.displayClientMessage(
                    Component.translatable("message.redalertcraft.not_enough_credits", cost, resources.getCredits()),
                    true
            );
            return false;
        }

        // Точка спавна — рядом со зданием
        BlockPos spawnPos = findSpawnPos(serverLevel, buildingPos);
        if (spawnPos == null) {
            player.displayClientMessage(Component.translatable("message.redalertcraft.no_spawn_space"), true);
            return false;
        }

        RaUnit unit = type.create(serverLevel);
        if (unit == null) {
            return false;
        }

        unit.moveTo(spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5, player.getYRot(), 0);
        unit.setOwner(player);
        unit.finalizeSpawn(serverLevel, serverLevel.getCurrentDifficultyAt(spawnPos),
                MobSpawnType.MOB_SUMMONED, null, null);

        if (!player.getAbilities().instabuild) {
            ResourceHelper.trySpend(player, cost);
        }

        serverLevel.addFreshEntity(unit);

        ResourceHelper.get(player).ifPresent(res ->
                player.displayClientMessage(
                        Component.translatable("message.redalertcraft.unit_produced", name, cost, res.getCredits()),
                        true
                ));
        return true;
    }

    private static BlockPos findSpawnPos(ServerLevel level, BlockPos center) {
        // Ищем свободное место в радиусе 2–3 блоков
        for (int r = 2; r <= 4; r++) {
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (Math.abs(dx) != r && Math.abs(dz) != r) {
                        continue;
                    }
                    BlockPos pos = center.offset(dx, 0, dz);
                    // Поднимаемся/опускаемся к поверхности
                    BlockPos ground = findGround(level, pos);
                    if (ground != null && level.noCollision(typeBoundingBox(ground))) {
                        return ground;
                    }
                }
            }
        }
        BlockPos above = center.above();
        if (level.noCollision(typeBoundingBox(above))) {
            return above;
        }
        return null;
    }

    private static BlockPos findGround(ServerLevel level, BlockPos pos) {
        BlockPos.MutableBlockPos m = pos.mutable();
        // Ищем блок с воздухом над твёрдой поверхностью
        for (int y = 0; y < 4; y++) {
            BlockPos check = m.offset(0, y, 0);
            if (level.getBlockState(check).isAir()
                    && level.getBlockState(check.below()).isSolidRender(level, check.below())) {
                return check;
            }
        }
        for (int y = -1; y >= -3; y--) {
            BlockPos check = m.offset(0, y, 0);
            if (level.getBlockState(check).isAir()
                    && level.getBlockState(check.below()).isSolidRender(level, check.below())) {
                return check;
            }
        }
        return null;
    }

    private static net.minecraft.world.phys.AABB typeBoundingBox(BlockPos pos) {
        return new net.minecraft.world.phys.AABB(
                pos.getX() + 0.1, pos.getY(), pos.getZ() + 0.1,
                pos.getX() + 0.9, pos.getY() + 1.8, pos.getZ() + 0.9
        );
    }

    private UnitProduction() {
    }
}
