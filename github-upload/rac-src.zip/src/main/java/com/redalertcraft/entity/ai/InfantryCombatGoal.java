package com.redalertcraft.entity.ai;

import com.redalertcraft.combat.CombatSounds;
import com.redalertcraft.entity.InfantryUnit;
import com.redalertcraft.entity.RaUnit;
import com.redalertcraft.entity.TankUnit;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/**
 * Умный бой пехоты:
 * - приоритет: вражеская пехота > техника > прочее
 * - подходит на оптимальную дистанцию (~3–6 блоков)
 * - отступает от танков вблизи
 * - стреляет очередями со звуком
 */
public class InfantryCombatGoal extends Goal {

    private final InfantryUnit unit;
    private LivingEntity target;
    private int attackCooldown;
    private int strafeTimer;
    private int repathTimer;
    private boolean strafingClockwise;

    public InfantryCombatGoal(InfantryUnit unit) {
        this.unit = unit;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        LivingEntity t = unit.getTarget();
        if (t == null || !t.isAlive() || !unit.canAttackTarget(t)) {
            t = findBestTarget();
            if (t == null) return false;
            unit.setTarget(t);
        }
        this.target = t;
        return true;
    }

    @Override
    public boolean canContinueToUse() {
        return target != null && target.isAlive() && unit.canAttackTarget(target);
    }

    @Override
    public void stop() {
        target = null;
        unit.getNavigation().stop();
    }

    @Override
    public void tick() {
        if (target == null) return;

        double dist = unit.distanceToSqr(target);
        unit.getLookControl().setLookAt(target, 40f, 40f);

        // От танков в упор — отойти
        if (target instanceof TankUnit && dist < 3.5 * 3.5) {
            Vec3 away = DefaultRandomPos.getPosAway(unit, 6, 3, target.position());
            if (away != null) {
                unit.getNavigation().moveTo(away.x, away.y, away.z, 1.25);
            }
            return;
        }

        double preferMin = 2.5 * 2.5;
        double preferMax = 7.0 * 7.0;

        if (dist > preferMax) {
            if (--repathTimer <= 0) {
                repathTimer = 8;
                unit.getNavigation().moveTo(target, 1.2);
            }
        } else if (dist < preferMin) {
            // Чуть отойти назад
            Vec3 away = DefaultRandomPos.getPosAway(unit, 4, 2, target.position());
            if (away != null) {
                unit.getNavigation().moveTo(away.x, away.y, away.z, 1.1);
            }
        } else {
            // На дистанции — стрейф
            unit.getNavigation().stop();
            if (--strafeTimer <= 0) {
                strafeTimer = 12 + unit.getRandom().nextInt(10);
                strafingClockwise = !strafingClockwise;
            }
            unit.getMoveControl().strafe(0.15f, strafingClockwise ? 0.35f : -0.35f);
            unit.lookAt(target, 40f, 40f);
        }

        // Стрельба
        if (dist <= preferMax + 4 && --attackCooldown <= 0) {
            attackCooldown = 12 + unit.getRandom().nextInt(6); // очередь
            if (unit.level() instanceof ServerLevel level) {
                CombatSounds.playShoot(level, unit);
            }
            unit.swing(InteractionHand.MAIN_HAND);
            unit.doHurtTarget(target);
            if (unit.level() instanceof ServerLevel level) {
                CombatSounds.playHit(level, target);
            }
        }
    }

    private LivingEntity findBestTarget() {
        double range = unit.getAttributeValue(net.minecraft.world.entity.ai.attributes.Attributes.FOLLOW_RANGE);
        LivingEntity bestInf = null;
        LivingEntity bestTank = null;
        LivingEntity bestOther = null;
        double dInf = range * range, dTank = dInf, dOther = dInf;

        for (LivingEntity e : unit.level().getEntitiesOfClass(LivingEntity.class, unit.getBoundingBox().inflate(range))) {
            if (!unit.canAttackTarget(e) || !e.isAlive()) continue;
            double d = unit.distanceToSqr(e);
            if (e instanceof InfantryUnit || (e instanceof RaUnit && !(e instanceof TankUnit))) {
                if (d < dInf) { dInf = d; bestInf = e; }
            } else if (e instanceof TankUnit) {
                if (d < dTank) { dTank = d; bestTank = e; }
            } else {
                if (d < dOther) { dOther = d; bestOther = e; }
            }
        }
        if (bestInf != null) return bestInf;
        if (bestTank != null) return bestTank;
        return bestOther;
    }
}
