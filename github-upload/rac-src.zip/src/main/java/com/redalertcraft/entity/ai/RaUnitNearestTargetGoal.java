package com.redalertcraft.entity.ai;

import com.redalertcraft.entity.RaUnit;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.targeting.TargetingConditions;

import javax.annotation.Nullable;
import java.util.function.Predicate;

/**
 * Поиск ближайшей враждебной цели с учётом владельца юнита.
 */
public class RaUnitNearestTargetGoal<T extends LivingEntity> extends NearestAttackableTargetGoal<T> {

    private final RaUnit unit;

    public RaUnitNearestTargetGoal(RaUnit unit, Class<T> targetClass, boolean mustSee) {
        super(unit, targetClass, 10, mustSee, false, createPredicate(unit));
        this.unit = unit;
    }

    private static Predicate<LivingEntity> createPredicate(RaUnit unit) {
        return target -> target != null && unit.canAttackTarget(target);
    }

    @Override
    public boolean canUse() {
        return super.canUse() && this.target != null && this.unit.canAttackTarget(this.target);
    }
}
