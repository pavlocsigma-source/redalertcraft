package com.redalertcraft.entity;

import com.redalertcraft.combat.CombatSounds;
import com.redalertcraft.entity.ai.RaUnitAssaultBuildingGoal;
import com.redalertcraft.entity.ai.RaUnitAttackGoal;
import com.redalertcraft.match.MatchManager;
import com.redalertcraft.entity.ai.RaUnitMoveOrderGoal;
import com.redalertcraft.entity.ai.RaUnitNearestTargetGoal;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.Optional;
import java.util.UUID;

/**
 * Базовый боевой юнит Red Alert Craft.
 * Владелец, атака, pathfinding, приказы движения.
 */
public abstract class RaUnit extends PathfinderMob {

    private static final EntityDataAccessor<Optional<UUID>> OWNER_UUID =
            SynchedEntityData.defineId(RaUnit.class, EntityDataSerializers.OPTIONAL_UUID);

    private UUID ownerUUID;

    /** Приказ движения (сервер). */
    private boolean hasMoveOrder;
    private double orderX, orderY, orderZ;

    private int veteranKills;
    private int veteranXp;

    protected RaUnit(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createBaseAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.25)
                .add(Attributes.ATTACK_DAMAGE, 3.0)
                .add(Attributes.FOLLOW_RANGE, 24.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.2)
                .add(Attributes.ARMOR, 0.0);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(OWNER_UUID, Optional.empty());
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new RaUnitAttackGoal(this, 1.15, true));
        this.goalSelector.addGoal(2, new RaUnitAssaultBuildingGoal(this));
        this.goalSelector.addGoal(3, new RaUnitMoveOrderGoal(this, 1.15));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.85));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new RaUnitNearestTargetGoal<>(this, RaUnit.class, true));
        this.targetSelector.addGoal(2, new RaUnitNearestTargetGoal<>(this, Player.class, true));
        this.targetSelector.addGoal(3, new RaUnitNearestTargetGoal<>(this, Mob.class, true));
    }

    public void setOrderedMove(double x, double y, double z) {
        this.hasMoveOrder = true;
        this.orderX = x;
        this.orderY = y;
        this.orderZ = z;
    }

    public void clearOrderedMove() {
        this.hasMoveOrder = false;
    }

    public boolean hasOrderedMove() {
        return hasMoveOrder;
    }

    public double getOrderX() { return orderX; }
    public double getOrderY() { return orderY; }
    public double getOrderZ() { return orderZ; }

    public void setOwner(@Nullable Player player) {
        if (player == null) {
            this.ownerUUID = null;
            this.entityData.set(OWNER_UUID, Optional.empty());
        } else {
            this.ownerUUID = player.getUUID();
            this.entityData.set(OWNER_UUID, Optional.of(player.getUUID()));
        }
    }

    public void setOwnerUUID(@Nullable UUID uuid) {
        this.ownerUUID = uuid;
        this.entityData.set(OWNER_UUID, Optional.ofNullable(uuid));
    }

    @Nullable
    public UUID getOwnerUUID() {
        return this.entityData.get(OWNER_UUID).orElse(this.ownerUUID);
    }

    @Nullable
    public Player getOwner() {
        UUID id = getOwnerUUID();
        if (id == null || this.level().isClientSide) {
            return null;
        }
        return this.level().getPlayerByUUID(id);
    }

    public boolean isOwnedBy(LivingEntity entity) {
        UUID id = getOwnerUUID();
        return id != null && entity != null && id.equals(entity.getUUID());
    }

    public boolean canAttackTarget(LivingEntity target) {
        if (target == null || !target.isAlive() || target == this) {
            return false;
        }
        if (isOwnedBy(target)) {
            return false;
        }
        if (target instanceof RaUnit other) {
            UUID myOwner = getOwnerUUID();
            UUID theirOwner = other.getOwnerUUID();
            if (myOwner != null && myOwner.equals(theirOwner)) return false;
            if (myOwner != null && theirOwner != null && MatchManager.sameTeam(myOwner, theirOwner)) return false;
            return true;
        }
        if (target instanceof Player player) {
            UUID myOwner = getOwnerUUID();
            if (myOwner != null && myOwner.equals(player.getUUID())) return false;
            // Союзники по команде не атакуют
            if (myOwner != null && MatchManager.sameTeam(myOwner, player.getUUID())) return false;
            return true;
        }
        return target instanceof Mob && !(target instanceof net.minecraft.world.entity.animal.Animal);
    }

    public abstract int getProductionCost();

    public abstract Component getUnitDisplayName();

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        UUID id = getOwnerUUID();
        if (id != null) {
            tag.putUUID("Owner", id);
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("Owner")) {
            setOwnerUUID(tag.getUUID("Owner"));
        }
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (!this.level().isClientSide) {
            Player owner = getOwner();
            if (owner instanceof ServerPlayer) {
                owner.displayClientMessage(
                        Component.translatable("message.redalertcraft.unit_destroyed", getUnitDisplayName()),
                        true
                );
            }
        }
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return getOwnerUUID() == null && super.removeWhenFarAway(distanceToClosestPlayer);
    }

    @Override
    protected boolean shouldDespawnInPeaceful() {
        return false;
    }


    @Override
    public void die(net.minecraft.world.damagesource.DamageSource source) {
        if (!this.level().isClientSide && this.level() instanceof net.minecraft.server.level.ServerLevel serverLevel) {
            if (!(this instanceof com.redalertcraft.entity.InfantryUnit)) {
                CombatSounds.playExplosion(serverLevel, this.blockPosition(), 0.9f);
                serverLevel.sendParticles(net.minecraft.core.particles.ParticleTypes.EXPLOSION,
                        this.getX(), this.getY() + 0.5, this.getZ(), 1, 0, 0, 0, 0);
                serverLevel.sendParticles(net.minecraft.core.particles.ParticleTypes.LARGE_SMOKE,
                        this.getX(), this.getY() + 0.5, this.getZ(), 12, 0.5, 0.4, 0.5, 0.02);
            }
        }
        super.die(source);
    }

    // --- Veterans ---

    public void addVeteranKill() {
        veteranKills++;
        veteranXp += 25;
    }

    public int getVeteranKills() {
        return veteranKills;
    }

    public int getVeteranXp() {
        return veteranXp;
    }

    public com.redalertcraft.entity.VeteranRank getVeteranRank() {
        return com.redalertcraft.entity.VeteranRank.fromProgress(veteranKills, veteranXp);
    }

}
