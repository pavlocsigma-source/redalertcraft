package com.redalertcraft.entity.ai;

import com.redalertcraft.building.BuildingManager;
import com.redalertcraft.combat.CombatSounds;
import com.redalertcraft.building.BuildingType;
import com.redalertcraft.entity.InfantryUnit;
import com.redalertcraft.entity.RaUnit;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/**
 * Пехота и техника атакуют вражеские здания; пехота — штурм.
 */
public class RaUnitAssaultBuildingGoal extends Goal {

    private final RaUnit unit;
    private BlockPos targetBuilding;
    private int attackCooldown;

    public RaUnitAssaultBuildingGoal(RaUnit unit) {
        this.unit = unit;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        if (!(unit.level() instanceof ServerLevel level)) return false;
        if (unit.getTarget() != null && unit.getTarget().isAlive()) return false; // приоритет живым целям

        BuildingManager mgr = BuildingManager.get(level);
        BlockPos found = mgr.findNearestEnemyBuilding(level, unit.position(), unit.getOwnerUUID(), 24);
        if (found == null) return false;

        targetBuilding = found;
        return true;
    }

    @Override
    public boolean canContinueToUse() {
        if (targetBuilding == null) return false;
        if (!(unit.level() instanceof ServerLevel level)) return false;
        BuildingType type = BuildingType.fromBlock(level.getBlockState(targetBuilding).getBlock());
        if (type == null && BuildingManager.get(level).get(targetBuilding) == null) return false;
        return unit.distanceToSqr(Vec3.atCenterOf(targetBuilding)) < 30 * 30;
    }

    @Override
    public void start() {
        if (targetBuilding != null) {
            unit.getNavigation().moveTo(targetBuilding.getX() + 0.5, targetBuilding.getY(), targetBuilding.getZ() + 0.5, 1.15);
        }
    }

    @Override
    public void tick() {
        if (targetBuilding == null || !(unit.level() instanceof ServerLevel level)) return;

        double dist = unit.distanceToSqr(Vec3.atCenterOf(targetBuilding));
        unit.getLookControl().setLookAt(targetBuilding.getX() + 0.5, targetBuilding.getY() + 1, targetBuilding.getZ() + 0.5);

        if (dist > 3.5 * 3.5) {
            unit.getNavigation().moveTo(targetBuilding.getX() + 0.5, targetBuilding.getY(), targetBuilding.getZ() + 0.5, 1.15);
            return;
        }

        if (--attackCooldown > 0) return;
        attackCooldown = unit instanceof InfantryUnit ? 15 : 25;

        BuildingManager mgr = BuildingManager.get(level);
        CombatSounds.playShoot(level, unit);
        if (unit instanceof InfantryUnit infantry) {
            mgr.assaultTick(level, infantry, targetBuilding);
        } else {
            int dmg = (int) unit.getAttributeValue(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE);
            mgr.damage(level, targetBuilding, Math.max(8, dmg * 2), unit.getOwnerUUID());
        }
    }

    @Override
    public void stop() {
        targetBuilding = null;
    }
}
