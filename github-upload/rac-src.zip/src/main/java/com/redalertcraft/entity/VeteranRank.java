package com.redalertcraft.entity;

import net.minecraft.network.chat.Component;

/**
 * Ранги ветеранов.
 */
public enum VeteranRank {
    RECRUIT(0, 0, 1.0, 1.0, "veteran.redalertcraft.recruit"),
    VETERAN(3, 50, 1.15, 1.1, "veteran.redalertcraft.veteran"),
    ELITE(8, 150, 1.3, 1.25, "veteran.redalertcraft.elite"),
    HERO(18, 350, 1.5, 1.4, "veteran.redalertcraft.hero");

    public final int minKills;
    public final int minXp;
    public final double damageMult;
    public final double healthMult;
    private final String key;

    VeteranRank(int minKills, int minXp, double damageMult, double healthMult, String key) {
        this.minKills = minKills;
        this.minXp = minXp;
        this.damageMult = damageMult;
        this.healthMult = healthMult;
        this.key = key;
    }

    public Component getDisplayName() {
        return Component.translatable(key);
    }

    public static VeteranRank fromProgress(int kills, int xp) {
        VeteranRank best = RECRUIT;
        for (VeteranRank r : values()) {
            if (kills >= r.minKills || xp >= r.minXp) {
                best = r;
            }
        }
        return best;
    }
}
