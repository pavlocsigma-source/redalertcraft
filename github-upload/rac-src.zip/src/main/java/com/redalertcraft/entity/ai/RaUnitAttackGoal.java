package com.redalertcraft.entity.ai;

import com.redalertcraft.combat.CombatSounds;
import com.redalertcraft.entity.RaUnit;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.EnumSet;

/**
 * Атака с звуками — без опоры на protected-методы MeleeAttackGoal (совместимость 1.20.1).
 */
public class RaUnitAttackGoal extends Goal {

    private final RaUnit unit;
    private final double speed;
    private int cooldown;

    public RaUnitAttackGoal(RaUnit unit, double speedModifier, boolean followingTargetEvenIfNotSeen) {
        this.unit = unit;
        this.speed = speedModifier;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        LivingEntity target = unit.getTarget();
        return target != null && target.isAlive() && unit.canAttackTarget(target);
    }

    @Override
    public boolean canContinueToUse() {
        return canUse();
    }

    @Override
    public void tick() {
        LivingEntity target = unit.getTarget();
        if (target == null) return;

        unit.getLookControl().setLookAt(target, 30.0F, 30.0F);
        double distSqr = unit.distanceToSqr(target);
        double reach = Math.pow(unit.getBbWidth() * 2.0 + target.getBbWidth(), 2);

        if (distSqr > reach) {
            unit.getNavigation().moveTo(target, speed);
            return;
        }

        unit.getNavigation().stop();
        if (--cooldown > 0) return;
        cooldown = 20;

        if (unit.level() instanceof ServerLevel level) {
            CombatSounds.playShoot(level, unit);
        }
        unit.swing(InteractionHand.MAIN_HAND);
        unit.doHurtTarget(target);
        if (unit.level() instanceof ServerLevel level) {
            CombatSounds.playHit(level, target);
        }
    }

    @Override
    public void stop() {
        unit.getNavigation().stop();
    }
}
