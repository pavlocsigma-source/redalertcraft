package com.redalertcraft.entity.ai;

import com.redalertcraft.entity.RaUnit;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.level.pathfinder.Path;

import java.util.EnumSet;

/**
 * Выполняет приказ движения от игрока (приоритетнее случайного stroll).
 */
public class RaUnitMoveOrderGoal extends Goal {

    private final RaUnit unit;
    private final double speed;

    public RaUnitMoveOrderGoal(RaUnit unit, double speed) {
        this.unit = unit;
        this.speed = speed;
        this.setFlags(EnumSet.of(Flag.MOVE));
    }

    @Override
    public boolean canUse() {
        return unit.hasOrderedMove();
    }

    @Override
    public boolean canContinueToUse() {
        if (!unit.hasOrderedMove()) {
            return false;
        }
        // Добрались
        if (unit.distanceToSqr(unit.getOrderX(), unit.getOrderY(), unit.getOrderZ()) < 2.25) {
            unit.clearOrderedMove();
            return false;
        }
        return true;
    }

    @Override
    public void start() {
        PathNavigation nav = unit.getNavigation();
        Path path = nav.createPath(unit.getOrderX(), unit.getOrderY(), unit.getOrderZ(), 0);
        if (path != null) {
            nav.moveTo(path, speed);
        } else {
            nav.moveTo(unit.getOrderX(), unit.getOrderY(), unit.getOrderZ(), speed);
        }
    }

    @Override
    public void tick() {
        if (unit.getNavigation().isDone()) {
            unit.getNavigation().moveTo(unit.getOrderX(), unit.getOrderY(), unit.getOrderZ(), speed);
        }
    }

    @Override
    public void stop() {
        unit.getNavigation().stop();
    }
}
