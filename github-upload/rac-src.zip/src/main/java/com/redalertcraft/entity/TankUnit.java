package com.redalertcraft.entity;

import com.redalertcraft.entity.ai.RaUnitAssaultBuildingGoal;
import com.redalertcraft.entity.ai.RaUnitMoveOrderGoal;
import com.redalertcraft.entity.ai.TankCombatGoal;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class TankUnit extends RaUnit {

    public static final int COST = 700;

    public TankUnit(EntityType<? extends TankUnit> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return RaUnit.createBaseAttributes()
                .add(Attributes.MAX_HEALTH, 80.0)
                .add(Attributes.MOVEMENT_SPEED, 0.22)
                .add(Attributes.ATTACK_DAMAGE, 12.0)
                .add(Attributes.FOLLOW_RANGE, 36.0)
                .add(Attributes.ARMOR, 8.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.7);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new TankCombatGoal(this));
        this.goalSelector.addGoal(2, new RaUnitAssaultBuildingGoal(this));
        this.goalSelector.addGoal(3, new RaUnitMoveOrderGoal(this, 1.05));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.75));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new com.redalertcraft.entity.ai.RaUnitNearestTargetGoal<>(this, TankUnit.class, true));
        this.targetSelector.addGoal(2, new com.redalertcraft.entity.ai.RaUnitNearestTargetGoal<>(this, Player.class, true));
        this.targetSelector.addGoal(3, new com.redalertcraft.entity.ai.RaUnitNearestTargetGoal<>(this, InfantryUnit.class, true));
        this.targetSelector.addGoal(4, new com.redalertcraft.entity.ai.RaUnitNearestTargetGoal<>(this, RaUnit.class, true));
        this.targetSelector.addGoal(5, new com.redalertcraft.entity.ai.RaUnitNearestTargetGoal<>(this, Mob.class, true));
    }

    @Override
    public int getProductionCost() {
        return COST;
    }

    @Override
    public Component getUnitDisplayName() {
        return Component.translatable("entity.redalertcraft.tank");
    }
}
