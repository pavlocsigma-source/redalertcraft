package com.redalertcraft.entity.ai;

import com.redalertcraft.combat.CombatSounds;
import com.redalertcraft.entity.AircraftUnit;
import com.redalertcraft.entity.InfantryUnit;
import com.redalertcraft.entity.RaUnit;
import com.redalertcraft.entity.TankUnit;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/**
 * Умный бой танка:
 * - приоритет: вражеские танки > здания (через assault) > пехота
 * - держит среднюю дистанцию (6–12 блоков)
 * - медленный поворот башни (взгляд)
 * - мощные выстрелы с перезарядкой
 */
public class TankCombatGoal extends Goal {

    private final TankUnit unit;
    private LivingEntity target;
    private int attackCooldown;
    private int repathTimer;

    public TankCombatGoal(TankUnit unit) {
        this.unit = unit;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        LivingEntity t = unit.getTarget();
        if (t == null || !t.isAlive() || !unit.canAttackTarget(t)) {
            t = findBestTarget();
            if (t == null) return false;
            unit.setTarget(t);
        }
        this.target = t;
        return true;
    }

    @Override
    public boolean canContinueToUse() {
        return target != null && target.isAlive() && unit.canAttackTarget(target);
    }

    @Override
    public void stop() {
        target = null;
        unit.getNavigation().stop();
    }

    @Override
    public void tick() {
        if (target == null) return;

        double dist = unit.distanceToSqr(target);
        // Медленный «поворот башни»
        unit.getLookControl().setLookAt(target, 20f, 20f);

        double minRange = 5.0 * 5.0;
        double maxRange = 14.0 * 14.0;
        double fireRange = 16.0 * 16.0;

        if (dist > maxRange) {
            if (--repathTimer <= 0) {
                repathTimer = 12;
                unit.getNavigation().moveTo(target, 1.05);
            }
        } else if (dist < minRange) {
            // Задним ходом
            Vec3 away = unit.position().subtract(target.position()).normalize().scale(4);
            unit.getNavigation().moveTo(
                    unit.getX() + away.x,
                    unit.getY(),
                    unit.getZ() + away.z,
                    0.95
            );
        } else {
            unit.getNavigation().stop();
        }

        // Выстрел орудия
        if (dist <= fireRange && --attackCooldown <= 0) {
            attackCooldown = 28 + unit.getRandom().nextInt(8); // перезарядка
            if (unit.level() instanceof ServerLevel level) {
                CombatSounds.playShoot(level, unit);
                // Вспышка
                level.sendParticles(net.minecraft.core.particles.ParticleTypes.SMOKE,
                        unit.getX(), unit.getY() + 1.2, unit.getZ(),
                        6, 0.3, 0.2, 0.3, 0.02);
                level.sendParticles(net.minecraft.core.particles.ParticleTypes.FLAME,
                        unit.getX(), unit.getY() + 1.2, unit.getZ(),
                        3, 0.15, 0.1, 0.15, 0.01);
            }
            unit.swing(InteractionHand.MAIN_HAND);

            // Танки бьют сильнее по технике
            float bonus = target instanceof TankUnit ? 1.35f
                    : target instanceof InfantryUnit ? 0.85f : 1.0f;
            float dmg = (float) unit.getAttributeValue(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE) * bonus;
            target.hurt(unit.damageSources().mobAttack(unit), dmg);

            if (unit.level() instanceof ServerLevel level) {
                CombatSounds.playHit(level, target);
                level.sendParticles(net.minecraft.core.particles.ParticleTypes.CRIT,
                        target.getX(), target.getY() + 0.8, target.getZ(),
                        8, 0.3, 0.3, 0.3, 0.05);
            }
        }
    }

    private LivingEntity findBestTarget() {
        double range = unit.getAttributeValue(net.minecraft.world.entity.ai.attributes.Attributes.FOLLOW_RANGE);
        LivingEntity bestTank = null;
        LivingEntity bestPlayer = null;
        LivingEntity bestInf = null;
        LivingEntity bestOther = null;
        double dT = range * range, dP = dT, dI = dT, dO = dT;

        for (LivingEntity e : unit.level().getEntitiesOfClass(LivingEntity.class, unit.getBoundingBox().inflate(range))) {
            if (!unit.canAttackTarget(e) || !e.isAlive()) continue;
            // Авиацию танки бьют слабо — низкий приоритет
            if (e instanceof AircraftUnit) continue;
            double d = unit.distanceToSqr(e);
            if (e instanceof TankUnit) {
                if (d < dT) { dT = d; bestTank = e; }
            } else if (e instanceof Player) {
                if (d < dP) { dP = d; bestPlayer = e; }
            } else if (e instanceof InfantryUnit) {
                if (d < dI) { dI = d; bestInf = e; }
            } else {
                if (d < dO) { dO = d; bestOther = e; }
            }
        }
        if (bestTank != null) return bestTank;
        if (bestPlayer != null) return bestPlayer;
        if (bestInf != null) return bestInf;
        return bestOther;
    }
}
