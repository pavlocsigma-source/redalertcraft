package com.redalertcraft.building;

import com.redalertcraft.RedAlertCraft;
import com.redalertcraft.combat.CombatSounds;
import com.redalertcraft.entity.InfantryUnit;
import com.redalertcraft.entity.RaUnit;
import com.redalertcraft.match.MatchManager;
import com.redalertcraft.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.storage.DimensionDataStorage;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * Регистрация зданий, урон, разрушение, штурм, гарнизон.
 */
public class BuildingManager extends SavedData {

    private static final String DATA_NAME = RedAlertCraft.MOD_ID + "_buildings";

    private final Map<Long, BuildingInstance> buildings = new HashMap<>();

    public static BuildingManager get(ServerLevel level) {
        DimensionDataStorage storage = level.getDataStorage();
        return storage.computeIfAbsent(BuildingManager::load, BuildingManager::new, DATA_NAME);
    }

    public BuildingInstance register(BlockPos pos, BuildingType type, UUID owner, int team) {
        BuildingInstance b = new BuildingInstance(pos, type, owner, team);
        buildings.put(pos.asLong(), b);
        setDirty();
        return b;
    }

    public BuildingInstance get(BlockPos pos) {
        return buildings.get(pos.asLong());
    }

    public void unregister(BlockPos pos) {
        buildings.remove(pos.asLong());
        setDirty();
    }

    /** Нанести урон зданию. Возвращает true если разрушено. */
    public boolean damage(ServerLevel level, BlockPos pos, int amount, UUID attackerOwner) {
        BuildingInstance b = buildings.get(pos.asLong());
        if (b == null) {
            // Авто-регистрация, если это наш блок
            BuildingType type = BuildingType.fromBlock(level.getBlockState(pos).getBlock());
            if (type == null) return false;
            b = register(pos, type, null, 0);
        }

        // Союзников не бьём
        if (attackerOwner != null && b.ownerId != null
                && (attackerOwner.equals(b.ownerId) || MatchManager.sameTeam(attackerOwner, b.ownerId))) {
            return false;
        }

        b.hp -= amount;
        setDirty();

        // Визуалы попадания
        spawnHitFx(level, pos, b);

        if (b.hp <= 0) {
            destroyBuilding(level, b);
            return true;
        }
        return false;
    }

    private void spawnHitFx(ServerLevel level, BlockPos pos, BuildingInstance b) {
        double x = pos.getX() + 0.5;
        double y = pos.getY() + 1.0;
        double z = pos.getZ() + 0.5;

        level.sendParticles(ParticleTypes.CRIT, x, y, z, 8, 0.4, 0.4, 0.4, 0.05);
        level.sendParticles(ParticleTypes.SMOKE, x, y + 0.5, z, 4, 0.3, 0.3, 0.3, 0.01);

        // При низком HP — искры и огонь
        if (b.hpPercent() < 0.35f) {
            level.sendParticles(ParticleTypes.FLAME, x, y, z, 6, 0.4, 0.5, 0.4, 0.02);
            level.sendParticles(ParticleTypes.LARGE_SMOKE, x, y + 0.8, z, 3, 0.2, 0.3, 0.2, 0.01);
        }

        CombatSounds.playBuildingHit(level, pos, b.hpPercent() < 0.35f);
    }

    private void destroyBuilding(ServerLevel level, BuildingInstance b) {
        BlockPos pos = b.pos;

        // Взрывной эффект
        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, pos.getX() + 0.5, pos.getY() + 1, pos.getZ() + 0.5,
                1, 0, 0, 0, 0);
        level.sendParticles(ParticleTypes.POOF, pos.getX() + 0.5, pos.getY() + 1, pos.getZ() + 0.5,
                30, 1.5, 1.0, 1.5, 0.05);
        level.sendParticles(ParticleTypes.LARGE_SMOKE, pos.getX() + 0.5, pos.getY() + 1.5, pos.getZ() + 0.5,
                20, 1.0, 0.8, 1.0, 0.02);
        level.sendParticles(ParticleTypes.FLAME, pos.getX() + 0.5, pos.getY() + 1, pos.getZ() + 0.5,
                25, 1.2, 0.8, 1.2, 0.03);

        float power = b.type == BuildingType.COMMAND_CENTER ? 2.0f : 1.2f;
        CombatSounds.playExplosion(level, pos, power);

        // Выпустить гарнизон
        for (UUID id : b.garrison) {
            Entity e = level.getEntity(id);
            if (e instanceof RaUnit unit) {
                unit.setNoAi(false);
                unit.setInvisible(false);
                unit.setPos(pos.getX() + 0.5, pos.getY() + 1, pos.getZ() + 0.5);
            }
        }
        b.garrison.clear();

        // Заменить блок на руины
        level.setBlock(pos, Blocks.COBBLESTONE.defaultBlockState(), 3);
        if (level.getBlockState(pos.above()).isAir()) {
            level.setBlock(pos.above(), Blocks.FIRE.defaultBlockState(), 3);
        }

        buildings.remove(pos.asLong());
        setDirty();

        // Сообщение владельцу
        if (b.ownerId != null) {
            ServerPlayer owner = level.getServer().getPlayerList().getPlayer(b.ownerId);
            if (owner != null) {
                owner.displayClientMessage(
                        Component.translatable("message.redalertcraft.building_destroyed", b.type.name()),
                        false
                );
            }
        }

        RedAlertCraft.LOGGER.info("Building destroyed at {}", pos);
    }

    /** Штурм: пехота у вражеского здания наносит усиленный урон / захват при полном гарнизоне. */
    public void tickAssault(ServerLevel level) {
        for (BuildingInstance b : buildings.values()) {
            if (!b.type.assaultable) continue;

            AABB area = new AABB(b.pos).inflate(2.5);
            for (InfantryUnit inf : level.getEntitiesOfClass(InfantryUnit.class, area)) {
                if (!inf.isAlive()) continue;
                UUID owner = inf.getOwnerUUID();
                if (owner == null) continue;

                // Свой гарнизон — вход
                if (b.ownerId != null && (owner.equals(b.ownerId) || MatchManager.sameTeam(owner, b.ownerId))) {
                    continue;
                }

                // Враг штурмует
                if (b.ownerId == null || !MatchManager.sameTeam(owner, b.ownerId)) {
                    // Урон от штурма каждый ~2 сек на юнита обрабатывается снаружи через assaultTick
                }
            }
        }
    }

    /**
     * Пехота штурмует здание — вызывается из AI.
     * @return true если здание уничтожено или захвачено
     */
    public boolean assaultTick(ServerLevel level, InfantryUnit unit, BlockPos buildingPos) {
        BuildingInstance b = buildings.get(buildingPos.asLong());
        if (b == null) {
            BuildingType type = BuildingType.fromBlock(level.getBlockState(buildingPos).getBlock());
            if (type == null) return false;
            b = register(buildingPos, type, null, 0);
        }

        UUID attacker = unit.getOwnerUUID();
        if (attacker != null && b.ownerId != null && MatchManager.sameTeam(attacker, b.ownerId)) {
            return false;
        }

        // Штурмовой урон (сильнее обычного)
        int dmg = 12 + unit.getVeteranRank().ordinal() * 4;
        boolean destroyed = damage(level, buildingPos, dmg, attacker);

        // Визуал штурма
        level.sendParticles(ParticleTypes.SWEEP_ATTACK,
                buildingPos.getX() + 0.5, buildingPos.getY() + 1.2, buildingPos.getZ() + 0.5,
                3, 0.5, 0.3, 0.5, 0.01);
        CombatSounds.playAssault(level, buildingPos);

        if (destroyed) {
            // Захват: ставим блок обратно и переназначаем владельца (для не-КЦ)
            // После destroy блок уже cobble — для захвата делаем иначе
            return true;
        }

        // Захват при HP < 20%: смена владельца
        if (b.hpPercent() < 0.2f && b.type != BuildingType.COMMAND_CENTER) {
            capture(level, b, attacker, unit);
            return true;
        }
        return false;
    }

    private void capture(ServerLevel level, BuildingInstance b, UUID newOwner, InfantryUnit unit) {
        int team = MatchManager.getTeam(newOwner);
        b.ownerId = newOwner;
        b.team = team;
        b.hp = Math.max(b.hp, b.type.maxHp / 3); // частичное восстановление
        setDirty();

        level.sendParticles(ParticleTypes.HAPPY_VILLAGER,
                b.pos.getX() + 0.5, b.pos.getY() + 1.5, b.pos.getZ() + 0.5,
                15, 0.6, 0.5, 0.6, 0.05);
        level.playSound(null, b.pos, SoundEvents.PLAYER_LEVELUP, SoundSource.BLOCKS, 0.8f, 1.2f);

        if (unit.getOwner() != null) {
            unit.getOwner().displayClientMessage(
                    Component.translatable("message.redalertcraft.building_captured", b.type.name()),
                    true
            );
        }
    }

    /** Гарнизон: спрятать пехоту в своё здание. */
    public boolean tryGarrison(ServerLevel level, InfantryUnit unit, BlockPos pos) {
        BuildingInstance b = buildings.get(pos.asLong());
        if (b == null) return false;
        UUID owner = unit.getOwnerUUID();
        if (owner == null || b.ownerId == null) return false;
        if (!owner.equals(b.ownerId) && !MatchManager.sameTeam(owner, b.ownerId)) return false;
        if (!b.canGarrison()) return false;

        b.garrison.add(unit.getUUID());
        unit.setInvisible(true);
        unit.setNoAi(true);
        unit.setPos(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
        setDirty();
        return true;
    }

    /** Выпустить весь гарнизон. */
    public void unloadGarrison(ServerLevel level, BlockPos pos) {
        BuildingInstance b = buildings.get(pos.asLong());
        if (b == null) return;
        int i = 0;
        for (UUID id : b.garrison) {
            Entity e = level.getEntity(id);
            if (e instanceof RaUnit unit) {
                unit.setNoAi(false);
                unit.setInvisible(false);
                unit.setPos(pos.getX() + 0.5 + (i % 3), pos.getY() + 1, pos.getZ() + 0.5 + (i / 3));
                i++;
            }
        }
        b.garrison.clear();
        setDirty();
    }

    /** Периодический дым от повреждённых зданий. */
    public void tickVisuals(ServerLevel level) {
        for (BuildingInstance b : buildings.values()) {
            if (b.hpPercent() < 0.5f) {
                double x = b.pos.getX() + 0.5;
                double y = b.pos.getY() + 1.5;
                double z = b.pos.getZ() + 0.5;
                if (level.random.nextInt(8) == 0) {
                    level.sendParticles(ParticleTypes.SMOKE, x, y, z, 2, 0.2, 0.3, 0.2, 0.01);
                }
                if (b.hpPercent() < 0.25f && level.random.nextInt(6) == 0) {
                    level.sendParticles(ParticleTypes.FLAME, x, y, z, 1, 0.15, 0.2, 0.15, 0.01);
                }
            }
        }
    }

    /** Найти ближайшее вражеское здание для штурма. */
    public BlockPos findNearestEnemyBuilding(ServerLevel level, Vec3 from, UUID attackerOwner, double range) {
        BlockPos best = null;
        double bestD = range * range;
        for (BuildingInstance b : buildings.values()) {
            if (b.ownerId != null && attackerOwner != null
                    && (b.ownerId.equals(attackerOwner) || MatchManager.sameTeam(attackerOwner, b.ownerId))) {
                continue;
            }
            double d = from.distanceToSqr(Vec3.atCenterOf(b.pos));
            if (d < bestD) {
                bestD = d;
                best = b.pos;
            }
        }
        return best;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (BuildingInstance b : buildings.values()) {
            list.add(b.save());
        }
        tag.put("Buildings", list);
        return tag;
    }

    public static BuildingManager load(CompoundTag tag) {
        BuildingManager m = new BuildingManager();
        ListTag list = tag.getList("Buildings", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            BuildingInstance b = BuildingInstance.load(list.getCompound(i));
            m.buildings.put(b.pos.asLong(), b);
        }
        return m;
    }
}
