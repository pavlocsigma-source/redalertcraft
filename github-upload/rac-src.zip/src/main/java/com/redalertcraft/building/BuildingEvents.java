package com.redalertcraft.building;

import com.redalertcraft.RedAlertCraft;
import com.redalertcraft.entity.InfantryUnit;
import com.redalertcraft.match.MatchManager;
import com.redalertcraft.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.UUID;

@Mod.EventBusSubscriber(modid = RedAlertCraft.MOD_ID)
public final class BuildingEvents {

    private static int tickCounter = 0;

    /** Регистрация здания при установке. */
    @SubscribeEvent
    public static void onBlockPlace(BlockEvent.EntityPlaceEvent event) {
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        BlockState state = event.getPlacedBlock();
        BuildingType type = BuildingType.fromBlock(state.getBlock());
        if (type == null) return;

        UUID owner = null;
        int team = 0;
        if (event.getEntity() instanceof ServerPlayer player) {
            owner = player.getUUID();
            team = MatchManager.getTeam(owner);
        }

        BuildingManager.get(level).register(event.getPos(), type, owner, team);
    }

    /** Shift+ПКМ по своему зданию — высадить гарнизон / инфо о HP. */
    @SubscribeEvent
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (event.getLevel().isClientSide()) return;
        if (!(event.getLevel() instanceof ServerLevel level)) return;

        Player player = event.getEntity();
        BlockPos pos = event.getPos();
        BuildingType type = BuildingType.fromBlock(level.getBlockState(pos).getBlock());
        if (type == null) return;

        BuildingManager mgr = BuildingManager.get(level);
        BuildingInstance b = mgr.get(pos);
        if (b == null) {
            b = mgr.register(pos, type, player.getUUID(), MatchManager.getTeam(player.getUUID()));
        }

        if (player.isShiftKeyDown()) {
            // Высадка гарнизона
            mgr.unloadGarrison(level, pos);
            player.displayClientMessage(
                    Component.translatable("message.redalertcraft.garrison_unloaded", b.garrison.size()),
                    true
            );
            event.setCancellationResult(InteractionResult.SUCCESS);
            event.setCanceled(true);
            return;
        }

        // Показать HP
        int pct = (int) (b.hpPercent() * 100);
        String bar = hpBar(b.hpPercent());
        player.displayClientMessage(
                Component.literal("§6" + type.name() + " §fHP: §a" + b.hp + "§7/§f" + type.maxHp
                        + " §7(" + pct + "%) " + bar
                        + " §8| Гарнизон: " + b.garrison.size() + "/" + type.garrisonSlots),
                true
        );
    }

    /** ПКМ пехотой по своему зданию — в гарнизон (через взаимодействие игрока с юнитом рядом — упрощённо: команда). */

    @SubscribeEvent
    public static void onWorldTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.level instanceof ServerLevel level)) return;
        if (level.dimension() != ServerLevel.OVERWORLD) return;

        tickCounter++;
        if (tickCounter % 10 == 0) {
            BuildingManager.get(level).tickVisuals(level);
        }
    }

    private static String hpBar(float pct) {
        int filled = Math.round(pct * 10);
        StringBuilder sb = new StringBuilder("§a");
        for (int i = 0; i < 10; i++) {
            if (i == filled) sb.append("§8");
            sb.append("|");
        }
        return sb.toString();
    }

    private BuildingEvents() {
    }
}
