package com.redalertcraft.building;

import com.redalertcraft.registry.ModBlocks;
import net.minecraft.world.level.block.Block;

/**
 * Типы зданий: HP, можно ли штурмовать, гарнизон.
 */
public enum BuildingType {
    COMMAND_CENTER(2500, true, 5),
    POWER_PLANT(800, true, 2),
    REFINERY(1000, true, 2),
    BARRACKS(900, true, 4),
    WAR_FACTORY(1200, true, 2),
    AIRBASE(1000, true, 2),
    OIL_DERRICK(600, true, 1);

    public final int maxHp;
    public final boolean assaultable;
    public final int garrisonSlots;

    BuildingType(int maxHp, boolean assaultable, int garrisonSlots) {
        this.maxHp = maxHp;
        this.assaultable = assaultable;
        this.garrisonSlots = garrisonSlots;
    }

    public static BuildingType fromBlock(Block block) {
        if (block == ModBlocks.COMMAND_CENTER.get()) return COMMAND_CENTER;
        if (block == ModBlocks.POWER_PLANT.get()) return POWER_PLANT;
        if (block == ModBlocks.REFINERY.get()) return REFINERY;
        if (block == ModBlocks.BARRACKS.get()) return BARRACKS;
        if (block == ModBlocks.WAR_FACTORY.get()) return WAR_FACTORY;
        if (block == ModBlocks.AIRBASE.get()) return AIRBASE;
        if (block == ModBlocks.OIL_DERRICK.get()) return OIL_DERRICK;
        return null;
    }
}
