package com.redalertcraft.building;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Состояние одного здания: HP, владелец, гарнизон.
 */
public class BuildingInstance {

    public final BlockPos pos;
    public final BuildingType type;
    public UUID ownerId;
    public int team;
    public int hp;
    public final List<UUID> garrison = new ArrayList<>(); // UUID пехоты внутри

    public BuildingInstance(BlockPos pos, BuildingType type, UUID ownerId, int team) {
        this.pos = pos.immutable();
        this.type = type;
        this.ownerId = ownerId;
        this.team = team;
        this.hp = type.maxHp;
    }

    public float hpPercent() {
        return Math.max(0f, (float) hp / (float) type.maxHp);
    }

    public boolean isDestroyed() {
        return hp <= 0;
    }

    public boolean canGarrison() {
        return garrison.size() < type.garrisonSlots;
    }

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        tag.put("Pos", NbtUtils.writeBlockPos(pos));
        tag.putString("Type", type.name());
        if (ownerId != null) tag.putUUID("Owner", ownerId);
        tag.putInt("Team", team);
        tag.putInt("Hp", hp);
        ListTag list = new ListTag();
        for (UUID id : garrison) {
            CompoundTag u = new CompoundTag();
            u.putUUID("Id", id);
            list.add(u);
        }
        tag.put("Garrison", list);
        return tag;
    }

    public static BuildingInstance load(CompoundTag tag) {
        BlockPos pos = NbtUtils.readBlockPos(tag.getCompound("Pos"));
        BuildingType type = BuildingType.valueOf(tag.getString("Type"));
        UUID owner = tag.hasUUID("Owner") ? tag.getUUID("Owner") : null;
        BuildingInstance b = new BuildingInstance(pos, type, owner, tag.getInt("Team"));
        b.hp = tag.getInt("Hp");
        ListTag list = tag.getList("Garrison", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            b.garrison.add(list.getCompound(i).getUUID("Id"));
        }
        return b;
    }
}
