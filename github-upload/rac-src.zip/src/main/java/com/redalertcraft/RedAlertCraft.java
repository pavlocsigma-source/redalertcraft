package com.redalertcraft;

import com.mojang.logging.LogUtils;
import com.redalertcraft.network.ModNetwork;
import com.redalertcraft.registry.ModBlocks;
import com.redalertcraft.registry.ModCreativeTabs;
import com.redalertcraft.registry.ModEntities;
import com.redalertcraft.registry.ModItems;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(RedAlertCraft.MOD_ID)
public class RedAlertCraft {

    public static final String MOD_ID = "redalertcraft";
    public static final Logger LOGGER = LogUtils.getLogger();

    public RedAlertCraft() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(modEventBus);
        ModItems.ITEMS.register(modEventBus);
        ModEntities.ENTITIES.register(modEventBus);
        ModCreativeTabs.CREATIVE_MODE_TABS.register(modEventBus);
        modEventBus.addListener(this::commonSetup);
        MinecraftForge.EVENT_BUS.register(this);
        LOGGER.info("Red Alert Craft загружается...");
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(ModNetwork::register);
        LOGGER.info("Red Alert Craft common setup OK");
    }
}
